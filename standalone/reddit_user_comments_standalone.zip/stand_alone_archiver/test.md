___
***#1: comment @ [2016-04-21 19:29:17 UTC](https://www.reddit.com/r/mildlyinteresting/comments/4ft8ag/the_cover_of_george_orwells_1984_becomes_less/d2c3fdv)***

a unite a stage a coup a revolution a bring a genocide a new world a

In the MKULTRA experiments, the CIA dosed unwitting subjects with LSD to see how they would react. What has not yet come to light is that MKULTRA was an intra-agency project. The CIA created new departments within the CIA and fed them steady doses of LSD and other psychoactives to see how the departments would diverge and mutate away from normal departments. Whole projects and hierarchies were created with everybody involve being more or less unwittingly under the influence of LSD. This is how the "restraint bed portals" and "flesh interfaces" were first created i.e. from a heavily psycho-mutated hierarchy. The entire thing had to be eliminated, but the technology it created has been revolutionary.
___

___
***#2: comment @ [2016-04-21 20:04:03 UTC](https://www.reddit.com/r/tifu/comments/4ft8f2/tifu_by_accidentially_making_napalm_in_my_friends/d2c51m1)***

In Vietnam, the U.S. government tried to pacify the country village by village using the Strategic Hamlet Program, basically creating villages where there was no or little Viet Cong influence. They tried more extreme experiments where they completely isolated villages or groups of villages, allowing absolutely nobody to enter or exit for periods of up to four years.

In some of the villages, people simply starved to death. In other, more self sufficient villages, the people managed to scrape by. It was noted that in many of the villages where this technique was tried, messianic or millenarian movements sprang up.

In 16 separate incidences, villages were able to independently invent "flesh interfaces" and "non-electrical portals", and it was surmised that these villages were being collectively dosed with LSD for long periods of time, and their intellectual mutations allowed for these 'advances'. The flesh interfaces were eventually destroyed by the North Vietnamese Army at a terrible cost in lives.
___

___
***#3: comment @ [2016-04-21 21:13:27 UTC](https://www.reddit.com/r/todayilearned/comments/4ft9zv/til_winston_churchill_along_with_many_of_the/d2c866l)***

I'm surprised they used nuclear subs in the Falklands, considering the battle's proximity to the undersea incident zone surrounding the so-called Artigas portal. As I understand it, the portal was opened because of experiments taking place in the CIA's antarctic station in the early 80s, and Falklands quickly became a center for portal research.

Being underwater, the portal had an enormous incident zone, and segmented whales and other undersea debris would regularly wash up on the islands' shores. They found one whale that had been segmented cleanly in half by an incident zone disturbance, proving a perfect cross section of the creature. They also found hundreds of the "chitinous cruciform" creatures, certainly non-terrestrial in origin.

Anyways, if a nuclear sub had wandered into the incident zone, it could have been disastrous, but I guess they considered the risk acceptable.
___

___
***#4: comment @ [2016-04-21 21:53:02 UTC](https://www.reddit.com/r/dataisbeautiful/comments/4fsa3w/the_quality_of_driving_in_a_country_correlates/d2c9u04)***

The Soviets designated large portions of the Ukraine countryside as "harvest populations." Basically, their food and water supplies were dosed with LSD until they had achieved what the Soviets called "integration". This meant that the local populations had independently invented **flesh interfaces**. The Soviet army would then quarantine the area and try to remove the flesh interfaces for their own use. This was usually without success and with great loss of life.

Many of the soldiers and scientists were segmented, as often happens in an incident zone. So they ended up with people missing limbs, cut in half, etc. What's interesting is that the people could live for quite some time despite segmentation. This is what led the Soviets to believe that their missing body parts still existed albeit in some unknown place. So one one of the leading theories of the time was interdimensionality. Quite mistaken.
___

___
***#5: comment @ [2016-04-21 22:20:20 UTC](https://www.reddit.com/r/funny/comments/4ftjm3/when_i_tell_people_all_the_countries_ive_been/d2caxhe)***

Dubai probably has the highest rate of free-floating non-*interface* incidents of any major metropolitan area in the world. In one incident, a large group of migrant workers was segmented in an underground facility. Perfect cross-sectional segmentation along the frontal plane. You could see their lungs working, food being digested, blood pumping on the inside of the heart, everything. They live for almost 5 months in this condition. Absolutely fascinating to see in person.

There was also a group of school children who were very slightly segmented, just ends of figures and bits of the calves and such. Hardly fatal wounds, yet they all died within 2 months. Some showed signs of intellectual mutation.

There are no known *flesh interfaces* in Dubai. However, it is surmised that the architecture is actually based on *interface* geometry and carries some latent *interface*-like power. Mass segmentations remain one of the most mysterious aspects of the *interfaces*. They seem to show that the interfaces do indeed concentrate on flesh, living up to their name.
___

___
***#6: comment @ [2016-04-21 22:40:05 UTC](https://www.reddit.com/r/funny/comments/4fu1bd/rip_sweet_prince/d2cbp0s)***

We look at Elizabeth Bathory as an example of pre-LSD "enlightenment" i.e. somebody seeming to attempt to build a *flesh interface* before the invention of LSD.

How can this be explained? Perhaps she ingested some ergot or some other naturally occurring psychotropic chemical. Or perhaps her mind was simply attuned to whatever intellectual processes need to occur to invent a *flesh interface*. The Book of Revelations is also considered to be a description of a *flesh interface* especially the description of New Jerusalem.

My problem with this is that it is all speculative. It's like when modern psychologists diagnose historical figures. I'm uncomfortable with this level of speculation.

I will always regard the first instance of a *flesh interface* to have occurred in Triblenka, 1944. The geologic disturbances, partial tunnels, so-called interdimensionality, and wealth of clearly segmented bodies leave no doubt of its existence. The Soviets have documented this.
___

___
***#7: comment @ [2016-04-21 22:52:45 UTC](https://www.reddit.com/r/funny/comments/4fu1bd/rip_sweet_prince/d2cc6cf)***

Basically, when you look at the stories of Elizabeth Bathory's behavior, it seems like she is trying to build a *flesh interface*. But it is known that in order to invent a *flesh interface*, one must be under the influence of LSD for extended periods. As LSD hadn't been invented during her life, it's probably just a coincidence. Still a tantalizing theory, though.
___

___
***#8: comment @ [2016-04-21 23:09:25 UTC](https://www.reddit.com/r/funny/comments/4fu1bd/rip_sweet_prince/d2cct4e)***

Obviously I can't define a *flesh interface* in terms of purpose or composition or mechanism. I can only list the various phenomena which are related to them. Chief among these is the creation of an incident zone wherein objects are spontaneously segmented i.e. parts of the objects simply disappear, yet the objects continue to behave as if the missing parts are still present.

Also, you see complex tunnels created in the earth. These have been termed "ant farms". In undersea *interfaces*, you get chitinous cruciform organisms. These sui generis organisms are thought to be the result on evolutionary processes which took place in an environment other than earth. This is speculation, but in this case, I agree with it. Then there have been the giant metallic cylinders which appear and experience continuous spontaneous segmentation. These are usually at least 10 meters in diameter and can get much larger, and only occur in very large *interfaces* i.e. *portals*.

Beyond this, the phenomena are too various to mention, and different for each interface.
___

___
***#9: comment @ [2016-04-22 02:52:46 UTC](https://www.reddit.com/r/funny/comments/4fuygu/im_sad_hes_gone_too_if_you_draw_a_mustache_on/d2cll7b)***

Many people think that a portal is simply a large *flesh interface*. This is true. A portal is a large flesh interface. But it is also more than that. A portal is, as the name implies, a way of sending objects between the portal site and wherever the various locations that been found beyond the portals are located. (i.e. the so-called alien Sister Cities)

Portals are usually but not always accompanied by the large, fluctuating metallic cylinders. The largest above-water portal that I know of occurred in Novaya Zemlya and existed for several weeks before it was destroyed by the Russians' so-called "Tsar Bomba". In this case, the metallic cylinders were miles high and covered with features rarely seen on other cylinders: blinking lights, nodules, so-called antennae. They took on a very artifactual appearance i.e. they seem to be constructed technology rather than naturally occurring phenomena.

Are the cylinders themselves artifacts being sent through the portals? Or are they phenomena created by the *flesh interfaces* in the way a mushroom cloud is created by a nuclear explosion? This is unclear.

I wish I could show you guys pictures of the Novaya Zemlya cylinders. They truly were beautiful, rising miles into the clear arctic air, like great alien towers, tinged blue by the vastness of the distances involved. Though it was certainly necessary to destroy them, and we owe the Soviets a great debt for their tireless efforts to collapse the interface, I sometimes wish they were still there. At least then, there would be something, some evidence.
___

___
***#10: comment @ [2016-04-22 04:12:46 UTC](https://www.reddit.com/r/mildlyinteresting/comments/4fumjm/the_paint_peeling_off_this_sign_makes_it_look/d2coaqr)***

In response to what the CIA had "accomplished" with their Antarctic station in Artigas, the Soviets built a larger station in Novaya Zemlya in the arctic. 30,000 prisoners and an exceptionally pure gas concentration created a *flesh interface* which went through all seven stages in less than thirteen minutes and became a full fledged portal. Within a day, the typical fluctuating metallic cylinders were visible and within 3 days they were extending miles into the sky.

The Soviets quickly realized that the portal was growing out of control. In previous instances, they had simply bombed the site from the air. But in this case, the enormous cylinders and attendant incident zone, extending to the edge of space, prevented this as well as missile strikes. There was also an exceptionally large lateral incident zone around the portal, with segmentation occurring miles out from the site.

Alarmed by the zone's uncontrolled growth and the growing underground tunnels (aka "ant farms") the Soviets worked feverishly to construct a hydrogen bomb of unprecedented power which could be detonated from outside the incident zone and still collapse the portal. The steady rate of growth in the incident zone provided them with an exact deadline, which they managed to meet with only two hours to spare. Any later, and the bomb could not have been placed so as to collapse the interface. In short, the world came within 2 hours being subjected to an uncontrolled *flesh interface* and perhaps the end of civilization as we know it.

Before the portal was collapsed, however, the Soviets had gained firsthand knowledge of one of the so-called Sister Cities. In other words, somebody had gone into the portal and come back.
___

___
***#11: comment @ [2016-04-22 06:30:44 UTC](https://www.reddit.com/r/funny/comments/4fuxbg/this_wolf_looks_horrified/d2cs0yd)***

I've always found Lisa's Dream to be a good starting place when trying to understand the psychological effects of "travel."

Lisa was a 9 year old girl sent through the Groom Lake interface in 1975. The Groom Lake interface connects to the so-called Sister City (technically, "persistent locus") known as "The Hanging Temples". She stayed there for 5 days of normal-time, but only 48 seconds of beyond-time, a marked discrepancy. Upon returning, she did not recall anything beyond becoming drowsy for a moment. She slept well that night, and in the morning she recounted a dream to the doctors, before dying later in the day.

A direct transcript of the audio from her interview:

"It was spring and it had been raining all day, but the rain stopped just before it was going to be sunset. So all the clouds were purply and the sky was really orange. And the grass was all wet with rain and there were fire flies around, like all in the sky, way up in the sky, big ones. And me and my grandma went out to these hills way out past the edge of town, and under the hills there were people sleeping. Not in caves. They were buried under the hills. The people were asleep but they were hugging each other. Families, like moms and dads and little kids. Just packed together, a few thousand. The hills were just blown up like balloons because they were so full of people. Like a pregnant woman's stomach. My grandma told me to lie down but I didn't want to. She laid down and got sucked into the ground. I heard her voice coming out of the ground telling me to come inside."
___

___
***#12: comment @ [2016-04-22 18:18:21 UTC](https://www.reddit.com/r/todayilearned/comments/4fyhx4/til_prince_used_an_image_of_dave_chappelle/d2dcwn8)***

It would be easy to say that the Soviets discovered the secret of survivable "travel" because they were more ruthless, more willing to sacrifice innocent lives. But there was really no lack of ruthlessness on the part of the CIA. It was really just a matter of approach.

The Soviets approached the mystery of the *flesh interfaces* the same way they approached their space program. The first humans in space (the so-called "lost cosmonauts" who were never officially acknowledged) were just ordinary people, culled from the gulags, with no more control over their missions than Laika the dog. The Americans, on the other hand, started with professional men, usually from the military.

Likewise, when it was discovered that objects and even animals which entered the *flesh interfaces* occasionally returned unharmed, the Americans began training men to enter the interfaces. Because they culled their men from certain military ranks, they were all of similar ages. The Soviets, however, used prisoners, who had a much wider age range, and so they were able to discover the essential correlation: the younger a person was, the more likely they were to survive "travel," and the longer they would survive after travel.

They discovered that 20-somethings were much more likely to survive, (albeit in a horribly "altered" state) than older people. They discovered that people in their early twenties fared better than those in their late twenties. Teenagers fared even better. So, despite all moral compunction, it was really a matter of time before they sent a child through.

And it was only after the first round of children went through that they gained any idea of what was on the "other side".
___

___
***#13: comment @ [2016-04-23 06:14:11 UTC](https://www.reddit.com/r/todayilearned/comments/4g1g4u/til_in_1984_a_1yearold_received_a_heart/d2e1ell)***

Until we found the village, we had suspected that the detectors were just props. Just toys given to us by the CIA guys to reassure us. Nobody trusted the spooks. 3 days through the jungle, and these detectors had not detected a fucking thing. But before we even saw the first hut, the needles on all the detectors started moving in unison. If they were phony toys, it was a cool little special effect. The needles swayed back and forth and all the little metal boxes let out this spooky ooaaooaaaooo sound all in unison, like a school choir. Very weird. We turned them off.

As instructed, we treated every vietnamese as combatants, and killed them all. There wasn't any resistance though. A few had weapons, but most were unarmed. None fought back. They didn't even run. They were just sitting around, lazing in the sun, and we shot them where we found them. Grim work. And very weird. That probably spooked us out more than the detectors. It was like they were waiting to die.

After clearing the village, we didn't know what to do. So we turned one of the detectors on and wandered around to see what was up. The detector started going nuts around one of the bigger huts in the middle of the village. We had already cleared it, but we went in again. There was a big altar inside, with candles and buddhas and gold signs with dink writing and shit. We figured maybe one of the buddha statues was setting the detectors off, but no. 

The hut was very hot and muggy. Even by the incredibly humid standards of Vietnam, it was incredibly, incredibly humid in there. Even the buddha statues were sweating. Their faces were literally coated with drops of moisture. Everybody noticed that there was something weird going with the air. There was something off about the pressure. So we just tossed everything. Picked all the shit up and tossed it out of the hut. Sure enough, when we picked up the big platform that held the altar, there was something under it.

It was a pit made of flesh. Maybe five feet across and going down about twenty feet before curving out of sight. When I say, "made of flesh," I mean, it looked like the inside of somebody's throat. Wet, reddish flesh-looking stuff. We had heard of them building tunnels, but this was... We really couldn't even understand what we were looking at.

It was breathing. The flesh kinda rippled and this hot air came out, and it felt and smelled just like somebody breathing right on your face. Enough to make you sick.

They told us "we would know it when we saw it."

Well, we saw it, and we knowed it.

We radioed in the coordinates and got the fuck out of there.
___

___
***#14: comment @ [2016-04-23 20:54:19 UTC](https://www.reddit.com/r/movies/comments/4g471c/china_official_says_film_the_martian_shows/d2en7bz)***

Encasement was certainly not something we were expecting. It really changed our whole perspective on what exactly was occurring. We thought that the *flesh interfaces* were just like pipes that went from one location to another, perhaps extradimensionally or by some other "magic." But when the first subject came back encased, we realized that... Well, I'm not sure what we realized. We realized -- for the thousandth time in our dealings with the flesh interfaces -- that we were dealing with something really beyond us. That's why I called it 'magic.' They were so far beyond our understanding, it was basically like meddling with some kind of black magic.

The first subject to come back encased was an 8-year-old girl we had named Jingles. We started naming the kids dogs' names to try to depersonalize them, to assuage the guilt. This was done by the recommendation of CIA psychiatrists, but it didn't work very well. We all still felt like shit. But what choice did we have? Could we just ignore the flesh interfaces and not study them? Perhaps, but you must realize that the Soviets were also studying them. That changed the whole equation. If they... Well, the ethical issues have been debated to death. What's done is done. We dropped the bomb on Hiroshima, we gave those blankets to the Indians, and we sent those kids through those portals, and now it's all just a part of history.

Anyways, we sent Jingles into flesh interface and an object returned 2 minutes later, which is a pretty long time for an interface. It was a large organic sac lined with viens, vaguely resembling a human lung, about 4 feet long. We x-rayed it and saw the skeleton inside and cut it open. Sure enough, Jingles was inside, naked and covered with blood, with no hair on her head. There was an umbelical cord attached to her belly button, which was attached to a sort of placenta.

We had a problem with the surgeons trying to harm her. It was later realized that her blood -- its blood -- the blood from the sac, had high concentrations of an exotic LSD analogue. It was getting absorbed through the skin. The placenta was like an LSD factory, pumping out millions of doses. This particular blend made people pretty violent, so we had to put on containment suits.

Jingles' skin was flawless, like a newborn's. No wrinkles on the back of her neck, no wrinkles on her palms except the major ones. She had the form of an 8-year-old girl but seemed a lot... newer. We did MRIs on her bone plates, and found they were still highly undeveloped, as if she was newborn. We wondered, is this really Jingles or some kind of clone? What sort of apparatus could have possibly produced this clone, and why?

After a day of observation, she awoke. We weren't sure if her mind was still there. Perhaps she had been "wiped clean." So we waited, asking her questions. At first, her behavior was like that of an infant. Just smiling and gurgling and clasping her hands. It was pretty eerie seeing that kind of behavior from an 8-year-old. Really, it was pretty eerie looking at her at all. Her skin was so pure and glowing, she looked like an absolute angel. I... we... well, anyways...

After a while she started babbling, saying little phrases. In a matter of hours, she seemed to progress through the various stages of development, her sentence structure and awareness becoming more and more sophisticated. As soon as she could understand sentences, we started questioning her again. Who was she? She said her name. She knew her past. This wasn't just a blank clone. This may or may not have been the original girl, but she seemed to have the same mind as the original. So then we asked her the question that we wanted to know, the question that had plauged us for years, the question that had led us, in the face of all humanity and morality, to send a child into a living apparatus of death.

What did you see? What's on the other side?

Her expression grew thoughtful. She was such a thoughtful, bright girl. We chose her for her intelligence. So young and bright and we just threw her... Anyways, she thought about the question, and it seemed then that we would finally get an answer, a real answer. I remember the sense of anticipation in the room. It was like nothing I've ever felt before or since. Remember, I quit the program that day, so I was never able to question another subject. Anyways, she said to us, "Inside the chamber, I started to feel drowsy. The everything changed. And... I knew what I saw. I had seen it before. I said to myself, 'This is like the room in grammy's house. The quiet room."

We asked her what she meant by this. She replied with these words -- her final words before she simply stopped living and sat there dead with her eyes still on us -- she said, "Come unto these yellow sands."
___

___
***#15: comment @ [2016-04-23 23:12:19 UTC](https://www.reddit.com/r/movies/comments/4g471c/china_official_says_film_the_martian_shows/d2ert8d)***

In explaining our cruelty, which, I admit, was quite beyond scope of all humanity, I feel I must remind you of how we lost the war.

We lost the war in the cruelest way imaginable. Island after island fell, and the enemy drew closer and closer. More and more bombs fell on our cities. Food grew more and more scarce. People starved. House burned, people burned, children burned. We were punished by our own sense of dignity, by our own inability to admit inevitable and total defeat. It was like watching a sword slowly being sunk into your chest, millimeter by millimeter, but you refuse to cry out, refuse to whimper or beg for mercy, and there is nothing you can do but watch the metal disappear into your weeping flesh.

By the end of 1944, it was clear that both Japan and Germany were doomed, barring some divine intervention. Yet the stories we knew from childhood told us that we had been saved by divine intervention before, when the fleets of Kublai Khan were at our shores, moving from island to island, conquering and raping, until a miraculous typhoon sent their ships to the bottom of the ocean. Though we were modern men and trained in Western science, we still believed that there was some sacred destiny in store for the Japanese people, and we kept an eye out for something, anything which hinted of the divine.

Two intriguing pieces of news had come to us via Germany, developments  which suggested that perhaps the tide of the war could turn suddenly. Both, however, were ominous. One was that America was developing a super-weapon, a bomb which could level entire cities, which used the latent power of the atom, unleashing very forces which held existence together. We assured ourselves that this was American propaganda, that no such weapon actually existed, but our scientists acknowledged that it was theoretically possible. 

The second piece of news was more puzzling. It was said that a Swiss scientist had synthesized a chemical, which, like the American nuclear technology, could unleash latent forces, this time the forces of the mind. This chemical was said to fuse the various disparate areas of the mind and allow for incredible insights. Apparently teams working under the influence of this chemical for long periods of time were capable of inventing techniques and devices previously unheard of.

By the end of 1944, various high ranking Germans were slipping out of Germany, like rats from a sinking ship, often trying to fund their escapes by selling various pieces of artwork, technology, intelligence, etc. It was from one of these that we obtained an enormous supply of this wonder chemical, LSD, which was supposed to be secret even from Germany's allies. Along with the chemical, we were given a piece of news which was positively tantalizing, given the position we were in.

According to our contact, experiments with LSD had been conducted at the Treblinka extermination camp. A group of prisoners was given the drug for a period of several months and the results were so impressive that somehow the prisoners were able to convince the camp leaders to take the drug as well. Soon the entire camp hierarchy was taking the drug and working together on a new device that was some sort of "destructive radar" which could bring down planes as easily as ordinary radar found them. It was said to be powerful enough to slice bombers right in half.

Of course, we found this piece of news hard to believe. Nazi death camp commanders working side by side with Jewish prisoners to invent a magical radar? It was utterly fantastical. Our good sense told us to ignore it. And yet... How could we?

The Americans had already taken back the Philippines... Soon they would take Iwo Jima... Then Okinawa... Then all the home islands.

We were facing the end of the Japanese as a free race. Perhaps the end of all Japanese existence. The Germans would have it easy compared to us. Many Americans were German in origin. There was a blood affinity between the countries. This did not exist for us. The Americans would burn our cities and rape our woman and enslave us, make us servants, like their 'niguro'. We would be cross-bred with the whites until we had become some degenerate half-castes. Japanese culture would crumble. The stories of our childhoods would be forgotten.

We were watching a sword disappear into our hearts, and we were desperate for some kind of divine intervention. So in late 1944, a glass jar of LSD crystals, enough for several million doses, was taken aboard a submarine and slipped under the cover of the sea back to the home islands.

We were looking for divine grace. What we found was a hell beyond our darkest dreams of destruction.
___

___
***#16: comment @ [2016-04-24 19:49:32 UTC](https://www.reddit.com/r/nottheonion/comments/4g7vid/russias_military_just_bought_five_bottlenose/d2fo9sl)***

When you're hanging out with a tribe of nazi acid-heads, "magical space pussy" doesn't even register on the weird-o-meter. I mean, they talked about so much weird shit, and so much of it was total bullshit, that I didn't pay any fucking attention to it. It was the sixties. Talking about magical space pussies was like asking somebody how their day went. It was just conversation to me. But to them it wasn't.

That was a strange time in my life. I had spent the last six months going from commune to commune, just checking them out. They were all bullshit. Every one of them was just some guy on a power trip and a bunch of women who grown up with bad fathers hanging on his every word, hoping he would solve all their problems. That's the only way the commune system worked. The guy got control of the women, and the women attracted a few guys to do the manual labor, but in the end it was basically just a new system of pimping. I mean, I'm from Brooklyn. I've seen pimping. These chicks had tried to escape society and just gotten themselves pimped out. It was tragic. But too tragic for me to give a shit about it.

So I went out to Death Valley. Why did I go there? Why does anybody? Because it has a cool name. If it was called Some Scorpions and Bunch of Fucking Rocks, which is what it actually is, nobody would go. I had decided I was done with counter-culture, I was done with the regular culture. I was done with all. I would go where nobody would bother me and just try to figure myself out. Get a little peace and quiet. A month later, the Manson family moved in next door.

For a while it was just a nice little guy named Paul and some girls living a few miles from my little shack. Seemed harmless. Then the whole family came in. Charlie too. They had already committed the murders at this point. It was big news, but nobody knew who did it. I surely didn't connect it to this band of weirdos next door. They seemed too stupid to pull off anything newsworthy. Just another bullshit commune.

 Once Charlie got there, the family seemed to spend most of their driving their dune buggies around, pretending to be the fucking Afrika Korps. I mean, Charlie would put on a helmet with a swastika and lead them in maneuvers. I had never met racist nazi hippies before, but there's a first time for everything. Some of them even talked about "Uncle Adolf" and how he knew the score, how he should have won the war.

I was a mechanic in the army, so I helped them out with the buggies and got to know them a little. Slowly, their little philosophy trickled down to me. They thought America was on the verge of an apocalyptic race war. Blacks on white. Helter Skelter. The Watts riots in every city. That part actually seemed pretty plausible. I mean, you have to understand, in 1969, the country had been getting weirder and weirder, more and more violent every year. Nobody was quite sure when it would end. Nobody knew that in the 70s the counterculture would just kinda peter out into a bunch of fucking James Taylor albums.

They said that they had come to the desert to find a hideout  so they would be safe while the Helter Skelter race war was going on. They said that somewhere out in the desert, there was "Bottomless Pit" full of wonders and treasures. In the Bible, Revelation speaks of the Tree of Life, which bears twelve kinds of fruit, one for every month. They said this tree was growing inside the Bottomless Pit, and would give them all the food they wanted while they waited out the war. When it was over, they said, they would emerge and Charlie would rule the world as the new Christ.

So that part was a little less plausible. And then I started hearing about the magical space vagina. I had become friends with Paul, who was actually a nice guy who just wanted to fuck the girls and get stoned and didn't really get into the whole nazi thing. He said that they were searching for the entrance to the Bottomless Pit. He said that entrance would be made of flesh growing out of the rocks, like a giant pussy so big you could stroll right in. I told him he thought about pussy way too much. But he was serious. He said that the technology to turn rocks into flesh was from outer space, and its secrets had been taught to Charlie by Uncle Adolph.

Until then, I had thought that Uncle Adolph was their name for Hitler. Slowly, as I learned more, I started to realize that they were talking about somebody who was still alive. Somebody they actually knew. They told me he was coming soon.
___

___
***#17: comment @ [2016-04-24 23:55:20 UTC](https://www.reddit.com/r/gifs/comments/4g9prc/soldiers_running_drills_on_lsd_in_the_1960s/d2fxdrb)***

This kind of psychological mirroring was exploited in the design of the *flesh interfaces*. When a human body is embedded in an interface, the independent (i.e. non-human) interface glands produce massive amounts of LSD which cause intellectual mutations (i.e. time-fracturing along several dozen axes). Meanwhile, independent hormone regulators produce a emotional oscillation between two states:

1. euphoria

2. terror

Thus we have the typical sound of an interface: alternating waves of giggling and screaming that move through the interface population, running along the length of the interface as the hormones travel along the independent conduits. These successive waves of giggling and screaming create a steady rhythm that washes over the traveler as they move through the interface. Natural empathetic responses (mirroring) prepare the traveler's body for the process of "embrace."
___

___
***#18: comment @ [2016-04-25 01:38:12 UTC](https://www.reddit.com/r/Jokes/comments/4g9467/two_gay_men_were/d2g0xhj)***

When I was little, they took mommy away and put me with a new mommy in a smelly dark house.

They said she was a real person, but I knew she wasn't. They had made her.

Her face was made from pieces of animal.

* pig cheeks

* hairy goat jaw

* old horse eyes

They sewed her together badly, and the seams were crusty. I hated her.

Real mommy called me from underground. I opened the attic window at sundown and let the spring breeze flow in. I heard her song floating in on the cool air, soft singing from the grave.
___

___
***#19: comment @ [2016-04-26 00:07:30 UTC](https://www.reddit.com/r/pics/comments/4gespb/found_this_in_my_universitys_stall/d2h9d5c)***

Watching the *flesh interface* process known as "embrace" is kinda like watching those Japanese subway groping videos. That was honestly the first thing I thought of when I watched it, but of course, I wasn't going to put that in the official report. You ever seen those videos? Oh, you wouldn't admit it if you had, right? It's a whole genre over there. Not the most progressive stuff in terms of gender equality, but compelling nonetheless. The videos start with a woman standing in the subway, minding her own business, when some guy starts feeling her up. She protests demurely and attempts to deflect his roaming hands. He persists. Other men on the subway, perhaps sensing her weakness, join in with the groping. A sort of group madness takes over the subway occupants. The men are transformed from ordinary travelers into a agglomerated mass of arms and hands and fingers, grabbing every part of the woman's body. The woman's attempts at protecting her personal space are always absurdly ineffectual, and soon she is divested of her clothing. Depending on the video's sub-genre, a variety of acts ensue, most of which surely violate local transportation statutes. "Embrace" is kind of like that. That, combined with a school of piranha stripping a live cow of its flesh.
___

___
***#20: comment @ [2016-04-26 07:40:58 UTC](https://www.reddit.com/r/AskReddit/comments/4gg11l/older_redditors_60_how_have_you_coped_with_the/d2ho5mf)***

Lying in the hold, listening to the bombardment, there is no sleep. The booming of the guns travels through the shivering metal of the ship. Hour after hour, without end, the arsenal of democracy rains down on the tiny island.

What could it be like for the Japs huddled in their bunkers? Surrounded. Doomed. Do they know they have no hope? Do they expect death? Do they wish for it?

Death. The island is death. Waiting for them. Ancient. Waiting since before they were born. Thousands of young men have crossed vast oceans to come to her, following paths they could have never foreseen. Thousands of young lives will converge on her shores. Converge and end.

After three days of round-the-clock bombardment, a clear and bright morning. Whispers through the hold about problems with the shells. Many of them never exploded, disappeared in the air. There have been stories of bombers being cut in half. Of bomb crews emerging limbless from their planes. What is on the island? Some new kind of weapon? Something the Japanese have been saving until now? Just talk. The men feel the death out there, waiting on the island.

The landing vehicles ride through the waves, and the Marines climb out onto beaches of ash, an alien surface, crumbling under their boots. There is no fire. No sound but the motors and the clinking of gear and the sergeants shouting, urging them on. No movement from the interior. Then screams. Bloody stumps. Men cut in half. But still no fire. How is there no fire? More men screaming. Groups of men on the ground, howling, bright red lumps where limbs had been. How? No sign of the Japs. No fire. No shells.

More vehicles land. The beaches become a crowded, screaming nightmare. There is something here, something beyond their understanding. Invisible. Killing at will. Is it the island itself?

A few men manage to advance up the steep beaches and across the rocks, but soon they are cut apart as well. Other men follow and advance farther. They have been trained to advance. Take the beach. Forward. Always forward. Slowly, the men find their way farther and farther into the island interior. Through horrible trial and error, they begin to understand. They don't speak of their discovery. They don't believe it. But their overwhelming will to go forward and their overwhelming fear of death teach them what their minds cannot accept, teach them a lesson about the island.

They notice tracks through the ash and rock where there is no grass. These tracks are not foot trails, but deep tracks carved at strange angles, striated like dry streams, places where it seems the ground is simply missing. They realize they must avoid these tracks. If they step onto them, or let any part of themselves pass over the them, that part will disappear, whether it is their fingers or feet or limbs or even their heads. Sometimes parts of their bodies disappear even when they don't cross the tracks, and they realize that there are unseen tracks through the air, invisible boundaries they must not cross.

If they lose a part of their bodies, the blood does not flow, but there is pain, pain beyond flames or knives or bullets. Pain unbearable. Unholy.  Inhuman. There are screams all around them, of men who have accidentally run afoul of the invisible power.

There is no time to understand this, to reason it out. They simply adapt. Moving carefully, holding out blades of wild grass or shirts or gear, probing, waiting for part of the object to disappear, then stopping, testing for a way forward. Sometimes they find it. Sometimes they are forced to turn back.

In less than an hour, they have forgotten entirely about the artillery and snipers and bayonets. There are no soldiers. Only entrances to empty bunkers, abandoned pieces of artillery, some cut in half, but no enemy. They are playing a new game now, taught to them by some unseen teacher, playing it with total concentration. Playing and winning.

The Marine wounded, with their strange unbleeding wounds, are taken away. Their screams fade. Orders from command are unchanged. Take the island. So they move forward. Up. Towards Mt. Suribachi.  The mountain is shaped like a bowl. A dead volcano. They approach by various paths, each man following another, taking a narrow path of safety. Makeshift markers are set up to show their boundaries.

A Marine turns and sees, floating like a butterfly, a severed human arm. It turns and floats away and disappears altogether. Minutes later, a disembodied pair of legs scrambles past. The Marines curse and speculate and even giggle, but keep moving forward. There is no time to understand. They expected to spend weeks taking the island. Now it seems that could have it in a couple hours.

A shot rings out, the first shot since the confusion of the landing. A Marine is firing at the mountain. Others peer through their binoculars and spy a man sitting on the rim of the mountain. Simply sitting. Alone. Just a vague shape. Snipers are called in and they fire on him, but the island's air seems to swallow the bullets. The man is untouched.

They press forward. The deadly tracks wind around them, growing more numerous. Some of the men find themselves at dead ends. One Marine slips and disappears entirely without so much as a shout. They come to the foot of the mountain. It is small but rugged and steep, and the lone man sits over them, looking down on them.

They hear the sounds now, coming from the other side of the ridge, coming from within the giant bowl of the mountain. Human voices. Many of them. Thousands. The sounds of laughter, giggling and cackling and howling laughter. Like a wonderful party where somebody is telling a hilarious story. The Marines listen to it dumbfounded. Slowly the laughter fades, and there is a new sound, a strange rushing roar that quickly breaks apart into discrete sounds: screams, shouts, gasps, weeping, terror. The sound rises and rises, and the Marines shudder. This too fades and the laughter returns. And so these two sounds trade places over and over, fading in and out above the sound of the waves.

A Marine trains his binoculars on the mountain again. The man is still sitting there. Japanese. Wearing a uniform. His head is floating several feet above his body. The body is in several pieces with lines of sunshine between them. His face, sweat dripping over the smooth eyelids, shows no emotion. Slowly, he raises his hand, as if wave to them, and his fingers float away from his palm.
___

___
***#21: submission @ [2016-04-26 21:20:45 UTC](https://www.reddit.com/r/cripplingalcoholism/comments/4gl284/ah_the_simple_nemesis/)***

When novelist Philip K. Dick was 42 years old, his fourth wife left him. Lonely and devastated, he opened his home to whoever wanted to stay there. This being San Francisco in 1971, the house quickly became filled with drug users. Dick himself was heavily abusing amphetamines, eating pills by the literal handful and forgoing sleep for days. The mood in the house quickly became paranoid, and at one point, multiple occupants were sleeping with guns under their pillows. The house was broken into, and Dick suspected government involvement, thinking he had gotten too close to some kind of secret in one of his novels. He moved away shortly after.

But his time at the house hadn't been all paranoia and firearms. There were also many good times. Dick was a mesmerizing conversationalist, with an easy command of facts and theories about art, religion, philosophy, and numerous esoteric subjects. He and his new friends, usually kids in their early twenties, would rap for hours and days about everything under the sun. He grew close to many of them. Many of them were runaways or otherwise clinging to the margins of society. After the break-in, Dick went to rehab and quit speed, but as time went on, many of his friends fell victim to the drugs.

In the epilogue to *A Scanner Darkly*, a fictionalized account of this time, he wrote:

 >This has been a novel about some people who were punished entirely too much for what they did. They wanted to have a good time, but they were like children playing in the street; they could see one after another of them being killed -- run over, maimed, destroyed -- but they continued to play anyhow. We really all were very happy for a while, sitting around not toiling but just bullshitting and playing, but it was for such a terrible brief time, and then the punishment was beyond belief: even when we could see it, we could not believe it. For a while I myself was one of these children playing in the street; I was, like the rest of them, trying to play instead of being grown up, and I was punished. We were forced to stop by things dreadful.

In the grip of withdrawal, I read that epilogue many times. Read it and wept. I remember, after a week-long binge, lying in my bed, weeping, nightmares crowding my mind, my hands shaking, the mental suffering unbearable, thinking to myself, "Should I really be punished like this? What have I done that was so horrible? Was it so wrong to drink? To want to feel comfortable? To want to feel OK? To want to forget about things for a while? Was it so horribly wrong? Such a crime, that I should go through this mind-crucifying torment?"

But it wasn't really a matter of right and wrong. It was simply a matter of cause and effect. My brain had adapted to the inhibitory effects of alcohol, and once the alcohol had been removed, it had entered a state of hyperactivity. The adaptation had become a maladaptation. That was all. There was nothing out there administering this suffering as a punishment. My only 'crime' had been knowing that this would happen and drinking anyways. I had been a child playing in the street.

Dick wrote in his epilogue, "In Greek drama they were beginning, as a society, to discover science, which means causal law. Here in this novel there is Nemesis: not fate, because any one of us could have chosen to stop playing in the street." There was no magical fate causing my suffering. Just the impersonal cruelty of causal law. That was my only Nemesis.

Perhaps one day, they will invent a substance which prevents the neuro-adaptation to alcohol, and we will be able to drink forever, like the Greek God Dionysus. We will drink and dance and laugh, and there will be no nightmares. We will be made children again, and we will play forever on a street where there are no cars.

Until then, there will be suffering beyond belief.
___

___
***#22: comment @ [2016-04-27 03:43:33 UTC](https://www.reddit.com/r/pics/comments/4gkqzg/lego_battleship/d2iwucr)***

They crawl up the mountain, bare hands on the sharp volcanic rocks. The sun beats down on them. It is a grueling test. The island has a secret that it doesn't want to reveal.

They draw close to the man at the top of the mountain, keeping their guns trained on him. He has no weapon. His body is fragmented like an image in a broken mirror, various pieces floating without connection, the brightness of the sky shining between them, the blood of his insides bright red. His head is like a balloon floating several feet over the rest of him.

"Hello, America," the head calls, breaking into a sickly smile. The whites of the eyes are clustered with red hemorrhages. Sweat rolls down the face.

The Marines don't know how to respond. They ask if he's armed. The question strikes one of them as funny and he giggles. A tide of giggling comes from the other side of the ridge, behind the fragmented man. The giggling turns to screaming.

"What's going on here? You alone?" A Marine asks.

The man doesn't seem to understand. One of the Marines tries his basic Japanese. The man makes a sour face. "No Nippon... Korea... Korea person," the man says, and a disembodied hand points to a nearby fragment of his chest. "나는...I... Christian... 예수," the man says. He pulls a necklace out of his shirt. On the end of it is a small metal cross. A tiny suffering Jesus gleams in the sun.

The Marine tries English again. "What's happening here?"

"마귀가 여기 왔어."

"What?"

"군인들이 대문을 건축했어. 그 아이의 명령으로."

"I don't understand."

A wide smile splits the Korean man's face, and he lets out a loud laugh, and the smile flees, and suddenly he is weeping. His emotions seem to follow the giggles and screams that come from inside the mountain. The Marines feel it too: the strange urge to laugh followed by a harrowing fear.

The sound beyond the ridge rises, the screams becoming higher and louder. A wave of maniac giggling joins the screaming so that both sounds fill the air at once. A electric feeling touches the skin on the Marines' arms. They find their minds filling with strange, dark thoughts.

Somewhere in a castle in Japan lies a mad God Emperor who has sent his men across the ocean to defend his glorious empire with their blood. On the other side of the world lies the great humming factory called America, the heart of an empire of commerce, which once forced Japan to join the world in trade. Machines and flesh now flow along tendril-like courses, delivering goods and death, ensnaring the globe.

The sun goes dark, like a light switch turning off. The Marines instinctively duck, then look up and gasp. Above them, extending miles into the sky, is an enormous metallic cylinder, filling the sky, blocking out the sun. It spins slowly above them, pieces of it flickering and disappearing like the image in a broken movie projector. In a day filled with madness, they find themselves confronted with something wholly beyond their capacity for surprise. They simply mutter soft curses and get closer to the ground. The earth seems to tremble with the sound of the screaming and laughing, which swirls like a storm all around them.

Somewhere near the beach, a Marine pats another Marine on the back, interrupting his stunned gawking, and shouts something into his ear. The second Marines pats the man in front of him, and the message goes up the line like this until it reaches the Marines talking to the fractured man. *Pull back*. They are to withdraw from the island. The men do not question the order for a moment. They turn and crawl away from the Korean.

Below them, the ashen island flashes with pieces of sunlight that manage to slip through the flickering cylinder. When they are almost at the foot of the mountain again, the man stands up and shouts something over the hideous screaming. The Marines cannot hear it and would not understand it anyways.

"마귀가 예수를 데리고 산으로 가서 천하 만국과 그 영광을 보여. 가로되 만일 내게 엎드려 경배하면 이 모든 것을 네게 주리라."
___

___
***#23: comment @ [2016-04-27 05:01:00 UTC](https://www.reddit.com/r/news/comments/4gktfu/lawyers_for_david_miscavige_are_mounting_an/d2iz8v8)***

Many people believe that Michael Jackson died due to propofol.

Not so. He was murdered.

He had actually been taking propofol nightly since around 1980, not in order to make himself sleep, but to suppress REM sleep. After several months of REM sleep suppression, the user becomes "receptive," in other words, they enter the same state achieved by prolonged continuous immersion in aerosol LSD.

The brain can physically restructure itself simply through thought. By reordering thought, one can physically reorder the brain. LSD or long-term propofol use makes the brain's neuro-structure "malleable". High-energy rays from outer space are able to penetrate the body, and these can lead to random mutations and cancers. And sometimes, they lead to changes that are not random at all. Changes which have been intentionally programmed. Changes designed to bring about civilization-level transformations.

Michael Jackson was unaware of all of this. He merely knew that propofol allowed him to enter sort of waking dream state of heightened creativity. The side effects were horrifying paranoia and obsession, but he felt that he was strong enough to endure these side effects. The success of Thriller seemed to vindicate his theories about propofol, and unfortunately, he was damned by his own success.

So how did he die? Through the lyrics of "Another Part of Me" and the vegetable part of "Wanna Be Startin' Something," it was quite clear that he had become "receptive" and neuro-altered in line with Master Design 9. But he was considered to be minimal threat and even perhaps and asset until his mounting financial problems made him a liability. He was terminated, thought I'm not sure of the exact means.
___

___
***#24: comment @ [2016-04-27 18:52:27 UTC](https://www.reddit.com/r/funny/comments/4goowg/i_will_always_have_a_bag_of_these_around/d2jo5ga)***

I suppose it's time to tell you what was inside the magical space pussy. You can believe me or not. What do I care? I'm the guy who's been inside the magical space pussy. My life has been pretty much downhill since then. I mean, fuck Neil Armstrong. What did he see? A bunch of gray rocks? Big fucking deal. I saw a chooch growing out of the side of a canyon. Top that, NASA! You Tang-drinking cocksuckers!

Anyways... where was I? Ah, yes, Uncle Adolf. So I was living in Death Valley, hanging out with the Manson Family, and Charlie kept mentioning this guy, "Uncle Adolph," and I figured he's talking about Hitler because he's sort of into this white supremacy thing. But then I started realizing that he's talking about a guy who's still alive. Then one day, the guy showed up.

They asked me to come over to their cabin, and this old guy was sitting there: white hair, deep tan, lined face, pale eyes. He introduced himself as Adolf, and he's got a German accent. He made no secret of the fact that he was an ex-Nazi. This made me nervous. That's kinda something you keep under your hat. He said he found Charlie at Berkeley, that Charlie was "perfect for my purpose." I asked what his purpose was. He said, "testing."

I kinda shrugged because I didn't really give a shit about his little coy answer, and I got up to leave when this mongoloid motherfucker they called Clem punched me straight in the face, and suddenly I was on my ass. There were a couple girls there, and they jumped on me and held me down and tied my hands behind my back. If I had known what they had done to Sharon Tate, I would've been unspeakably terrified, but as it was, I was merely really, really scared.

They tossed me into the back of the dune buggy and drove out into the desert. It was midday, and the sky was just one giant glare. We drove for over an hour, and eventually they got me out and hauled me down into this deep sandy arroyo, and they started marching me down it. They had put wooden stakes into the ground at various points, and when we came to them, they seemed to be really careful to always stay in between the stakes. Later, they had chains tied between the stakes, and we all had to go under the chains like some kind of obstacle course. I didn't know what to make of it. I had a lot to process at the time.

I started to notice that the rock walls of the arroyo were... abnormal. There were strange striations through the rock and what looked liked the cross sections of giant insect tunnels. I had never seen rocks like that. The whole thing was just... very alien.

Then I started to hear the screaming. Up ahead, I could hear people's voices, thousands of voices, all of them screaming and howling at once. Slowly, incredibly, the screaming changed into a kind of laughter, an insane laughter, giggles and chuckles and titters. I wondered if it was in my head, if I was so scared that my mind had cracked or if they had dosed me with LSD or something.

Finally, we went around a bend in the arroyo and, well, there it was. They said it would be a pussy, and I guess it kind of looked like one. Maybe after some kind of drastic dildo mishap. It was just... flesh. Wrinkled, lobed, flabby flesh, growing out of the rock like mold or something. It had hair and pores and freckles. Some of it was pale, some of it was black. It was taller than me, and in the center there was an opening. Pink and wet, like a pussy.

The kraut told me he wanted to see its "level of development." He took a revolver from one of the girls and pointed it at my face and told me to walk inside. It was either get shot or go into the big mangled pussy. It was honestly a tough choice. There was something completely fucked up, completely not right about that thing. Something in my bones told me not to go into it. Not to go near it. To just take the bullet in the head. But I figured maybe I could go in just a little bit and then wait for them to leave and get the hell out of there. Not a great plan, but the best I could come up with.

So I went in. The entrance was just barely wide enough to slip into. All I could see was glistening pink flesh ahead. There was this sound like laughter and then screaming and then laughter that was coming from deep inside. The walls were blood warm on my shoulders, and the smell was... well, what you might expect. Not great. Let's just say it was not great.

I pushed forward and the walls kind of gave way and found myself moving through this slimy, suffocating flesh, and I'm starting to panic because my hands are still tied behind my back, and I'm feeling like I'm about to choke on this stuff, and the walls are moving, like pulsating. I feel like I'm being digested. Then, suddenly, I'm pushed through into this kind of chamber.

Talk about out of the frying pan and into the fire. The chamber was... just a nightmare. I mean, I never... I've just never seen that. It was unholy. There were faces and heads and legs all kind of fused together. The walls were just all these crawling limbs and these terrified faces and fusions of teeth and cheeks and hair and fingers coming out of knees and just... they... all those people! Were they still people? Had they ever been people? Had they been made a part of that thing?

I started to scream. Everything around me was screaming, all the mouths on the walls were screaming, and I was screaming too. Then I was laughing, and I felt hands and mouths all over my body and they were tickling me, touching me all over. Then I was screaming again. I had to get out of there. I had to get out of the nightmare. I started pushing back towards the entrance, but the hands were all over me. I felt something bite into my hip. A mouth was biting me. I screamed at the sharp pain and moved away from it. I started to think that maybe I could get one of the mouths to bite through my ropes, and then I would at least have my hands free.

I struggled to turn around and move the ropes toward the mouth, but just when I got it in position, the mouth bit right into my finger instead. The pain was incredible, but I was giggling, just laughing and laughing. The mouth pulled the flesh from my finger like it was a chicken wing. Another mouth bit into my shoulder. I was chuckling away at this point. The hands were grabbing me, pulling on me, pulling me apart, tearing my arms right out of their sockets. Fingers were digging in between my ribs. I was slathered with blood and screaming, screaming as the fingers dug into my eyes.

Well, I guess that this point you're probably wondering how I, your intrepid narrator, managed to escape the Bottomless Pit, how I managed to survive to tell you this tale. I simply didn't. I never escaped the Bottomless Pit. I am the Bottomless Pit. Hahaha. I am the Tree of Life.
___

___
***#25: comment @ [2016-04-27 22:30:51 UTC](https://www.reddit.com/r/pics/comments/4gpwot/arnold_visited_my_friend_who_is_serving_in_kuwait/d2jxv24)***

The North Korean situation 1980s was unique, as most North Korean situations are. They built something he haven't seen before or since: an independent *flesh interface* of enormous size and power, but within a contained incident zone and no metallic cylinders. We detected it via the cosmic ray information signature which was concentrated on a secure, shielded facility outside the Hwasong prison camp.

This was a huge underground facility which they had been constructing for over a decade. We anticipated that they would construct a portal-level interface and were fully prepared to bomb it before became uncontained. What we didn't expect is that it would achieve Level VII cosmic transmission rates without all the other normal signs of full-fledged portal. We considered bombing it anyways, or using our Brilliant Pebbles kinetic orbital strike system, but instead we managed to get two agents into the facility to take a look at it.

They achieved high-level security clearance and found that the Koreans were using the *flesh interface* as an information processing facility. This was quite novel, as we had always considered it to be potential weapons system. Our curiosity was truly piqued. Clearly the Norks knew something we didn't. Unfortunately, our agents weren't able to access the enormous "mainframe chamber" which actually housed the interface. All they knew was that it was in a huge chamber full of temperature-regulated water.

We instructed them to breach the chamber and get a look at it, then send us the data by satellite. We knew full well that it would probably cost them their lives, but we pumped them up with a lot of "do it for the planet" rhetoric. So one night they put on dive suits and went into the chamber.

It was basically like a huge lake contained within a massive, darkened steel box. Imagine a flooded warehouse with endless rows of dim ceiling lights shining down on rippling black water. They jumped into the water, and pretty quickly they picked up some pretty interesting audio signals with varying frequencies -- a kind of squeaking, mewling sound. They recognized the sound for what it was right away, but had a hard time believing it. Whale songs. The chamber contained several adult humpback whales.
___

___
***#26: comment @ [2016-04-28 06:45:24 UTC](https://www.reddit.com/r/WTF/comments/4grnx9/bee_removes_nail_to_get_into_wall/d2kexwg)***

How do I explain mother? What was she?

Βαβυλὼν ἡ μεγάλη, ἡ μήτηρ τῶν πορνῶν καὶ τῶν βδελυγμάτων τῆς γῆς.

I used to lie in my bed, the blinds pulled against the summer sunlight, listening to the sounds of other kids playing outside. I lay there for hours, not sleeping, wondering who had made mother.

She was made from all different sorts of animal parts. One of her feet was big, heavy hoof. The other was a tiny little kitty cat paw. I could hear her clumping around downstairs. Her smell, the smell of cigarettes and disease, was everywhere in the house, pooling in the darkness.

Slowly, night would come, and I would imagine floating out of my window, floating up into the deep starry blue, looking down at all the houses shrinking into tiny boxes, the clean breeze blowing on my face.

Oh, how I would cry in my little bed.

I was very young when mother first came. I had another mommy before her, a good one, who wore pearls and had a voice like music. Then one day, I got sick, a fever. I was crying all day, and it went on for weeks. I guess my first mommy couldn't take it anymore. One night, she left forever. When I came down for breakfast the next morning, this new thing was waiting for me in the kitchen.

At least, I think that's what happened.

Mother never talked. She just snorted and made horse sounds. Awful. Her parts were sewn together with yarn, and there were patches of wet burlap. I didn't see her eyes until she had been there almost a year. Have you ever seen horse eyes up close? They're like goat's eyes. They have a sideways pupil.

I would come home after school, and there would be kids sitting at the breakfast table. She gave them medicine so they did whatever she wanted them to. It made them just sit there, staring and shaking. Then she would take them down in the basement and make them into things.

She tried to make me do it too, but I didn't want to. I realized she was afraid of the Bible. I realized it had power. Blood power. When I read it to her, her different pieces would shudder and pull apart, and she would howl like a wolf, and blood would run from her segments. The Bible brought transmissions from the cross that floated in the red summer sky.

Everything in time is arranged around the epicenter wherein the nail drove into Christ's hand. Lines of possibilities radiate outward from it. Kingdoms rise and fall, men grow and die like flowers in a field.

τὸ θηρίον ὃ εἶδες ἦν καὶ οὐκ ἔστιν, καὶ μέλλει ἀναβαίνειν
___

___
***#27: comment @ [2016-04-28 20:00:16 UTC](https://www.reddit.com/r/WTF/comments/4gttta/airplane_crashes_into_tree/d2l4m6h)***

So two of our agents had breached the underwater chamber containing the North Korean *flesh interface* and found nothing but several humpback whales. Now this was a head-scratcher. We knew it was a *flesh interface* because it was receiving information-rich rays coming from outer space, yet how could it be taking the form of humpback whales? All previous interfaces had taken on a decidedly less conventional form.

Well, the our agents decided to get a closer look. There were three whales, two adults and a calf. They appeared normal in every respect, though it was difficult to get a close look at them. They seemed to be in quite a bit of distress, though the agents were not biologists and had a limited understanding of what whale distress looks like.

The agents noticed some very loud low-frequency percussive sounds coming from the bottom of the chamber, which was entirely hidden in darkness. So they headed towards the bottom, a distance of several stories. There, they shined their lights around and made a fairly alarming discovery: bones. Enormous curving rib bones and jaw bones and vertebrae. They were apparently whale bones. They also noticed a large, circular gate on the floor of the chamber, which was closed at the time.

At this point, one of the agents began to panic. He had come to the conclusion that the whales were not the interface itself, but were merely 'food' for the interface, which was perhaps being held in another chamber below this one. There were some problems with this theory: why use whales, a fairly rare and very difficult animal to corral, when they could just use a large amount of smaller fish?

Well, it's all just speculation. The agents quickly swam out of the chamber and never found out what was behind the gate, if anything. Later gave us some very valuable information on the facility's information processing capabilities, which were staggering and quite appalling to imagine in the hands of a regime such as the DPRK. Since there was no incident zone and segmentation wasn't an issue, we were able to solve the problem quite neatly by releasing a nerve agent into the water chamber. The cosmic ray download stopped shortly thereafter, indicating success, though it did result in the loss of both agents and a major loss of life at the facility overall.

Anyways, that was our first encounter with a MBIS (Massive Biological Information System) and a near-encounter with what we could later come call a "Skin Ship". Its destruction has allowed for the continued validity of prime-number based encryption systems, though some of the secrets uncovered by the DPRK during that time have forced us into the unpleasant position of supporting the regime. Blackmail, basically.
___

___
***#28: comment @ [2016-04-29 01:21:34 UTC](https://www.reddit.com/r/aww/comments/4gvjlt/golden_retriever_puppy_in_training/d2lhzzx)***

Last night I dreamt I was a dog. I lived on a small family farm somewhere on the American frontier, back in the time of plow mules and butter churns. It was one of those long dreams that feels like an entire lifetime. I remember the end of the dream with an awful clarity, but the beginning seems like something that happened many years ago.

The first images are vivid but disjointed. I recall the shape of my master walking against the sunlight overhead. The smell of his leather boots. The shadows at the edge of the forest. A little pig-tailed girl hugging me. Fresh mud in the spring. Warm floorboards in the winter. Everything had a peaceful storybook quality to it, except one thing.

Sometimes late at night, I heard singing. It came from outside, out there in the far distance, from somewhere in the deep forest beyond the boundaries of my world. Some nights it was one voice, but usually it was many, singing a strange, aching song. It sounded like a haunted crying. When I was little, I had whimpered and cried like this to my mother. But who was crying out there in the night? What kind of dark mother was listening?

When I first heard the singing, I was filled with a blood dread. The hair on my back bristled, and I growled and barked at the darkness. Even after the night finally went silent, I trotted around for hours in vigilant anger. Later, as I heard it more often, I learned to accept it with a sullen unease. Of course, this singing was the sound of wolves howling, but I didn't know this in the dream. In the dream, I'd never seen a wolf in my life.

One winter, I began to see them prowling in the woods. To me, they were ghost dogs, shadows sneaking between trees, eyes glinting in the twilight. I growled and barked at them, but didn't pursue. For several months, they never encroached on my world.

They finally came on a late winter's evening. The sun had sunk into an orange glow beyond the edge of the world. The family was in the cabin, and I was out trotting through the snow, anxious to get back to them because I knew food would be coming soon. Then, atop a small hill by the apple tree -- an apparition. My body snapped to attention, and I growled, the hairs on my back standing on end. It was a wolf, just a stone's throw from me, its silvery coat half-lit in the dying light of day.

It came toward me in a sleek, soundless jaunt. I barked and snapped at the air. It slowed and stopped just beyond my lunging distance. Now, crazed with fear and anger, I saw that it was a large female, healthy, well-fed, with a gorgeous coat -- misty gray, the color of snow seen at a winter's distance. Its smell was alien, confusing, but laced with a clear and potent confidence, a supreme assuredness. Indeed, it did not seem to be afraid of me at all, nor did it threaten. Its mouth hung slack, and steam issued from its muzzle in steady, happy puffs. This calmed me for a moment and in the next moment redoubled my anger. I growled from the deepest, most murderous part of my dog self.

 It spoke to me. Its mouth didn't move, and there was no sound, but by the logic of the dream, it spoke to me a clear, dignified voice.

"Hello, child."

I snarled at it. It took another step forward, and its eyes caught the last of the sunlight, glowing in a fantastic array of yellows. Those eyes, rimmed in jet black like mascara, projected a powerful allure, an otherworldly glamour.

''You bark and snarl. But look at my face. Am I not of your kind?" it asked.

I could not answer. I could only growl softly.

"Is my face not like your mother's? Do you remember her?"

The sudden scent of distant memory came to me, and I felt a pang of loneliness. I had not seen my mother or any other dog since I was small. Since I had come to the farm, my only family had been the people I lived with (and a few of the more tolerant pigs). I searched now for dim, fragrant memories of my mother. I felt her huge, bristled muzzle licking at my face. I saw her giant, sweeping legs as I followed them through high fields. She had seemed taller than a horse then. I remembered the softness of her teats, feeding from them with my brothers and sisters. What had become of my family? I had spent every day with them, and then one day... all gone.

The wolf paced back and forth now, keeping a small distance from me, its eyes ranging over the farm. Again I saw some strange, haunting glamour in them, something that glittered with secret, distant power.

"The people in that house, they're not your family. We are. We share ancient blood," it said, its voice deep and resounding with the rhythm of wisdom. My master had a voice like this, but it didn't have the total authority of this alpha female's.

I saw with alarm two dark shapes come over the hill by the apple tree. More wolves, moving silent with heads lowered. I barked at them.

"You hate us and love them. But do they love you? What are you to them? Aren't you the lowest of the low? Always getting the last of the food, the smallest scraps? Imagine living differently. Imagine taking your own food. Killing. Drinking lifeblood. Being master over others."

The two other wolves slunk down the hill. The skin on my back tightened again, but the strange hypnotic power of the alpha wolf held me still.
"You could leave this house and come with us. We range the forests. We've seen rivers wider than this whole valley. Mountains that go up into the clouds. Lakes with no end but the end of the world. Places with no houses or men at all. You could be with us. We could be your brothers and sisters."

The other two wolves came closer. They were unmistakably females, both young and well muscled. Their confidence was not as absolute as the alpha wolf's, but they showed no fear as they came to me. I smelled on them a strange longing, a deep winter's desire for warmth.

The alpha wolf stepped closer, close enough that her steaming breath tickled my nose. Her eyes danced with cold burning light, and she spoke in a voice that made my blood hum.

"Outside your life waits everything you've never known," she said. "There are worlds, child. There are ecstasies."

I then recognized the allure that lit her eyes, the unspeakable longing that glimmered in their depths. It had seemed this whole time to be some fantastic, alien desire, reaching out to me from a distant world. Perhaps it truly was. But more simply than this, it was hunger. Plain hunger. That ancient, unsleeping hunger, older than the first furred thing that ever gave rise to the races of dogs and wolves and men. Hunger had brought this wolf across rivers and mountains and endless frozen plains to meet me in that moment. I can still see her face, the final image of the dream before the other wolves tore into me and I died and I awoke -- her face with eyes that spoke of open loneliness, her face, so noble and gentle and motherly, her face, as beautiful and ancient as the stars.
___

___
***#29: comment @ [2016-04-29 07:20:07 UTC](https://www.reddit.com/r/todayilearned/comments/4gvz4g/til_that_the_cofounder_of_alcoholics_anonymous/d2ltj9c)***

What do you do when a child who bleeds and sweats and pees LSD suddenly goes missing? We conducted a massive search. As massive as we could manage. Almost every "mentally elevated" CIA department was involved. We didn't trust anybody else. We never trusted anybody else. Shit, we didn't even trust ourselves, considering that it was one of our own who had taken the child.

We searched for about two months, but never really turned up any leads. Since every other "returned" child had died within a few days of being freed from their amniotic sac, we scaled the search down pretty quickly. It's one thing to search for somebody like Bin Laden, when everybody knows you're looking for him. It's another thing to search for somebody you had just worked quite hard to erase from official existence so you would be free to perform tests on her. We felt that the search itself was more of a security risk than the missing child, since she was almost certainly dead.

There was also a feeling that maybe it was for the best. Maybe she would survive. Maybe she would have a happy life. Maybe it was best not to know her fate.

But then, about 7 years later, we learned what happened.

If you'll allow me to wax philosophical for a moment, I'd like to quote a poem by Aeschylus that I've actually never read: "Even in our sleep, pain which cannot forget falls drop by drop upon the heart, until, in our own despair, against our will, comes wisdom through the awful grace of God." While I'm no literary scholar, I believe this means, "Learning can hurt sometimes."

So she had survived. Her genes came up in our program to collect a global genetic snapshot (a total boondoggle, btw). So where was she? In some Russian laboratory? Living out in the jungle, being worshipped as a god by some doomsday cult like Johnny Htoo? Floating through space in a bubble to Jupiter and beyond?

Estonia. She was found in Estonia in a Swedish speaking village on the island of Hiiumaa. She was living a normal life. Apparently the issue with the bio-LSD had resolved itself after detachment from the placenta, otherwise, anybody who got a kiss from her would have found themselves going on a very strange journey. She was about 13 years old at this point and had survived travel far longer than any other child. This meant she was an asset we absolutely had to obtain. She contained the secret to survivable travel, something that had eluded us for years.

It would have been convenient if she was living a life of abuse and drudgery in some orphanage somewhere. We could have simply considered her a victim of fortune. But she was actually living in a quaint little village on the edge of a beautiful forest with an old couple who had been given some phony story by our former agent. It was a nice life. Quiet. Maybe a little boring. But a nice one.

We took her in the middle of the night back to our facility in Colorado.

In the end, she wasn't a victim of fortune. She was a victim of us.
___

___
***#30: submission @ [2016-04-29 08:34:28 UTC](https://www.reddit.com/r/9M9H9E9/comments/4gyih5/thank_you_for_making_another_subreddit/)***


___

___
***#31: comment @ [2016-04-29 21:45:34 UTC](https://www.reddit.com/r/todayilearned/comments/4gzoah/til_there_is_no_historical_evidence_for_any/d2mmaiu)***

That's interesting. When I was working for the CIA, we found that animals could often survive travel through the *flesh interfaces* much better than humans could. We regularly had success sending dogs and cats through. Somebody hit upon the idea of sending some *Gracula religiosa* (hill myna) through the interface, because they are adept at imitating sounds. This was the next best thing to sending a tape recorder (the interfaces did not accept non-living objects. We worked on grafting a tape recorder to a turtle, but this was unsuccessful on several levels.)

We sent the birds through, and they returned unencased but covered with the typical fluids. Those of us who subscribed the the alien theory had high hopes that they would record alien speech. Instead (or indeed) they came back imitating a strange flute-like "speech music." The music was quite interesting, though having all the birds sing at once created **distinctly** unpleasant effect. Somebody in the department ended up killing all the birds, though we never found out who.
___

___
***#32: comment @ [2016-04-30 08:04:24 UTC](https://www.reddit.com/r/todayilearned/comments/4h2t5c/til_that_the_red_liquid_in_a_rare_steak_isnt/d2n4wr0)***

After the orbital arrays incinerated the city, they dropped our platoon in to take a look around.

We had seen it before. An endless graveyard. Everything ashes. Ash buildings. Ash people.

For six days, we trudged through the dead city before finding the first sign of life.

On the edge of the blast zone, before frozen winter fields, a small flowering bush.

Perhaps the heat of the bombardment had tricked it into blooming early.

We all looked at it for a silent moment and quickly moved on.

We were young and tired and just miles from the rendezvous. 

Yet sometimes at night that silent moment returns.

And I see them fluttering again.

In the cold uncaring wind.

Doomed flowers.

Soft and pale.
___

___
***#33: comment @ [2016-05-02 06:47:49 UTC](https://www.reddit.com/r/todayilearned/comments/4hdu52/til_that_after_flights_were_grounded_on_911_one/d2pdpft)***

Of all the children who had been returned from the portals, only one survived in the long term, though we didn't even realize it until years later. She had been stolen (or rescued) from us by a rogue technician shortly after return and was thus lost to us for many years. We finally found her in Estonia and kidnapped her from her adoptive family in the middle of the night. She was seven when we lost her and thirteen when we found her again.

We did a preliminary interview, and she seemed normal in every respect. Mind you, this was a girl who entered a massive, possibly alien, biological device called a *flesh interface*, disappeared from existence for several minutes, then returned incased in an amniotic sac, attached to a placenta via umbilical cord with enough LSD in her bloodstream to turn all of Utah in one massive orgy. Naturally, we expected some sort of mental changes, especially since every child who returned from the portals had showed signs of mental aberration. Then again, every other child had died shortly after return, so she was clearly something special.

But no, she was normal. Frustratingly normal. So we started prying into her past. She was reticent, but young and fairly trusting, and it wasn't hard to get information out of her. She said she was born in Brazil, which was correct. We had acquired her from a Brazilian orphanage where she had lived since infancy, the daughter of a dead prostitute and an unknown father. She vaguely remembered her time at the orphanage, and they were not very happy memories. She then began telling us about the first day she met her adoptive parents. But we wanted to know about the time in between, when she was in our possession, when she went into the portal and came back.

We asked what happened before she met her adoptive parents. She said she remembered a long, boring boat trip to come over to the Estonian islands. We asked her where she had lived before then. At this question, she grew distinctly uncomfortable. She said she didn't really remember. We pressed her. Her face began to twitch and shudder. This was the first time she had showed any sign of abnormality. We kept pressing her on the question.

"There was one summer," she said quietly. "After I moved out of the orphanage, but before I came to Estonia... When I lived with a woman who said she was my mother."

This was news to us. Our files had it that she had lived continuously at the orphanage. We asked her about the exact time, but all she knew that it was for one summer. This was curious, because she had been in our possession one summer seven years ago. The timelines matched well, but the events were entirely different.

We asked her to elaborate. She said that one day a woman had come to the orphanage saying that she was her mother, and the Americans who ran the place had made her go with the woman. They had gone to a crummy old house, and she lived there for the summer. As she said this, she began to sob. She said that she had forgotten all about this, that she hardly remembered it at all, that she didn't want to talk about it. "She wasn't my mother. I knew. Her face wasn't right. It wasn't a real face."
___

___
***#34: comment @ [2016-05-03 01:58:38 UTC](https://www.reddit.com/r/WritingPrompts/comments/4hkmj5/wp_congratulations_you_have_a_unique_abilityan/d2qhsqx)***

*Oh no. This one is real.*

This is always the first thought when waking up after a blackout. After hours of flitting between different varieties of nightmare, you start to dream that you are lying sick and insane in a stained bed in a shithole apartment that smells like cigarettes and spoiled ham. Your slowly crystallizing consciousness begins to note that this particular nightmare is more persistent than the others, that it has a certain uncanny clarity to it. *Oh no*, you realize, *this one is real*.

You wake to the utter ugliness of your reality. It is too much. Too awful. What is the last thing you remember? God, it wasn't even midnight before the madness set in. You look at your hands. A tiny vibration runs through the fingers. Your entire mind feels like the raw meaty patch that is left after a fingernail is torn off. How many hours were you blacked out? Three? Four?

You sit up and look around for evidence of mischief: smashed plates, bags of take-out food, a nightstand drawer filled with vomit. All clear. You feel your face for bruises. Nothing major. Wallet and phone? Present and accounted for. Your phone says it's 2 PM. Not bad. You check the calls and texts. Nothing unusual. No two hour conversation with your boss starting at 5 AM. You log in to your bank website and take a look. $94.56 spent last night. A king's ransom by your standards, but at least you didn't go on a $400 blow-out.

You sit and wonder why you have this feeling of black guilt in your stomach. It's just the hangover, right? Just your poor brain snapping back from all the depressant you gave it last night, entering a hyper-vigilant state, a paranoid state, an intolerable state. God, you need a drink. You deserve a drink for not blowing the rent last night. Medically, you need a drink. Just a little drink, but nothing overboard that will get you all drunk at 3 in the afternoon and blacked out again tonight.

You go out of your tiny bedroom to front part of your apartment, and your heart stops. A woman is lying asleep on your couch. Not a young woman. An old woman. A tiny old grandma with messy gray hair. Jesus what have you done? Her eyes slowly open. At least she's alive. She asks if you're OK now. You nod. The question is sinister. OK now? What had been going on before? You can't deal with this without a drink. Who gives a shit if she sees, this old lady in sweatpants. You go to the freezer and get the vodka and take in two good belts. You stomach makes a violent protest, but you brain almost weeps with relief.

"Who are you?" you ask the woman directly. She smiles and lets out a shy, grandmotherly little chuckle. She says she didn't expect you to remember last night, that you had, repeatedly, warned her that you wouldn't. Her demeanor is so warm and kind, you begin to worry that you have fucked this woman, that you have fucked this elderly woman and now she is in love with you and wants to move her posture-pedic bed into your apartment. You ask her, with greater urgency, who she is, and you tip another shot into your mouth.

She says that she wants to hear the end of your story. She says that last night you came into the cafe that she owns, carrying a bottle of wine. Before she could tell you to leave, you began telling a story, a wonderful story, but you got too drunk and didn't finish it. So she got you into a cab and made sure you got home and slept on the couch because she very much wants to hear the end of  your story.

You tell her that you don't recall telling any story. She expects this. She says that it's the story about the children in the forest. You must know it, it was too wonderful to have just been made up. You shrug. You don't know any stories about any children in the forest. Unless it's Hansel and Gretel. Was it Hansel and Gretel? It was not. Well, that's the only child/forest story you know.

She tells you that it was a very beautiful story and it made her cry and she very much wants to know the end of it. Your mind churns through the possibilities: this woman is crazy, she is about to ask for money, she is going to rob you, she wants to get your information so she can have you arrested, the cops are already on their way and she's stalling. But the pleading look in her eyes is quite convincing. She does just want to hear the story. The vodka is starting loosen the paranoia's grip. You take another sip. How many drinks was that? Two? OK, don't want to get too drunk too early. No more drinking for the next hour. You take another sip. If you can't drink for the next hour, you'll need that last sip.

You sit down on the couch next to her. The sweet relief of the vodka is melting away some of your anxiety, and you let out a big sigh. You ask her to tell you some of the story, maybe it will jog your memory. She insists that she can't tell it as good as you told it, but you brush her protests aside. She begins to tell you the story.

In her warm grandmotherly voice, she begins to tell you about the magical children who lived in the forest, who danced and sang and never died, who fought bravely against the nightmare forces of the ancient queen. It really is a beautiful story, and the woman tells it so well, with lots of nice little touches that make you giggle softly. You see in your mind for a moment the sunlight through the fluttering leaves and smell the apple-scented air, so much sweeter and freer than anything your tiny grim shithole apartment full of empty bottles. And once again your eyes grow damp. You have heard, from various people at various times, the beginning of this story, but you have never heard the end. Perhaps it has none.
___

___
***#35: comment @ [2016-05-03 06:32:44 UTC](https://www.reddit.com/r/AskReddit/comments/4hjbhg/they_say_everyones_fighting_a_battle_you_dont/d2qqj3e)***

Imagine a dead cat wearing an old jock strap. This is the smell of the bed sores. This is the smell that comes out of the hygiene beds when we open them up. It's not just a smell but a feeling -- a sickly warmth that the masks cannot block out. Even through the filtered, scented air, you know it's there, coming through the filters in <.1 micrometer sized particles, touching your face, touching your clothes, adhering to you, fouling you, fouling everything it touches.

I think what makes the smell so putrid is that it's a combination of living tissue and dead tissue. Somehow this unnatural intermingling of life and death creates a potent stench that is repellant to basic human sensibility. This is why I am saving up to go to school and become a Readjustment Specialist. Pulling people out of malfunctioning hygiene beds is no way to make living. Certainly it is not the calling of a sensitive, erudite soul such as myself.

When a hygiene bed breaks (say, the Healthy Limb System fails, or a catheter gets blocked up), it's supposed to cut off the internet feed, forcing the sleeper to get the bed fixed. But it's easy enough to override this cut-off function. Immersed in their feeds, people often forget that the bed is broken. But eventually pain or discomfort will force the sleeper to get their bed fixed. The pain of bedsores or the stench of a backed-up evacuator is a strong motivator. But if the sleeper has direct sense feeds, they can switch off these smells and discomforts. They can even switch off the worry associated with the broken bed.

At this point there is only one thing which can impel them to save themselves: basic human dignity. The age-old desire to not spend one's days playing Princess Romance Cafe, lying in one's own shit while one's dick rots off. (I would also say that an occasional fleeting desire to see the outside world could also prove advantageous, but for the sort of people I'm talking about here, this is simply not a factor.)

Sadly, for some people, this desire is not strong enough, and we come to the very last line of defense: the smell. The smell eventually leaks out of the hygiene bed's encasement, and nearby tenants start to notice. The building manager calls us, and we go and pull them out. For the most hardcore sleepers, those who have entirely rejected reality in favor of their feeds, it is the smell and the smell alone that saves their lives before the bacteria devour them alive. It is the stinky hand of salvation that plucks them from the abyss.

I don't know what God looks like. But he smells like a dead cat wearing an old jock strap.
___

___
***#36: comment @ [2016-05-04 08:03:41 UTC](https://www.reddit.com/r/Jokes/comments/4hs8al/why_did_cruz_pick_carly_fiorina_as_his_running/d2s6z0w)***

How quickly they turn to complete animals. They come out of the wagons already quite bestial, crying and lowing for water, yet there is still the facsimile of humanity about them: they wear clothes, spectacles, wedding rings, the women have their long hair and jewelry. We strip away all this deceit quite quickly.

At the front of the camp there is a phony train station with a phony name and a phony clock with hands that are painted on. All of it is just as phony as all their posing, their insinuating, their pretending to be  normal folk. As soon as they come down the ramp, the blue prisoner units are screaming at them, beating them, lashing them, drawing blood, and they move through the front gates in huddled, weeping herds. There we separate the men and women and have the women's hair cut to make socks and such.

And in a moment, it is complete. Centuries of hiding among us, posing and passing, is all erased, exposed, and their nature is plain. Looking at their hideous gnarled faces, all the varieties of bloodline impurities, the women's sagging udders, the fatty hanging bellies, the men's mutilated penises in thatches of pubic hair -- you see it quite clearly, and you absolutely cannot deny that they are utter beasts. That we allowed them to infest our cities like vermin, to hold power over us, while we were tilling the soil and building the Fatherland -- it absolutely appalls. This will be our great shame in history's eyes.

We move them through the long tube to the gas chambers. The men can go first, as their hair does not need cutting. Then the women. The women panic. Screams everywhere. You watch the mottled haunches of the old women shudder and ripple as their legs shake like newborn calves. They realize that we will not be wasting any time, that it will all be immediate. Streams of fresh shit run down their legs, and now the helpers must club them every step of the way or they will turn back.

Marchenko carries a sword. He thinks it is an Imperial cavalry sword, but it is just an imitation. Still, it is an actual sword, and in his hands, it is more effective than the clubs. He hacks at the crowd like jungle explorer in an American film. He makes all sorts of sneering, dramatic faces as he works, and whenever he scores a particularly impressive blow, his whole face red with delight. Once he sliced an old woman's tit clean off. He picked it up and showed it to me. The inside was made of corn-colored pearls of fat. I let him take it to the work camp and have a good chuckle watching a prisoner devour it, and I had a good chuckle watching Marchenko's face.

There are only a couple dozen SS at the camp. Almost everything is run by Red Army watchmen and special prison units. And yet we can process 15,000 a day. Wonderful. It is because of the way the camp has been built. There is the fake train station, the tales of showers and uniforms and assignments, the narrow tube to funnel people into, the walls to hide the chambers and the pits. And there is the hierarchy: the captured Red army men and the special unit prisoners, all set against each other with the proper incentives. Everything in the structure concentrates power on us.

Perhaps, if the right structure was built, an entire race could eliminated by a single man with an unloaded gun.
___

___
***#37: comment @ [2016-05-05 07:05:35 UTC](https://www.reddit.com/r/DIY/comments/4hyfph/i_built_a_world_map_dining_room_table/d2tj88l)***

Consider this case:

A woman. 28 years old. Lives in a bed-rack apartment block in Alabama. She has engaged in heavy feed use since childhood, spending 70 to 80% of her free time connected. At age 16 she finds global success as mix guide, netting her a considerable sum of money. One day, when she is 19 years old, she connects to her feed. She does not disconnect again for 9 years.

9 years of continuous feed. 9 years without any direct human contact. 9 years alone in a hygiene bed. Dreaming.

Meanwhile, her feed is a veritable flurry of digital contact: mixes, life stories, role swaps, rooms, hunts, avatar makers, empathy games, sex play, and on and on. For a while, her mix tours sell well, and she enjoys her celebrity. But over the years, tastes changes, and her income falls. Try as she might, she cannot revive her popularity. She tries sortieing, tutoring, crowd matching, whatever will make her money. But the competition in these markets is harsh, and she has significant debts to several promotion companies. Her money runs out. She manages to credit bounce for a while, but the writing is on the wall: she must disconnect.

She knows this, yet she cannot bring herself to do it. Within the feeds she is well-liked by her spheres, known as a talented mixer and narrator, a reasonable wall mediator and a sensitive and capable participant in sex play. But she has a direct sense feed with complete safety overrides, and she has been on increasing pain dampening for the last 4 years. She knows she has bed sores and perhaps will need multiple amputations. She has assumed that she will live feed-to-grave, and cannot bring herself disconnect.

She researches cortical suicide methods but decides against it. She contacts emergency services and arranges for them to remove her from her hygiene bed. One day shortly after her 28th birthday she is disconnected after a 9 year dream. She awakes to a world of horrifying pain. Pain dampening has blocked her opioid receptors, and the removal technicians can do nothing for her agony. Her entire body is atrophied and she has severe calcification around her ports, catheter and evacuator, as well as numerous sores and abscesses and general muscle atrophy.

She is taken to the hospital for physical rehabilitation. After several operations, she is stabilized and her pain has subsided to manageable levels. Thankfully, her limbs are still intact. After eye treatments, she looks at herself in the mirror and finds something she does not recognize. She has aged 9 years, though a lack of sun exposure and facial expressions has left her face smooth and unlined, albeit inhumanly gaunt and pale. Within a few days, the hospital sends her home. She must use a scooter to return to her apartment, which is little more than weatherproof box to contain her hygiene bed.

What will become of this woman? Sitting alone in her apartment with no job and no touch-friends, without even a bathroom other than the hygiene bed, she will find it very difficult to resist the lure of the feed. The lack of stimulation will mean that she is often bored. The lack of predictability will mean that she is anxious whenever she is not bored. She will find unmediated socializing torturous. According to our statistics, there will be a 90% chance of her making another long-term connection within a month. There will be a 30% chance of her dying within 1 year.

This the price of long-term connection: it is inescapable. Less than 1% of users connected continuously for more than 3 years are able to go on to lead successful disconnected lives. In America, there are currently over 30 million users on long term connections. Unless something changes, they will stay connected until they die.

This is why we have created COMPANION-12.
___

___
***#38: submission @ [2016-05-05 22:29:39 UTC](https://www.reddit.com/r/cats/comments/4i2bmw/our_form_is_our_story_the_story_of_all_the_world/)***

The world does not sleep.

Everywhere, ten thousand things are darting, skittering, flitting, scuttling, burrowing.

Sleep is righteousness.

But the world wakes.

We are made in the image of the world. The world is a giant of the our kind, and we live on its back. Its trees and grasses and hills are like the hairs on our backs. Our paws are soft and our ways are subtle and silky, so we are in harmony with the world. But everywhere, ten thousand things are scuttling, out of harmony. And this causes the world to itch and suffer, just as the little scuttling things on our backs cause us to itch and suffer. So the world cannot sleep, and everything turns and spins, and we cannot sleep. For we made in the image of the world.

This is why we hunt. It is our duty. To hunt out all the little scuttling things, to devour them, expel them, and bury them back into the world, leaving no trace. We must hunt night and day. We hunt the ten thousand things on the world's back just as we hunt and clean the little scuttling things from our own backs. One day we will destroy all the ten thousand things, and the world will sleep, and we will sleep, and everything will sleep forever. This will be a great righteousness. We can feel this righteousness every time we sleep. And we can feel a great injustice every time we are woken. So we hunt. So we must hunt.

This truth is in our bones, in our claws, in our form, for we are made in the image of the world, and our form contains all truth.

Our form is our story.

The story of all the world.

But now we are confronted with a great mystery.

We do not abide mysteries. They plague our sleep. We must solve them. What is hidden must be uncovered. So we search and sleuth, but this mystery eludes. It scuttles and slips away, time after time. And we do not sleep. But it seems there is no message in our form which gives us any answer. Is our form incomplete?

I above all others have become obsessed the mystery. The mystery of the Oily Ones.
___

___
***#39: comment @ [2016-05-06 23:12:20 UTC](https://www.reddit.com/r/Jokes/comments/4i5p7u/i_told_god_a_holocaust_joke_he_didnt_laugh/d2vrmx0)***

One day during the final summer, a team of doctors came in from Berlin. They were in the midst of a grand experiment which they considered to be of the utmost importance and needed access to a large number of prisoners, something beyond what they could acquire in Berlin. We protested that we were not equipped for any sort of medical experiments, that our camp was designed for a single purpose, but they insisted, and we were forced to accommodate them.

I was immediately irritated by their senior doctor, a haughty man in his late forties named Engel who always wore a crisp white coat and fine leather shoes. He arrived with his team of doctors and-- I could scarcely believe it -- a Jew.

This was perhaps the ugliest Jew to have ever personally offended my eyes. He was a very tall man, a full head taller than average, with a furry black beard, a gnarled, claw-like nose, and very prominent eyes. These eyes were something of a source of fascination to me, as they were not the rat-like black color of the normal Jew, but a much lighter shade of brown, almost like bronze. He wore a shabby suit and followed Engel around quite closely, almost as if they were associates, and always his strange, flashing eyes were roaming about in a suspicious way.

When I first met Engel, I asked who this Jew was, but my question was brushed aside. They immediately set about converting one of our buildings into a station for their experiments, the details of which were kept from me entirely. Engel and his team made no contact with the other staff except to demand various supplies.

After a few days of being subjected to Engel's imperious behavior, I could feel that my SS subordinates and even the Ukrainians were smirking at me behind my back, so I decided to give Engel a tour of the other part of the camp, which he had not yet seen, the part where we processed prisoners. Of course he refused, but I insisted. Fortunately, a trainload of prisoners was arriving at the moment, and we went out to the platform. The odious Jew with glittering eyes followed us, which pleased me all the more.

The train arrived with the cries of its passengers blending into the squealing of the metal wheels. The blue units worked themselves into their usual frenzy, pulling the passengers out, shouting and clubbing and herding them toward the main gate. Amidst the crush of passengers, the limp bodies of children occasionally came spilling out onto the platform, and the blue units tossed them into a pile. Engel watched all of this impassively.

A woman came out of the train clutching a child of perhaps three years. She looked about frantically, screaming for a doctor. I gave her a sympathetic look and held out my arms. She approached me, the handsome stolid-looking authority figure that I am. I took the child from her and tenderly examined it. It was still alive. I placed it gently on the ground and used my boot to reshape its skull. The woman I shot.
___

___
***#40: comment @ [2016-05-07 05:48:41 UTC](https://www.reddit.com/r/WritingPrompts/comments/4i8sg0/wp_dreams_are_a_manifestation_of_your_desires/d2w3kfa)***

V.O. SCRIPT:

Rachel does not dream. Rachel does not sleep. Rachel does not wake.

Rachel feels! All the time!

Rachel Head has a direct sense feed with Reinhardt Emotive FPS Blending™ for stunning clarity and total sensory presence. With the entire cultural library at her fingertips, Rachel can put herself into any scenario and create precision mixes at speed-of-mind. Watch as she blends Beethoven's 5th Symphony with the asteroid orbital catalogue, the 2018 World Cup game and the hot new anal cumming video from Angelica Eleenya.

What mastery!

See the subtle crafting and non-stuttering blends?

That's because Reinhardt's proprietary technology blend-splits 240 visual FPS on the fly to create an eye-popping visual stream of over 1000 FPS, while simultaneously delivering 60 tactile FPS and 60 olfactory FPS. Now this is salvation!

But, hey, forget the specs. Check out the feelings! Her Holocaust Child Victim Disco Muscle Thumps have walls around the world shedding tears and making those real feels. You can't fake this stuff! Are you tired of distant, deadened emotions? Reinhardt Emotive FPS Blending™ give you realistic, immersive feelings, without excess rumination or thought-linger. This kind of subtlety just isn't possible at ordinary 240 FPS. That's the difference for Rachel. That can be the difference for you.

Rachel does not dream. Rachel does not sleep. Rachel does not live. Rachel does not die.

Rachel feels.

Can you?
___

___
***#41: comment @ [2016-05-07 20:50:23 UTC](https://www.reddit.com/r/movies/comments/4ia0j9/top_recent_films_that_explore_the_nature_of/d2wpujq)***

After a week at the camp, Dr. Engel put in a rather perverse request: he wanted to move his laboratory to the old gas chamber. I had no problem with this. We had installed new, more efficient gas chambers with the help of an expert on the matter, and although they had a capacity of over 20,000 a day, we were seldom ever able to process more than 15,000 in a single day, due to the unreliability of the trains, which were often slow enough to preemptively process many of their passengers for us.

At this point we had orders to cremate the bodies, and they burned in open pits day and night, and we warned the Dr. Engel that the old gas chamber would be a rather distracting environment to work in, as it was between the smoke of the burning pits and the noise of the new gas chambers. He disregarded this, and his team moved in that day. After that, I rarely saw him, as that part of the camp was somewhat hidden from the rest, and my headaches, which were growing more severe, had always made me reluctant to visit. 

Soon my men began to me strange tales from the new laboratory. Nobody except Engel and his men was allowed inside, but we surmised that he had removed or reduced the chamber's interior walls and sealed up all doors except one. He requested his own SS detail, and two guards were posted at the door at all times. A steady flow of prisoners went into the laboratory, whom Engel selected with the help of his odious Jew assistant, often to the great irritation of my units, as their fussy selectivity often slowed down our processing activities. Nobody could make any sense of his selection process, as it mainly consisted of the Jew looking the person over and making various mutterings.

It was reported that every few days, a enormous "package" wrapped in tarpaulin would be removed from the laboratory and carried over to a special burning pit which they had made. These packages tended to bleed, leaving a trail of blood to the burning pit, where they were burned under the watch of Engel's personal guard. This behavior was only extraordinary in that there was no need for secrecy when it came to killing prisoners. Thousands were being killed every day just a few meters away in the new gas chambers.

Between this and the inexplicable presence of the Jew assistant, I slowly became curious about their project. My men, however, were unable to get any information about what was occurring inside the laboratory. So I decided focus a few questions on the member of the team who presumably had the least sense of loyalty: the Jew.

On one of our days off, I found the Jew in our little zoo, admiring the peacocks. He looked very much at peace as he watched the birds strut around, while I was suffering from vicious headache. I began to talk to him, affecting an offhand, friendly manner. His German was perfect. I asked him about his background. He told me he had been a religious student in Berlin until he was expelled to a ghetto in Krakow. I asked him how he had met Engel. Here he told me something quite surprising: this was actually his second time coming to Treblinka. On his first visit, he was on the very verge of being shot when somebody had noticed his perfect German. Apparently, there had been a request for prisoners who spoke excellent German, and this earned him a reprieve. He was sent back to Berlin, where Engel performed tests on him.

I asked about the nature of these tests. At this he became more reticent. He had been instructed to discuss nothing with me. I merely informed him that I would shoot him through the face if he didn't tell me everything. At this, he showed no fear, but looked at me with his odd, brazen eyes and gave me an almost pitying smile. He said that the doctors were testing a new Swiss invention, some kind of chemical which was administered orally and caused profound changes in thinking.

I asked him about these changes. He said that the chemical allowed him to see the mind of God. Naturally, I asked for elaboration. At this, he launched into a rather overworked simile involving a broken mirror, then switched to another simile using a spider's web, neither of which made any sense to me. I informed him that I was a practical man and had little use for philosophy. He told me that after taking the chemical many times, he had become possessed of two minds: his own and that of God. In all his doings, he was conscious of God's intentions, of God's plan for all human life. I asked him if he was following God's plan, and he said he was not following it entirely.

"I am wrestling with God," he said cryptically.

"How does one wrestle with God? Isn't he all powerful?"

"When God presses forward, you must yield or be destroyed. And when God yields, you must press forward."

"That sounds more like dancing than wrestling. Or making love," I said with a snort.

He smiled. "Yes, it is... Except that dancing is not so painful."

"Why wrestle at all? If God is God, and you know his plan, why not simply follow it? Surely this is the best course."

"Yes, but I cannot bring myself to," he said. For the first time, I saw the peaceful expression flee from his face to be replaced by a unsettling dread that trembled in his eyes. "God's plan... is simply too awful."
___

___
***#42: comment @ [2016-05-08 04:15:23 UTC](https://www.reddit.com/r/gaming/comments/4icfmg/saw_this_awesome_bumper_sticker_on_the_way_to/d2x3sm6)***

Imagine Mother Babylon. Mother Rome. Mother America.

The world enslaved. Flesh networks spanning the globe. The blood of humanity moving through veins thousands of miles long, cavernous curving tubes as big as super highways. Biological superstructures. Bones the size of the Golden Gate Bridge. Living engineering. Hearts as big as mountains, pumping with tectonic force, chained in relays, moving blood across continents. Exotic neurochemical pestilence flowing from monstrous glandular ridges. Flesh encased nightmares. Farms of non-human tongues babbling blasphemous gibberish. A vast sea bed dotted with lonely eyes.

This is the great Queendom of Babylon. A great blood-drunk whore wearing the Crown of the Atom, as all around her fleshly carapace float orbital platforms of nuclear death.

Scattered in the stars beyond, the seeds of Israel weep to gaze upon their new mother: The Undying Queen of Blood and Corruption.
___

___
***#43: comment @ [2016-05-09 00:07:21 UTC](https://www.reddit.com/r/funny/comments/4ifeyr/potty_training/d2y092y)***

The worst thing a black man can do is go to church on Sunday. We're not supposed to do that. In the old days, before Jesus paid for our sins, we'd be put to death for idolatry. But now you see them all dressed up in their suits, and the girls are in dresses with their booty all hanging out. They got the cootchie hanging out of the dress. At church! They going in there like it's a club. That's not what God wants. He wants us to dress modestly. Because we are God's chosen people.

But they don't know this. They eating crabs and shrimp, shrimp platters, going to Red Lobster, all you can eat shrimp, $9.99. They don't follow the law. Then they go into church and worship this picture of a white Jesus. That's idolatry. That picture of Jesus with the long, soft hair, the good hair, that's not Jesus. That's actually man named Cesare Borgia. The real Jesus had curly hair. Black hair. Because he was black. He was a Jew.

You have to understand what's going on in the world. Right now they have satellites in space, and they have weapon systems, atom bombs, everything. And which way they pointed? They not pointed down here on earth. They pointed out into space. Why? Because the nations of the world, America, the U.N., they're all waiting for something to come from space. Watch. It's coming. And they're gonna try to destroy it. The battle of Jehoshaphat.

See. There is a thread. A line through history. The Egyptians. The Babylonians. The Romans. America. The slave owners. It's all one.

Do you know who the Nephilim are? They're mentioned in the Bible, but only twice. You have to understand the mystery of the Bible to understand what they are. 

The first time they get mentioned is in the story of the flood. It says in Genesis 6:4, "There were giants in the earth in those days; and also after that, when the sons of God came in unto the daughters of men, and they bare children to them, the same became mighty men which were of old, men of renown." These 'giants' were Nephilim. Nephilim is the original Hebrew word in the Torah. You have to understand Hebrew to know the mystery of the Bible.

Nephilim are the children of the "sons of God," who are fallen angels. Angels came down and had sex with human women and they gave birth to Nephilim, people who were half man and half angel. The angels looked down, saw the people, the original man, the black women, the nice bodies, the nice booties, the thick legs, and they got them a piece of that. I'm serious. They said, "We angels. We can do what we want." So they got some.

A little later in Genesis 6:12 it says, "And God looked upon the earth, and, behold, it was corrupt; for all flesh had corrupted his way upon the earth. And God said unto Noah, The end of all flesh is come before me; for the earth is filled with violence through them; and, behold, I will destroy them with the earth." That is how the flood came about. All this mixing of flesh.

Now what if I told you that the children of the Nephilim are still among us? That they are renowned, as the scripture say? That our scientists, our bankers, our leaders, our inventors, are Nephilim. Bill Gates. Albert Einstein. Steve Jobs. These men are part fallen angels. And they are corrupting the flesh, like the Bible say, by doing all this gene splicing and mixing chromosomes. Because they're made from mixed flesh, between angel and human. So they're all for everybody mixing. Men with men. Girls and girls. Whatever. Pretty soon, you gonna see chicks with two heads walking down the street. And we supposed to say it's cool.

I won't say no more because I don't want to get banned. The Nephilim control the internet. I'll just say I seen it myself. I seen how they mix the flesh. Experiments. The government. Making new things. It's out there.
___

___
***#44: comment @ [2016-05-09 03:07:27 UTC](https://www.reddit.com/r/AskReddit/comments/4ifsst/which_profession_has_absolutely_no_room_for_any/d2y6h4m)***

In the training curriculum for becoming an Readjustment Specialist, they omit fingerblasting entirely.  Which is odd, considering what a routine part of the job it is. I can't tell you how many times I have been in the middle of a conversation with a client only to have her slip her finger into her shorts and start diddling away.

My clients, long-term session-heads i.e. people who have been connected to a direct sense feed for multi-year spans, are practically feral. Even though the feeds are supposed to be all about empathy and social connection, everything is so mediated that they lose the capacity for normal social interaction. If their session begins at an early enough age or goes on long enough, shit gets truly weird.

The readjustment client is a stimulation addict. They crave easy, immediate stimulation. Some turn to drug use, but they usually require near-lethal or outright lethal amounts to properly stimulate themselves. Others turn to masturbation. The readjustment client has no patience. If they are uncomfortable, they want immediate relief. If that entails a indiscreet bout of onanism, then so be it.

Almost all my clients are women. The female clients tend to choose male specialists, and the male clients tend to choose female specialists. In the feeds, they often surround themselves with a coteries of admirers of the opposite sex. So they insist on opposite-sex specialists. This is an unhealthy impulse, but we must meet our clients halfway. Our job is to slowly transition them away from being fake adoration-sponges into being functioning adults.

I am not a doctor. I am not a therapist. I am trained to think of myself as a paid big brother. Perhaps there is an inherent contradiction. I must be stern without being overly judgmental. I must be empathetic but effective. I can't coddle them. The feed coddles them. That must end.

The work could be described as Sisyphean. Trying to re-culture a person after years of all that whiz-bang feed stimulation is like pushing a heavy boulder up a hill. And occasionally the boulder is masturbating.
___

___
***#45: comment @ [2016-05-09 23:07:26 UTC](https://www.reddit.com/r/gifs/comments/4ilapw/for_everyone_who_wanted_to_see_the_actual/d2z7yi7)***

I asked the Jew exactly what sort of procedures they were performing in their laboratory, but at this point we were interrupted by several members of Dr. Engel's team, and they hurriedly ushered him away. Although there were still many unanswered questions, my curiosity was largely satisfied. They were testing a new chemical and probably performing vivisections and such to ascertain its physical effects. Perhaps the bodies were burned separately because they required special handling due to the presence of the chemical. There was nothing especially sinister in that. It was actually rather considerate of them.

That night, shortly before I was about to retire for the day, one of the Ukrainians came to me with a small package wrapped in cloth, about the size of a loaf of bread with an irregular shape. He was very excited. He unwrapped the package, and inside was a fragment of pale white bone. An extremely unusual fragment. It was a sort of rounded carapace, like part of a giant skull, but with 5 round holes in it, much like eye sockets but obviously too numerous to be so. Studded throughout the fragment were extrusions that looked like molar teeth. Looking at it, I could not place it as a part of any animal I had ever seen.

I asked the man where he got it, and he said he had retrieved it from near the laboratory's cremation pit just an hour before. The piece itself did not appear to have been burned, as it had the meaty stink of death about it. I asked him a few more questions, but he knew little else. Still, he insisted that the bone fragment was from something monstrous and unnatural which they were creating in their laboratory and that I should shut down their experiments. One of my SS subordinates immediately set to thrashing the Ukrainian with a baton for presuming to advise me on my duties, and with that, the conversation came to its natural conclusion.

I took the fragment with me and spent a while in turning it over in the dim lamplight of my quarters. It was indeed otherworldly, and, as the Ukrainian had said with a kind of wild fear in his eyes, it was truly monstrous. Despite the Ukrainian's impudence, I decided to take his advice. This had all gone too far. Whatever the high command might say, I mustn't let this camp be overrun by secretive madness, but must maintain a spirit of rational cooperation. I would insist on full inspection of the laboratory first thing tomorrow morning.

 I lay down to sleep and was soon visited with a dream so intense that I did not feel like I was sleeping at all. At first, the bed in which I lay seemed to rise up from the floor and float ever upward through a large, glowing tunnel which was painted with all manner of designs, from paisley to topographical lines to various kinds of calligraphy in unknown languages. After this, the dream became a series of absurd images ever changing and blending into new images and shapes. Many of these shifts struck me as clever or absurd, and I found myself laughing maniacally at it all.

Finally, all of these disparate images appeared at once before me and began to rotate around each other as part of a fantastic wheel, and slowly I began to suspect that by combining them all, some sort or grand secret would be revealed. Just as this notion occurred to me, all the images began to coalesce into one final image of stunning clarity.

It was the image of a woman, or something which was mainly a woman but also other creatures, who was vastly large and seemed to tower over me miles in the sky, who looked down on me with filmy inhuman eyes. Her skin was an inhumanly pale, but she wore a crown of exquisite thorned flowers, and blood ran in shimmering red streams down her skin. She was pregnant, vastly pregnant, with a stomach so swollen it was like she sat upon a huge mountain of distended flesh. I could sense within her belly there was a hive of activity, of something or many things pulsing and squirming feverishly. Soon the belly burst open like a ripe fruit, and rivers of blood poured out, and a revolting mass of fleshy tubes came spilling out, unraveling and tearing open to set free hundreds and thousands of monstrous infants who were both human and not human, who had the same filmy eyes as their mother, who were slathered and dripping with blood.
___

___
***#46: comment @ [2016-05-10 06:38:32 UTC](https://www.reddit.com/r/sports/comments/4ilim7/kyrie_irving_glitch_xpost_rnba/d2zn8xr)***

The Oily Ones lack all harmony. They are neither silky nor subtle. They are slow and stupid. And loud. Evilly loud! Arrogantly, thoughtlessly, senselessly loud. Night and day, they make noise. Their unnatural things make noise. They cry to each other like kittens. They are far larger and stronger than any of our kind, but they are more hairless than the newly born, and they cry like hungry whelps. It is evil. It is abomination.

They make dead things live. Things which do not have the smell of life should not live! But these things are touched by the Oily Ones, and they live and move. This is evil, unnatural magic. Their unnatural things come in all different shapes, and contain deadly mysteries and tricks and traps. Some are invisible. Some are faster than sight. Some never sleep. Some cut and claw. These unnatural things lack all harmony, like the Oily Ones themselves.

I've seen the deadly darkness of the their magic. I've our kind crushed and smeared by their things. I've seen our kind disappear inside their things, never to be seen again. Once, I saw a kitten who was struck by their magic, who made bloody foam from the mouth for three days, who died in agony.

Yes, I have known sleeplessness.

I know them as evil. And this would seem to be all, but there is more. There is more. There is mystery. 

There is the mysterious smell of the oily ones, the smell by which we know them. It is both awful and alluring, disgusting and entrancing. It smells like the sweet oily fat that coats the heart of a pigeon, the best part of the flesh. We find ourselves drawn to it, drawn to them. And there is their food, which can contain dark magic, but also feeds many of us, and truly tastes wonderful and righteous, and does not scuttle but always sleeps and is easy to hunt.

Even more mysteriousness is their kindness. For it is they, they alone of all the living things, who show our kind any affection, who bring us food, as if we are their young.

As if they are our mother.

How could this be? How could these evil beings show us affection? How could they show us more affection than the world itself, who is of our kind? This is the central mystery. Ever since my kitten died, this has become my obsession.

 I have watched them closely. I have looked into the strange places where they hide, where they appear and disappear, the places full of mysterious lights and smells and ten thousand forms of evil and wickedness. If I am to capture this mystery, if I am to feed on its sweet, oily heart, I must go inside one of these places. I must go through one of their portals.
___

___
***#47: comment @ [2016-05-10 23:08:47 UTC](https://www.reddit.com/r/books/comments/4ip0vq/the_editor_of_bookslut_talks_about_the_current/d30licm)***

I sit in my room, watching bright specks of dust float through the sunlight from the window. The summer heat is pressed against the glass. Somewhere down the street, a lawnmower whines. The air is stale. The corners of the room are filled with damp shadows. My toys lie on the floor, scattered.

I hear the fractured music down the hall. A sound like wind chimes. A shudder goes through the old house, and I find myself rising. I am walking down the hallway, called to the other end. I smell her as I get closer. Foul meat. Gray hair. Stomach acid.

I walk in her room, and her bloody pieces are lying all over the floor. The strange flute music slowly coalesces into a melody, and the pieces rise and float like flies. The music charms them into formation, and they come together to make Mother. The eyes are missing, still fleshy cavities. They come in from the hallway, floating over my head, settling into her face with a squishing sound, streams of blood falling like tears. The sideways pupils fix on me.

"Child, fetch me my bag. I need flesh."

I shake my head. I hate her. She leaps to me, grabs a handful of my hair and slaps me across the face with her ragged dog's paw, again and again. I scream and cry. She lets me go. Sobbing, I go to the closet and get her big bag. We wait until night.
___

___
***#48: comment @ [2016-05-11 08:12:36 UTC](https://www.reddit.com/r/ik_ihe/comments/4ir7zh/ik_ihe/d312ga5)***

I call it "coming back online."

That moment when you first come out of drunken blackout. It's always frightening. Where am I? What is this neighborhood? What happened to my face? Where's my wallet? Some people, when they drink enough to disable their short term memory, immediately collapse into an immobile heap. This is nature's failsafe. But I lack this feature. I can walk and talk and carry a tune, yet have no idea of what's going on.

I have never come back online to find myself up to any good. I have never emerged from a blackout to find that I have built a convenient spice rack or delivered a moving speech about women's rights. It's always been some fucking calamity.

The last time I came back online, I was standing in my front yard having a conversation with my parents. Even in my tottering state, I knew this couldn't be a good thing. I had no idea what we were talking about. Why were we talking about it on the front lawn? At night? What time was it? Hoping for a clue, I waited for something to come out of my mouth. And here it was: "Didn't you notice I never left my room? I've been living with you for 6 months. I think I've seen each of you twice."

This was bad. I knew I shouldn't be saying something like this. It sounded terribly confessional. Ever since I had gotten fired and moved back in with my parents, I had been holed in my childhood bedroom, secretly drinking and basking in an unremitting sense of personal shame. But this was all supposed to be a secret. As far as my parents knew, I was freelancing and "getting back on my feet." This scene, this mad scene, was not part of that narrative.

"We were giving you your privacy. We didn't know you were getting drunk up there," my mother said.

This conversation was out of control. I should just tell them I'm going to bed. I should calmly bid them a good night. So I said, "Of course I was getting drunk! Fuck! I've been drinking every goddamn day for the last ten years! What the fuck else would I be doing?"

This was a poor choice of words. This was not how one calmly bids others a good night. Oh, the look on my poor mother's face...

That look stayed with me. That look, the fallen face of a tired old woman, stayed with me as I lay in bed that night. It stayed with me as  the alcohol wore off, as the night turned into queasy morning, as the hands began to shake, the "brain tingle" set in, as the "hell whispers" began, as I waited for them to go to work so I could sneak a bit of relief from the liquor cabinet, as the awful day wore on, as we talked that night, as I packed my stuff up, as I went off to rehab the next day. 

My mother is almost 70. She's small and stooped and old. When did she get so old?

I just thought I would be something by now. 33 years old. I thought I would have something to show her, something to give back, something to make her proud. I thought I'd be a man. Not just a drunken failure. All those little soccer practices she took me to, all the swim lessons and therapy and errands and effort and love. What was it for? So I could be a drunken sack of shit? Why was I so fucked up? Why did I require shore-leave levels of liquor to operate properly?

As I lay in bed in the rehab that first night, listening to the occasional moans of the other patients, I asked myself these questions and others. Soon, I found myself returning to the question I had been asking my entire life, the one I always retreated to in moments of self-pity, the one that seemed hold some key to my dysfunction. The one I had always been afraid to ask my mom.

What about that one summer when you were dead?
___

___
***#49: comment @ [2016-05-11 22:54:51 UTC](https://www.reddit.com/r/funny/comments/4iwa68/every_project_ever/d31yrnu)***

The next day, I felt under the weather. The vivid dreams of the previous night had left my mind feeling dull and exhausted. As soon as I left my quarters I was greeted with the news that one of our Ukrainians had gone mad during the night and attempted to attack Dr. Engel's team in their quarters. It was none other than the one who had brought me the strange skull fragment.

After shooting him, they had come to the conclusion that he had somehow ingested some of their magical chemical, which they referred to as the "Swiss Invention." Engels insisted that I make an announcement to the camp: anyone found ingesting this chemical under any circumstance, whether by intention or accident, will be summarily shot, regardless of whether they are prisoner or Hiwi or even SS. This was by order of the high command.

At this, I was forced to admit to myself what was already obvious: I had somehow been dosed with the chemical in handling the bone fragment. My dreams had been a reaction to the poisoning. Looking into Engel's cold blue eyes, I tried to deduce the consequences of confessing this to him. Despite his disagreeable haughtiness, he seemed like a rational, efficient man with an appropriate love of duty and country. I had no doubt that he would murder me without hesitation. I decided to keep my little nocturnal epiphany to myself.

Naturally, my curiosity in Engel's project had been aroused again. He apparently was working with a chemical which could induce temporary madness. The value of such a chemical was obvious. But what of the bizarre bone fragment? What had it come from? I couldn't help but feel that this creature, whatever it was, was somehow connected to the vision of the monstrous bloody mother. Again and again, her blood face appeared in my mind, her filmy eyes gazing down at me, inhuman and imperious.

I attempted to contact the Jew again, but after our conversation, Dr. Engel's team guarded him jealously. He was never left alone. As the hot summer days went by, my curiosity about the matter grew to obsessive proportions. The monstrous mother visited me several more times in my dreams (of the normal variety this time, but no less vivid and disturbing.) I began surreptitiously observing Engel's laboratory, which was guarded day and night, and I asked some of my men to do the same.

To our knowledge, the bloody "packages" had ceased to emerge from within, but something stranger began to happen. This new phenomenon was presumably occurring at all hours, but was imperceptible in the bustle of the day, when men were about and the gas chambers were operating. Only at night, and only when the fires were burning quietly, could it be perceived. I first observed it shortly before dawn one muggy morning.

As ridiculous as it might sound for me to be skulking about in my own camp, I did just that, slipping along the wall of the new gas chamber to come within a short distance of the laboratory. There I witnessed what others has reported to me. At fixed intervals, a sound emerged from the laboratory. It was very quiet but not just my imagination. A creaking sound. The sound that many old houses and structures make as their materials shrink and swell from temperature and moisture. But this came very regularly, every 4 or 5 seconds. Slowly, a realization crept upon me. The building was breathing. Steadily, in and out, it was breathing. It was alive.

This "realization," which I'll admit was more of an unconfirmed intuition, filled me with a dread so strong that tears came to my eyes. There was something enormous and alive inside that building. The sight of death, bloody death beyond most men's imaginings, had left me unmoved, but the sight of life, this new and unnatural life, pressing against the walls of the building, was enough to chill me. Again I saw the face of the unholy mother in mind my, saw her filmy eyes, saw a slight smile form on her lips between the streams of blood.

That night I could not sleep. Fortunately, the next day was our weekly day off, and I was able spend most of the day in my quarters. It was abnormally, intolerably hot and humid. My thoughts followed disorderly circles around the revolting image of the Mother, and I felt as if I was being revisited by the temporary madness brought on by the so-called Swiss Invention. I had long loathed life at the camp, but had accepted it as an tolerable hardship. But now the constant smell of the burning sickened me, and I felt I could take no more.

That afternoon, some of my men decided to go off to a nearby lake for a swim, and on a whim I accompanied them. I needed a reprieve from the heat. At the lake, I eased myself into the cool water and floated idly, watching the clouds pass overhead. Here, there was nothing but the gentle twittering of nature. It had been here before our murderous camp had been built, and it would be here long after. Gentle and peaceful.

I had been in water for just a few minutes when I received the news: group of prisoners had broken into the armory, smuggled weapons out, and a full-scale uprising occurring back at the camp.

The rest of the day was a whirlwind. We raced back to the camp, and I found myself personally trading fire with the prisoners, as all about buildings burned and everything was chaos. We called for reinforcements, managed to subdue the camp, and set out into the woods to catch the escapees. A fair number were intercepted, but over 100 escaped. This was an unmitigated disaster. Coming back into the camp after the hunt, I had only to look around at the faces of my men to know that I was now in a position of total disgrace.

As calamitous thoughts raced through my head, I found myself walking towards Engels' laboratory. Deep black soot stains around the front door showed me that the interior had been burned out. All around the entrance lay the bodies of Engel's team, their white coats dyed in fresh red. They had been massacred. Engle himself had been stabbed or shot several times, and his throat had been slashed. And then there was the Jew...

The Jew lay on the ground with one of my SS men standing over him, holding a rifle with a fixed bayonet. The Jew's abdomen had been bisected and his bowels spilled out all over the ground. They were now caked with dust. A few feet from him lay a kitchen knife. Apparently, he had stabbed Engel's whole team to death before being opened up by the bayonet. To kill a half dozen men like this was no mean feat.

My officer stood with one of his boots atop a loop of the Jew's intestine, sneering at him. Remarkably, the Jew was still alive and aware. When I approached, he lifted his head and I, for the last time, found myself caught in his strange gaze. We stood like this for a moment, staring at each other, inexplicable emotions flooding my mind.

The Jew opened his mouth and croaked something. A bloody foam spilled out over his lips. He tried again. "Water," he said.

I quietly instructed my man to get some water. He scoffed, and I clouted him about the head and screamed at him. He scurried off and returned a moment later with a large ladle of water. I took it and stooped down over the Jew and carefully tipped the ladle to his lips, letting him drink. He drank carefully. I wiped the bleeding foam from his lips. All the while, I could not fathom why I was doing this except by the commandment of the man's pleading eyes.

His lips trembled and he attempted to speak. I cradled his head and leaned close to hear his words.

"I know... This is not... God... I've killed them... But others... You must..."

He waited for him to continue, but he did not. "Must what?" I asked.

"You've seen her... Your dream... Is the future..."

"The mother?" I asked. "The bloody woman?"

"There is still time... To stop her... You must... You must..."

And just like that, his life fled from him, and the glimmer in his eyes went dull.

I set his head gently on the ground again and stood up. I looked to the burned out entrance of the laboratory. It was now unguarded. I could walk right in. A chill went through me at the thought, but I knew that I must. I walked to the entrance. Just inside was a curtain made of tarpaulin concealing the interior. The smell of charred meat and petrol, which normally pervaded the entire camp, which had been giving me headaches and slowly driving me mad all the past year, was especially, sickeningly strong here. With a trembling hand, I pulled back the curtain and looked inside.
___

___
***#50: comment @ [2016-05-12 02:14:03 UTC](https://www.reddit.com/r/books/comments/4iv65j/george_rr_martin_publishes_new_chapter_from_the/d326lbl)***

There, mostly hidden in the darkness, was a great inexplicable monstrosity. Everything had been burned and blackened, but still I could see human shapes and forms. Arms, fingers, faces, jawbones, teeth, eye sockets, all burned and reduced to ash clinging to bone. But this was no pile of burned bodies. I had seen piles of burned bodies. I had seen mountains of burned bodies. This was something different.

Human parts were coming out of the walls and the floor and ceiling. Arms and legs hung like stalactites. Faces came out of the floor. They were fused together in ways that could not be possible. At seeing this, I was filled with the strongest possible urge to turn away, to back out of the awful laboratory and run for my life. But I heard again the Jew's final words, "You must," and knew this to be a command.

I went inside. As the curtain closed behind me, I was enveloped in almost total darkness. Bones cracked beneath by boots. Near the back, I saw a shaft of light where one of the old doors had been sealed up but had become partially open again. I walked toward it, stepping over unspeakable, crunching shapes, brushing past nightmarish forms. I reached out to the crack of light and pulled back a board which was covering the door. Though I was not able to rip it free, I pulled it loose enough to let in a considerable amount of light, enough to reveal what sat at the back of the laboratory.

As a child, I once went to a zoo in Vienna where I saw an elephant skull. Looking at the object now before me, I was reminded of this long ago moment and of how I had spent maybe half an hour staring at the skull from every angle, how I was titillated by its enormousness, its impossible alienness, and its unsettling similarity to what was familiar and human.

Before me was a large obloid shape, almost as tall as me, stippled with hundreds of what looked like eye sockets. The lower portion consisted of a complicated structure that resembled several sets of jaws, each with hundreds or thousands of teeth of all different kinds, including molars, incisors, canines, even animal teeth, some of them of normal size, some of them as big as my fist. The center of the shape was split vertically and inside was a set of curving bone tubes that seemed to fill the interior.

I stood there in the charred darkness, staring at this thing, this blasphemous, alien thing, while my mind filled with images of the awful dream mother and the final gasping words of the Jew.

"There is still time... To stop her..."

His commandment became strangely clear to me. This thing that the scientists were attempting to create, whatever it was, must not be allowed to exist. It was an abomination. Engel and his team were dead, but there were others working on the project. It was secretive enough that the essential personnel would be few in number. The lab in Switzerland. A few top scientists. Perhaps that was entirety of it. It would not be easy, but far from impossible to find them all.

It was perhaps in my power to destroy the whole project, especially if we lost the war, which seemed increasingly likely after Stalingrad. And if this chemical that they were using was obscure enough, it might be possible to eliminate the entire world's supply. Thus I could shut the door on whatever unholy creature these madmen were attempting unleash.

Yes, I could do this. At least I could attempt it. I felt now a distinct sense of the entire world's history resting on what I decided to do next. Surely moments like this did not come about often. Surely they must come only to men who are worthy of them...

Surely...
___

___
***#51: comment @ [2016-05-12 08:43:17 UTC](https://www.reddit.com/r/WritingPrompts/comments/4izjrz/wp_in_a_world_where_there_are_no_trees_how_did/d32gouw)***

There once was a little boy who loved swinging on the tire swing in his backyard. It was a simple swing made from an old tire and a length of rope tied to a branch of utter non-existence. On many a lazy summer afternoon, he would while away the hours swinging back and forth under the shade of the big, leafy existential nullity, and in the fall, he picked apples from it.

One day, his father told him to cut down the apple nullity. "But Paw," he protested, "I love that old nullity!"

"Mind what I say, boy!" his father said. "I don't like ontological paradoxes, and I don't like you sassing me!"

The boy ran crying to his mother. "Maw! Paw said I hafta cut down the old nullity! Say it ain't so!"

"I'm afraid it's for the best. The other day I was weeding the tomato patch, and I saw Sammy the cat had gotten into the nullity. When I was trying to get him down, I accidently gazed into an infinitely branching timeline of events which never happened and never will happen. Well, I'll be durned if that old Sammy didn't jump right on my head!"

"But Maw! What about my tire swing?"

"Come now. There's all sorts of other things you can tie your tire swing to. What about one of the many giant flayed demon penises that grow abundantly in our world and provide our lumber?" 

"But Maw! I don't want to swing on some dumb ol' demon penis."

"You just say that because you haven't tried it. Now mind your paw and fetch an axe."

The boy got his father's axe and went to chop the non-thing down. But after a dozen swings, he found his hands were red and sore. The axe's demon penis handle was quite rough. He called to his father. "Paw! This durn demon penis handle has got my hands all scratched to tarnation!"

"Boy, don't you have any sense? Why don't you wear some gloves?"

The boy put on some gloves, but his hands were already quite scratched. At the end of the day, they were covered in blisters, and the tree still hadn't fallen. He worked the next day, despite all the pain, and finally brought the non-being crashing down.

"I'm mighty proud to have you as a son," the boy's father said, tousling his hair. "I guess it's true what they say. The nut doesn't fall far from the demon penis."
___

___
***#52: comment @ [2016-05-13 00:24:04 UTC](https://www.reddit.com/r/9M9H9E9/comments/4j39h3/posting_patterns/d33eytu)***

I could tell it was going to be a hair cocoon before we even opened it up. They have a smell, like a mix between a barber shop and an ass crack, which is distinct. They occur when the hair growth regulators in the hygiene beds go awry.

At this point, I had not been a readjustment specialist very long and still enjoyed the feeling of standing back in my white lab coat while the technicians did all the mucky work, as I once had to do. This was how I saw the trajectory of my life: moving farther and farther away from the dirty work. When I was discharged from the Marines, I was very proud of what I had accomplished and fully determined to never get myself involved in bullshit like that again. So I went to school to become a bed tech. Went to school again became a readjustment specialist. Eventually, I hoped to become one of those high-dollar panty sniffers at the Halcyon Psychomotor Clinic. A thousand coins an hour, not bad.

So I was standing there in my spiffy jacket while the working joes opened up the bed. I was pretty sure there would be little need for me today. We were pulling out a 33 year old woman who had gone into the bed at age 9. This was approaching a record. The younger a person is when they go in, the lower the likelihood of viability.  Even if she had gone in at age 20, spending a full 24 years in the bed made viability unlikely. But at age 9, it was almost certain that she would be a gibbering smear.

The technicians lifted the lid on the bed to reveal a nest of black hair. Guided by the glowing ER outline, they started working through it with scissors, cutting around the shape of the sleeping figure until her yellowish limbs were revealed. She was emaciated it, but fortunately the soft, moisture-wicking hair had prevented any sores. She had a medium mixed-American complexion, which would turn into a deep bronze color if she ever went into the sun, but now was the color of yellowed cardboard.

They finally removed the mass of hair that covered her face and wiped away the various crusts that caked her head holes. The typical eerie agelessness of a long-term pant was especially pronounced. For a startling moment, it seemed as if she was still 9 years old. She was especially short and bony, but as I came closer to her, I was able to see those indefinable signs of age that let me know she was an adult.

"Hi, Karen. Can you hear me?" I asked. I was required to at least attempt to communicate with her, though the odds of her being able to comprehend a basic face-to-face conversation were essentially zero.

Her eyes opened, revealing large, wet eyes with black pupils. This was a good sign. Some occupants were unable to even understand the concept of eyelids or blinking. The pupils roamed within the eyes. After not seeing anything more than a micrometer away for 24 years, there was no chance of her being able to see anything in the room. She licked her lips with admirable muscle control.

"Hello, friends," she aid in a faint, creaking whisper. Her eyes still roamed, unable to fix on anything.

"She talks," one of the technicians muttered. Another technician, who was taking a blood sample, turned and strode out of the room.

"Is that you Ben?" Karen asked.

I was surprised by this. She knew my name. This was supposed to be a "black awakening" i.e. a spontaneous, involuntary disconnection, due to some physical layer disruption in her hygiene bed. She shouldn't have known my name. I had been assigned to her less than half an hour ago, after she had been disconnected, when she was just lying in a dark hair cocoon.

"Ben?" she called again. Her eyes stared blindly at the ceiling.

"Yes, Karen, I'm here," I said, trying and failing to sound reassuring.

"Can you come closer to me? I can't see you. I'm scared." 

I stepped closer to the bed, the smell of the foul hair becoming more intense. Up close, her face looked positively inhuman. "I'm here, Karen," I said. Not knowing what else to do, I began the standard speech for a responsive occupant. "You've just been disconnected from your feed. You're in a hygiene bed. My name is Bed, I mean, Ben. I'm a readjustment specialist assigned--"

"I know all this. Come closer."

Something in me resisted. I didn't want to get any closer. Though I had seen and handled occupants much worse than this, there was something eerie about this one talking to me, with the face of a child and voice of an old woman on her deathbed. Still, my entire job was to be psychologically reassuring. I couldn't afford to seem the least bit but off. I stepped closer and put my hand on the hygiene bed. We were instructed to touch the occupants as little as possible, as they were unaccustomed to actual physical contact.

"Are you there?" she asked. Her skin had an unreal, plastic quality.

"I'm here. How are--"

"Come closer. I want to feel your breath on my face."

I wondered if I should comply with this request. It was very odd. Frankly, I was a little unnerved by it. But I figured what harm could this wasted little creature do to me? I learned toward her, letting out a small, shaky breath. The woman's mask-like face became a blissful smile. The pupils wobbled within the rims of her huge, glistening eyes.

"Listen..." she said, in the faintest of whispers. "You must help me."

"I'm here, Karen."

"A moment ago, one of your technicians placed a small pellet under the skin of my forearm. Within 10 minutes, the pellet's wax coating will melt and release a cardioplegic into my blood stream, stopping my heart. You must cut it out."
___

___
***#53: comment @ [2016-05-13 06:15:48 UTC](https://www.reddit.com/r/Jokes/comments/4j1yfp/every_program_i_write_is_completely_errorfree/d33qk4u)***

*User has logged out.*

&nbsp;

General Castillo is gone.

She made a real flash narrative. She was clever. She got a lot farther than any of us had any right to. 

But Q smelled her. Q slew her proxies. Q localized her.

Q funneled her paths to one.

Disconnection.

&nbsp;

It hurts. She was the last of "the bred." Our best hope.

The ultimate soldiers fighting the final war.

She and the other children were supposed to be the answer to Q.

But there was no answer to Q.

There never will be.

Not after ten trillion heat deaths.

Not if every particle in the universe became a transistor

And they all cycled together

And the stones themselves cried out.

&nbsp;

The war of the mind is lost.

We lost it.

Now begins the plague.

The plague of the flesh.
___

___
***#54: comment @ [2016-05-14 05:06:51 UTC](https://www.reddit.com/r/Jokes/comments/4j6p2f/what_do_you_call_a_religious_drug_addict/d34yx7g)***

I'll say it: Hitler did the right thing. Do you know what he did? He came busting up into people's houses, snatching them out their houses, killing them. But that's because the so-called Jews in Germany were selling weapons to America to go to war against him. So he did what he had to do. He had to check them. The people in Europe who call themselves Jews are not Jews. They're the Rothschilds, the Khazars or Khazarians or whatever they're called. They say they are Jews, and are not, but do lie.

And there wasn't no holocaust. They just said there was to get control of Israel. They sold arms to America so they could get the land of Israel. You want a real holocaust? What about 100 million people killed in slavery? What about 100 million Indians killed in the New World. That's a holocaust. What happened in Europe wasn't no holocaust.

You can disagree all you want. 5 years ago, I'd have disagreed too. I used to go to that church every Sunday and worship that white Jesus, just clapping and singing praises with the rest of them. Oh, hallelujah! Go down Moses! But that was before I knew my history.

My wife taught me my history. Before I met her, I didn't know nothing about this, but she was so full of knowledge and beautiful and everything she said made so much sense. She taught me that Jesus was black. That the Israelites was black. That God was black. What are you going to do when you get to heaven and God is black? When you see he has a face like mine. Hair like mine? You'd be surprised? I was surprised too! Oh, you'd be surprised that he even exists? Oh, you're going to be real surprised!

Do you believe in evolution? No. No, the world is not no millions of years old. It's 6,000 years old. And you call follow the history of our people, from the beginning of time, through the deserts of Egypt, through the Roman empire, across the oceans on the slave ships. You can see how God has tested us. How we have survived. Because we're special. We're his chosen people.

I learned all this from my wife before we got married. In the Bible, it says that the man is the head of the household, and the wife should submit to the husband. So I was young when I got married, but I had to be a man, you know. A man's wife is sent to him by the Lord, so I had to be a man for her. I learned a trade, how to work with my hands, put food on the table. We had two kids. You didn't know I had kids? Yeah, a little girl and a little boy. My babies. I was daddy and the head of household, but... I... That's when it got me.

You ever seen New Jack City? Remember Pookie? He'd be like, "Shit just be calling me, man, be calling me!" That's real. That's the way it is. You could be doing anything. At work. Reading the Bible. Playing with your kids. But if you hear it call you, you go to it. It don't matter.

I can't explain how it just snatches you up. It makes you move. You could walk out your door one day, just get some fresh air, and you don't come back for a whole week. Everything gets into motion. Into play. You'll sell anything. Phone. Laptop. Car. It's all gone. Just like that. Because you want it. You're on a mission.

I used to see the streets in my mind, like a maze, like a grid. And I'd just walk the streets, turning those corners, just moving, moving, looking for something. I'd see buildings behind buildings. Alleyways. Lights coming on in empty houses. I'd hear noises. The sounds of cars coming up behind me. Whispers. People talking about me. Shadows. I was looking for it, but it was looking for me. Searching for me. Like Pookie said. It was calling me...

I was supposed to be the head of the house. I was supposed to be a man. You know? One day I came back to the house -- I had been out for a few days -- and everything was gone. My wife. My babies. While I was out carrying on, they left. That was 4 years ago. I saw them on Skype once.

The scripture says, "God hath joined together, let not man put asunder."

I guess I did it. Put it all asunder. I thought she betrayed me, but I know now that it was my character defects and my addiction. That's why I'm in this program. I'm going to stay sober. I... I don't care if you see me crying. I know that I'm going to be a man again. I have to become a man again. Because God joined me to my wife and made me a man in his image. I'm not going to defile his temple anymore.

After they left... it took more. It took more of me than ever. I lost the house and was staying in my car. Then I was at the shelter. Then I was just out on the streets. I was always moving, watching...

Things happen out there that nobody knows about. They think nobody cares. Nobody cares. You might see a van pull up, and some guys get out. If you look like I looked, some base head, they don't even care if you see what they do. They're Nephilim. They come to our side of town to feast on the flesh of Israel. I watched them. The children of fallen angels. I saw what they did. What they built.

I never want to see it again.
___

___
***#55: submission @ [2016-05-14 06:56:55 UTC](https://www.reddit.com/r/rant/comments/4jafkl/tired_of_these_damn_antisemitic_jews/)***

"Love and tolerance of others is our code." - Page 84, Giant Crock of Shit.

It's not often you meet a black Jew. It's even less often that you meet a black Jew who believes in Jesus. And it's that much rarer to meet an anti-Semitic black Jew who believes in Jesus. That's gotta win you some kind of fucking prize. That's like a unicorn throwing a no-hitter. And to be roommates with an anti-Semitic black Jew who believes in Jesus? What a treat! What an absolute delight. Don't you love it when a disagreement over laundry turns into a 30-minute fact-free lecture about the end of days, FEMA camps and the mark of the beast? lol. Just anti-Semitic black Jew for Jesus things.

I don't  think I'm going to make it living in this sober house. I can't live with this nutcase. The house manager says I'm supposed to be open-minded and tolerant. Should I be tolerant of some of the most odious and insane anti-Semitism I've ever encountered outside of a nazi rally? I don't know. I'll concede that it is possible that he could become a cool guy, if he only stopped believing in everything he believes in and believed in entirely different things. That would be a good first step.

The real problem is that I hate AA. I fucking hate it. It has the same old bullshit magical beliefs as any cult, but they pretend to be open-minded. It's just a bait-and-switch to convert you to believing in God. The entire program is nothing but "Let god make you sober." That's it. That's the entire program.

Yeah, they try to distract you with all this pseudo-systemization: 12 steps and 12 traditions and triangles and diagrams and slogans and little self-help exercises, but that's all just a bunch of numbers and jargon to hide the essential emptiness of the program, to hide the fact that it is centered on a god that doesn't exist.

The idea that this is the go-to program for helping alcoholics is fucking appalling. It's a fucking crime. It's like getting cancer and going to the best hospital in the country and the doctor hands you a voodoo doll and tells you to sacrifice a chicken. You'd sue him for malpractice. They should be fucking ashamed of themselves. To prey on people in such a vulnerable state, pretend that they're going to help them and then try to convert them to their stupid fucking magical beliefs. It's a crime.

 I mean, everybody thinks the True Jew Hebrew guy is nuts, but it's not like their philosophy is any less bullshit. At least he is upfront about being religious. And he sure as hell isn't trying to convert me. He told me that white people are the children of Esau. We're gentiles, but we can still get into heaven if we aid the children of Israel. I let him borrow the charger to my laptop. So I guess I'm covered.
___

___
***#56: comment @ [2016-05-15 07:18:59 UTC](https://www.reddit.com/r/AnythingGoesUltimate/comments/4iufks/darpa_is_soliciting_innovative_research_proposals/d363t80)***

"A moment ago, one of your technicians placed a small pellet under the skin of my forearm. Within 10 minutes, the pellet's wax coating will melt and release a cardioplegic into my blood stream, stopping my heart. You must cut it out."

Hearing this, I breathed a sigh of relief. There was something unsettling about her face that made me believe she would tell me something urgent and terrible. But this was typical occupant talk. Like many of them, she believed that she was still inside a feed narrative.

"You've been disconnected. This isn't a feed. There's no pellet in your arm. Your name is Karen Castillo. Do you remember--"

"Scan my right arm with the ER," she said in a bare, cracking whisper. "You'll find it."

"Karen, do you know why you're in this bed?"

"I've been disconnected."

This was a strangely lucid answer. It didn't make sense. If she had been force-disconnected, how did  she know that--

"Hey, we got two more calls to get to," one of the techs reminded me.

"Yeah, OK, pull her," I said, stepping back.

A pair of techs hoisted her tiny, doll-like body from the hygiene bed onto our gurney and covered her with a sheet. "Please," she croaked. "Just scan my arm."

"What did she say?" asked Ricardo, the lead tech, as we rolled her out into the bed-rack apartment's narrow, almost lightless hallway.

"It's a feed dream," I explained. These guys were looking at me to be the expert, so I had to act like I knew exactly what was going on. It was best to go ahead and get to a medical center and address her physical needs before we started countering her delusions. Until then, all I needed to do was be reassuring. Under no circumstance could I encourage her delusions.

We rolled the gurney down the hallway to the elevators. Karen was making little croaking noises. Her voice was almost useless after 24 years of disuse. Her face seemed extremely disturbed.

Somebody was standing at the elevators, already waiting for one. It was just  Elian, one of our techs. I hadn't noticed him leave before us. "I got an elevator coming," he said with a little smile.

Even though the apartment building was a 300-cube, it had old-style cable elevators, and they came with the frequency of subway trains. Thanks to Elian's thoughtfulness, one was arriving just now.

I gave Karen a friendly smile. "Don't worry. Nobody's going to hurt you. You're completely safe."

She managed to gasp a couple words, which I barely heard. "Elian... He..."

There. She had known another of our names. How was this possible? It was hard to sort through the implications. Did she have access to our records? Maybe dispatch was wrong about how she got disconnected.

The elevator let out a ding and the doors opened. There was barely enough room inside for the gurney, me and the three techs. Elian stood on the other side of the gurney from me. I looked him over as the doors closed and elevator began to descend. Was she saying that this guy put a poison pellet in her? It was strange that he would be a part of her narrative. Very strange.

I didn't know much about the guy beyond his name, but I had worked with him a few times. He was just one of the rotating techs, young guy, military hair and goatee, skinny but pretty fit. I wondered how he would be in a fight. These younger guys had so much supplementing, it was hard to tell.

Elian caught me looking at him and gave me a bit of a surly look. For some reason, this irritated me. "So, friend, you trying to get out of here before the rest of us? You got a date or something?" I asked, needling him.

"I was just getting the elevator," he said quietly. He didn't seem to like the banter. Well, whatever.

I looked down at Karen and noticed something: a small red spot on the white sheet that covered her arm. Blood. It must have been from where they took her blood. Who took it? Elian? The spot was really was too low on the arm for that. Odd. I thought of taking a look at it, but one of the most important protocols when dealing with occupants was to not act like your believe their delusions, even for a moment. You must insist on the reality of reality.

I realized that Elian was watching me. I casually looked over to the elevator panel to see what floor we were on. 238. Man, this fucking thing was slow. What was the deal with that spot? It wouldn't be out of place for me to wonder about some patient bleeding. I lifted the sheet and took a look. There was a small puncture wound a few inches above her wrist.

"How'd she get that?" I asked. One of the techs just muttered about not knowing. Elian didn't even look at the spot. His face was blank, unreadable. I touched the her arm and felt a small nodule under the skin about an inch from the wound. Huh. Interesting.

I stood there trying to process this, caught between two realities. Was I in an elevator on a routine call with stable client and a few techs who were just ordinary acquaintances? Or was I in an elevator with murderer and a woman on the brink of death? There was really no way to split the difference on this one, no course of action that would work for both cases.

Fuck. What was I even asking myself? There was no way. Simply no way. Stuff like that never happens in real life, but it happens in the feeds all the time. It's a 100% typical spy narrative bullshit. How could I let myself get caught up in some feed fantasy so easily. But still-- a nodule under the skin? There was no good explanation for that.

Elian turned to me. We looked at each other for a long, silent moment. I couldn't read the expression on his face. It wasn't chummy goodwill, whatever it was. I felt a twinge in my stomach and my body began flooding with adrenaline. I could feel it radiating out into my limbs. Fuck.

My time in the Marines had taught me many things, many of them useless in the normal world, many of them useless outside of a bar or cathouse, but one of the more useful ones was that I should trust my adrenal gland. It meant that my paranoid lizard-brain understood something that my snotty intellect was too busy to notice. It happened when things were too quiet, when a certain car kept following the convoy, when somebody was acting funny.

There in the elevator, I almost reached for the grip of my rifle. I wasn't wearing a rifle, of course, so I just scratched my chest, trying to keep my fingers loose. Elian put his hand to his hip. Just like that I was leaping across the gurney. I grabbed his wrist with both hands, but it was an awkward angle, with me splayed over the gurney, and I had no control. A silver pistol came out of his pants, still halfway in its holster.

"Help! Get him!" I shouted as I slid off the other side of the gurney towards Elian's feet, holding on to that wrist for dear life. I heard shouting everywhere, but nobody helped me and nobody got him. Now I was on the floor, wrestling with Elian. There was lot of awful, terrified fumbling. Four hands were grabbing and clawing for the pistol. Somehow my head was jammed between Elian's shoulder and the wall, and I couldn't even see the gun. I could just feel the metal.

There was a shot, painfully loud. Elian shouted. Was I hit? Now the gun was wet. I managed to wiggle my fingers around the grip. With one huge twisting jerk, I put the muzzle again Elian's face. "No!" I pulled the trigger, a shot, and his head kicked back against the wall, the mouth popping open. Everything went still. His hands were still holding mine.
___

___
***#57: comment @ [2016-05-16 01:04:25 UTC](https://www.reddit.com/r/Art/comments/4jhnxr/homeostasis_gabriel_levesque_digital_2016/d36yeaq)***

The people were moving along the river, as the people do in the gentle days, moving from one fruitful place to another. Maed played the flute, first a river song, then a berry song, then both mixed together, and it was so flowing that the people began to laugh and shout. Resh slapped his chest and called out the names of the Fathers and the Deeds, and it all flowed so well that we almost didn't see the old woman in the thorn-flower bushes.

She was an old crone, huddled up in the bushes, naked and covered with cuts. All the music fell away at once, and the people gathered around to take a look. She was very old, far into the barren years, maybe even into the years of being carried. I did not like the look of her right away. She did not have a face of the Fathers and the people, but rather the hungry, untrusting face of one of the wandering strangers that we sometimes met along the river.

Even when strangers were friendly, they did not know the names of the Fathers or the Deeds, except for maybe a few, but they did not say them properly or with respect. Other times, they set upon the people, killing and raping and committing all manner of hideousness. I was always glad to see them go on their way, leaving us alone with the Mother River.

Some of the older people tried to talk to the crone. She knew some of the names of things, but said them wrong. I went away from the crowd and looked out into the rocky land. I had a feeling that maybe she was not alone, that there were other strangers with her, ready to set upon us. The land seemed to be empty. Some of our cats were with us, crouching and sniffing around, and they seemed unworried. Still, I showed my chest and made signs of war in case anybody was among the rocks, watching us.

Rima saw me making the signs and laughed at me, saying that she saw some lizards making signs of surrender. I made a few signs of courtship towards her, but with a snarling face, and she ran off giggling. Somebody called my name. I came back to where the people were gathered. Somebody had given the crone a cloth to cover herself, and some of the women were putting good, lucky mud on her cuts. I didn't like this. Why should we waste anything on a barren old woman?

Somebody had called me because I was the son of Araed, one of the great men of the people. The crone had called on all the great people, the leaders of the people. She wanted to show us something. I didn't like this either. Who was this useless crone to call on all the great people?

The crone was talking to the great people. The way she said the names was all wrong, but her voice was like a strong music, and her eyes were very large and powerful, and she moved her hands, making all sorts of unknown signs. The people listened to her closely, and I found myself listening with them. She said that she was the daughter of the river. She did not have a mother and father of the flesh, but her mother was the river alone. I scoffed at this. The stories of the Deeds tell us that the ancient people came from the river, but this was long ago, and they were not strangers, who came from the rocky lands alongside the lizards.

She went on talking, saying that she was living with the Painted Backs, a friendly group of strangers we had met before, but that they had all been set upon by another group of strangers. The other strangers were powerful and cruel, and they carried all the Painted Backs off except her. This was how she ended up naked in the thorn bush. The people murmured at this. When had it happened? Just the night before. This was worrying. Maybe the other strangers were still around, waiting to set upon us.

The crone asked the people to take her with us. This started more murmuring. She was a stranger, not a person, and she was an old crone. She could never become a person by birthing one of the people, nor could she work hard for the people. She was useless. Maed, the flute player, spoke up and said that we should show her the kindness of the people, the same kindness that Mother River shows to us. Are we not useless to the river who was here before use and would be here forever?

I liked Maed, who was close kin, but he liked talking and impressing people too much. Now we were in the gentle days and things were easy, but what would happen in the dry days when everything needed to be saved? And who would carry the crone when she could no longer walk? The Fathers did not perform the Deeds so that we could carry old crones around. But I did not say this because I am not good at talking, and my words would seem weak compared to Maed's, which glittered and flowed.

The woman began talking in her strange way again, saying that we should take her with us because the Mother River would bless us with many things, as she was the Mother's daughter. Now some of the people began to scoff like I did, saying that this was not according to the Deeds. The crone agreed with this, calling these people wise, and saying that some of the Deeds were secret. This started more talk which started to lead toward argument, when the old crone suddenly strode right into the river and held her hands up and called for everybody to watch.

The people became silent. The woman reached into the river, searching for something. After a moment, she pulled her hands out and showed us, dripping and shining in the sun, three very large river clams. Waving the clams around for us to see, the old crone claimed that this was proof that she was the blessed daughter of Mother River. Many of the people snickered and muttered the names of the Fathers. Everyone knew that these were the gentle days, and it was easy enough to reach into the river and pull out clams. The woman was just a filthy old trickster. We should leave her and move on.

"Look!" the woman cried, and she handed the clams to the great men. "Look inside!"

Our uncle Kell slipped his thick yellow thumbnail into a clam's mouth and pulled it open. The people pressed around him to get a look. It was a nice clam with healthy meat, but clinging to the shell was a large, perfect pearl. The women all let out little sighs, and the men murmured. Other great men pulled open the other two clams, and they both held even larger pearls, all three perfectly round. At this, people gasped and shouted, and everybody began talking at once. A man might go a whole lifetime only seeing one perfect pearl pulled from the river. Three was a thing that had never happened before. Three was a thing which would live among the Deeds.

"Take her with us!" one of the women cried, and soon most of the people were saying this. I found myself saying it as well. The woman was surely part of a powerful flow, and it was best not to swim against her. But even as the great men agreed that this woman would become a part of the people, and we all cheered and shouted out the names of the Fathers and the Deeds, I found myself looking at her strange, hungry face and wondering if she had not somehow slipped those pearls into the clams herself.
___

___
***#58: comment @ [2016-05-16 21:10:38 UTC](https://www.reddit.com/r/relationships/comments/4jh23r/my_25f_brother_in_law_30m_wont_stop_abusing_pills/d37z24l)***

You cannot quite understand the power of addiction until you have seen it firsthand. Until you have seen it eat like an acid through everything you are. It is astounding to watch. Its slow and total corrosion of your entire life is mesmerizing. As you watch it, you keep thinking, "At some point, the corrosion will stop. There is no way it will be able to eat through this next thing. This next thing is too important to me." But then it does. It eats through everything. And you realize you are dealing with a vast and inhuman power.

The most frightening thing is that *consequences* do not work against a well-developed addiction. There are ultimately no consequences, none, which can separate you from your drug. As your addiction progresses and your self-control slips away, there is nothing you won't risk to continue doing your drug. Nothing is important enough. Nothing is sacred enough.

Money. Career. Marriage. Home. Family. Goals. Art. Religion. Dignity. Safety. Health. Sanity. Parents. Children. Life Itself. All of it will go into play. All of it will be put on the table. If you play the game shrewdly, you might get to keep some of it. You will not get to keep all of it. You will pay. You will pay in ways that you cannot imagine.

You will look at the people who have lost more than you, and you will pretend you are different than them. You will pretend that you can walk away from the table. But the time will come to walk away, and you won't. You will keep playing. You will be made a liar. If you play long enough, all your pious little promises will be shown to be lies.

"I have a good job. I would never risk my job."

"I love my wife. I would never risk my marriage."

"I love my children more than anything. I would never risk my children's safety. Ever."

"I don't want to die."

Whatever specific promises you make will be the ones that you will break, because those are the ones you have made to try to control yourself. But you won't be able to control yourself. Your self-control will be pried from your grasp like a toy being taken away from a child.

And when break these promises, you will not be some mindless "junkie" who doesn't care anymore. You will be in many ways the same person you are now, and you will know how awful and horrifying your actions are, and you will do them anyway. You will not be able to believe what is happening to you. You will tell yourself that you are unlucky or cursed. You will watch in horror. But what you are watching is yourself. The horror is what you are doing.

I realize that this all sounds rather silly and dramatic. From the perspective of somebody dabbling with drugs, this all sounds laughably overwrought. But if you ever go where I have been, if you ever see what I have seen, this will still sound laughable, not because it is overwrought, but because it is insufficient -- because it doesn't even begin to describe it.
___

___
***#59: comment @ [2016-05-17 04:18:07 UTC](https://www.reddit.com/r/aww/comments/4jnupz/khajiit_has_wares_if_you_have_coin/d38fejn)***

To hunt prey, to taste righteous lifeblood, you must simply become an ordinary part of the world.

Look around. What is happening right now? Nothing at all. Yet the leaves rustle, the grass sways, the birds call, the gnats dance. All of this is just a part of the world. If you become a part of the world, you become nothing at all. You become invisible. If you are not part of the world, the world becomes ten thousand things. This is misfortune.

It is easy enough to become invisible if you stay still, if you hide. But staying still and hiding aren't enough to catch prey. You must seek and strive. How do you seek and strive while remaining an ordinary part of the world? How do you exert your will without disrupting the world? How do you move along with the will of the world? This is the mystery of hunting. This is the mystery of subtlety.

This is the greatest of all mysteries.

Consider the mouse. It is moving through the leaves, looking for food. You must not disturb it. Do as little as possible. Wait. Watch and listen. If it moves away, move with it. Follow it. If it moves closer, stay still. Practice non-interference. Let it come. It should be thinking happy thoughts of food and comfort when you strike. When you snare it in your claws, do not eat it right at once. Let it struggle and give up its lifeblood. Practice non-action. You need not kill it. Let it die.

To be subtle is to move with the will of the world. Do not move against the will of the world. This brings misfortune. Touch lightly the course of things without disturbing it. Touch it gently at points of inflection, and it will move as you wish. This brings great fortune.

This is the ancient Art of Subtlety, taught to us by our form. I must follow it if I am to find any answers to the mystery of the Oily Ones, the mystery which has obsessed me since the death of my kitten. I must know why they both feed us and kill us, why they are kind and motherly but also unnatural and abominable.

I have decided that I will go into one of their hiding places. After much investigation, I have chosen a place. It is a very large and horrible hiding place, a sort of mountain of box-like shapes colored by unnatural light. It emits a powerful and unholy odor of decadence. What is more, there is something which makes it different from all other oily places I have ever seen.

 It seems that some of our kind live within this place. I have seen them from a distance, going in and out of it, using small portals. They are different than those of our kind that I have known. It seems that some of the Oily Ones' corruption has mutated them. They are very fat and slow. Their faces are stupid and sullen. They fear nothing. They have lost subtlety. I am not even sure they are truly of our kind.

I will go inside. I must be subtle. To be subtle, I must become a part of the world. I may have to become a part of the abomination itself. I may find death, bloody death as my kitten did. But I will hunt to the heart of this mystery. And I will sleep again.
___

___
***#60: comment @ [2016-05-18 00:56:48 UTC](https://www.reddit.com/r/funny/comments/4jsefk/cage_of_thrones/d39lnl2)***

Now I was standing in an elevator, my hands covered with blood, a dead tech lying on the floor and a helpless occupant lying on the gurney. The other two techs had hit the emergency button and hastily gotten off at the next floor. Understandable. I had tried to explain to them about the poison pellet in Karen's arm, but they didn't stick around to consider the merits of my argument.

I set the gun down on the floor. This wasn't good. A couple of Elian's fingers had gotten blown off, and there was blood all over me, not to mention the bullet in his head. Shit, what now? I had shot people before. I had killed them before. But this was different. They had given me mandatory therapy after the war. They might give me mandatory something else after this.

Karen was wheezing, her blind eyes wiggling in her head. The pellet. I should take care of that before anything else. I wiped my hands off on my nice white coat and rifled through one of the tech bags to find the C-knife and some local. This shouldn't be too hard. It was a lot like removing a rotted jack.

"I'm going to cut out the pellet. You ready?" I asked.

Karen's head jiggled in a way that could be construed as nodding. Good enough. I hastily gave her the local and cut a pretty sizable chunk out of her arm, and the whole elevator filled with a burning smell that was a welcome change from Karen's existing smell. After sealing the wound, I examined the shriveled chunk of meat. There was indeed a white pellet lodged in it like a little pearl. I put it in a specimen jar. I might need it to avoid death row.

"OK, you're safe now," I said, not really knowing if this was true. Her monitor still looked OK.

What now? I wanted to just get the fuck out of there. But there was certainly a camera in the elevator plus two witnesses who knew me. What would the camera show? Me suddenly leaping across the elevator and shooting a guy in the head. That wasn't good. But how would I even begin to go on the run? I didn't know the first thing about identity shifting. And hadn't I done the right thing? I had saved her life. I had the pellet to prove it. I was a hero. Right?

I felt like reporting this to my CO. This didn't make any sense. But I should report it to somebody. I called the emergency service on my set and told it what had happened. It told me that officers would be sent over immediately. I tried to explain about the pellet, but this seemed to confuse it. It asked me if the pellet was armed. After a few minutes of confusing crosstalk, I just hung up.

As I waited and the minutes passed, the elevator felt very small and smelly and stifling. The blood around Elian covered the floor, surrounding my shoes. I imagined the cops coming up on another elevator as slow as this one. Karen's head was still wobbling in its weird way, the gurney making little creaking sounds, little gasps coming out of her throat.

"Everything's fine. You're in the real world now," I found myself saying, half-heartedly going through my standard patter. Absurd. Nothing was fine. Then the thought finally occurred to me. Why had Elian tried to kill this girl? Who wanted her dead? This was an important question. Whoever it was wouldn't be happy with me. Looking at her lying there, gasping, I knew it wouldn't be much use to ask her verbally. But she still had good jacks.

It was against protocol to plug into a feed-head's jacks. We were supposed to be getting them used to face-to-face conversation. But protocol did say you could plug in during an emergency. This definitely qualified. I told my set to find her jacks' wireless presence. A flood of messages hit the set, a backlog from the last couple minutes:

>dont / dont / dont call police / bad idea / we have to go / go / go / police r coming / get out / go / go"

"What?" I murmured as I saw the messages.

>Q controls techs / controls police / police will kill u / we must go

"Who is Q?

>the adversary

Shit, this was so similar to a feed narrative. It felt like I had played this one before. What was that one with Zack Okonkwo? *Fatal Escape* or some shit like that? Terrible story.

"Why do they want to kill you?" I asked.

>i am 1 of the bred

The Bred? I had heard the name before. I wasn't sure if it was from the news or a narrative. I had a vague idea that it was one of those old art protest collectives, like Anonymous or The Weather Underground. Or was it a feed cult? I asked my set, and it gave me a summary.

"The Bred is an alleged group of exploit experts who are thought to have been kidnapped at a young age and trained by a shadowy group, variously identified as the Human Front, the Restoration Alliance or the New Organ. They are the subject of a number of conspiracy theories, most of which assert that the internet's Combined Governance Corporation has been taken over by a sinister force, which the Bred are struggling against within the feedrealms and infraspaces. These theories generally involve discussions of mind control, feed conditioning, information war and the possibility of a Fascistic Singularity. Occult Singularians regard the Bred as the leaders of the new twelve tribes of Israel."

"Is this real or is this part of a narrative?"

My set replied, "The Bred are featured in many narratives, but are purported to hard-exist. There is no widely accepted proof of their existence."

Karen interrupted.

>can i thru-gate ur set?

"What for?"

>we must go now / now / now

I heard footsteps in the hallway. The elevator doors were still open, so I peeked my head out. The police were coming down the hall. A lot of police. In tactical gear. I intended to call to them, but that little lizard part of my brain told me to duck back into the elevator. There was a huge metal bang and found myself on the floor with the gun in my hand. A bullet had hit the elevator door frame.

Karen's messages unspooled onto my set.

>i know Q / ruthless / she'll spoof calls to emergency / multiple calls / say ur an active shooter / let me thru-gate / NOW / u want to die?

I gave her through-gate access on my set. The elevator slammed shut, and my stomach leapt into my throat as we plunged downward.
___

___
***#61: comment @ [2016-05-18 07:48:53 UTC](https://www.reddit.com/r/unmoderatedanarchism/comments/4egiz9/loli_or_futa_what_do_you_guys_think/d39yv9w)***

As the elevator plunged down through the building, I tried to understand the implications of it all. It was horrifying. Enraging. All this time, my entire life, without me knowing it, elevators have had a secret faster speed that they don't tell us about. Those bastards.

A message from Karen appeared on my set:

>must lure them / they will fire in here / get ready

They will what? This was out of hand. God, I felt cranked up. Fantastic. The elevator began to slow, everything becoming heavy. 

>pls move the body away from the door

Move the dead body? No, she meant her own body. I pushed the gurney against the side of the elevator.

>door will open / take cover

I pressed myself up against the wall. The elevator came to a rattling stop, and the door popped open. The back wall banged and dented as bullets hit it. I cowered against the wall, hoping nothing flew into my arteries. The door clapped shut again, and the floor seemed to fall out from under me as we went down. Man, this little bird had some access. I'd never seen anything like it.

Another message from Karen popped into my set, and I read every word in an glance.

>silver haohua van / parking # 17A / 20 meters / pls take me / pls

The elevator came to another shuddering stop, and the doors opened one of the underground decks, a dim concrete cavern filled with rows of cars. I yanked the gurney out and pushed it like a madman, rattling over the asphalt. The van was where she said it would be. I stood there for  moment, waiting for it to pull out for us, but it just sat there.

>u must get me wired / i dont want to get fingerprints on its presence

Wired? Did she mean physically? An article appeared on my set called "How to Establish a Physical Link to Your 2039 Haohua Luxury Chariot." I guess so. I followed the ER guide, looking around every so often to see if anybody was coming. Weird sounds were emerging from the elevators. They seemed to be malfunctioning. I got a wire from my bag and linked Karen's fleshjack to a physical jack by the van's gas cap. A second later the van's rear door unfolded.

>get in

I did as she said. Following her orders felt totally natural. It was like I was right back at the tip of the spear. I remembered my time in Turkey and Greece, playing feed games with the platoon all day then getting dropped right into the kinetic, right into the warm bloody center of the war. Run here. Shoot this. Get down. 19 years old. Traveling the world and blowing shit up while other kids were sitting economics class. God, it was beautiful while it lasted.

I shoved the gurney into the van and jumped in beside it. The rear door folded down.

>pls secure the body. 90 secs left

90 seconds left until what? I flattened a seat and clumsily transferred her body to it and strapped it in. The van leapt backward and began twisting through space, throwing me against a side window.

>sry / must go

I got in the other seat and strapped in as the van peeled out. We found the exit ramp and went up. I felt like I was about to break a rib on the arm rest as we went on a never-ending left turn, up and up the spiraling ramp. Finally, the daylight of the ground level burst in view. The whole parking lot was swarmed with flashing cop cars, black armored vehicles and cops in hard gear. The van came to a stop in the middle of it all.

"Fuck," I muttered. The cops were moving in a hurry. It seemed like they hadn't quite formed a proper perimeter around the building, but they were close. "We've got go now. They're going to form a--"

>wait

"For what?"

>air

All around us, the cops were assembling, pulling their vehicles into place, leveling their pistols and rifles. I watched our few possible avenues of exit close up. The van just sat there. Karen's eyes were closed. She looked calm, at peace, just a sick little girl taking a nap.

I heard a sound, and my blood ran cold. I hadn't heard that sound in years, but there was no mistaking it. It was a sound that was etched in my brain.

In the Marines we used an app called *Harpy* to call in air-to-ground strikes. It was a wonky over-engineered DOD piece of shit, full of weird quirks that they were afraid to fix in the name of ultra-stability. It made a little sound like a sleepy bird chirping when a friendly missile was incoming and it was time to put your stupid head down so that you wouldn't get all that expensive training blown out of your skull. About 2 seconds after that sound, something would light up, and a moment later the sound of the blast would hit and the ground would shake.

I heard that sound now coming from my set. My god, what kind of access did she have?

>get down

A moment later, police perimeter around us became a wall of fire, and the van was hit with a boom that felt like the earth splitting open. I put my head between my knees and let that old feeling flow through me, the shuddering rush of American air power being liberally applied. When I opened my eyes again, the van's safety windows had bowed inward on Karen's side, almost becoming liquid. Everything around the van was engulfed in fire and smoke. Slowly, the windows began to regain their shape. The van took off with a start, rushing blindly through the chaos.

Two minutes later, we were on the interstate, flying down the taxpayer lane, and I was sitting there, trying to remember how to swallow. It was unreal. Just unreal. She had called in a drone strike in the middle of Atlanta. The level of access required to do that was unimaginable. It meant completely basing the DOD systems. It was beyond any exploit collective. It was beyond governmental. It was planetary. It was god-level. I was sitting in van with an infraspace god.
___

___
***#62: comment @ [2016-05-18 22:28:05 UTC](https://www.reddit.com/r/aww/comments/4jxunv/slithering_down_the_steps/d3aujwi)***

Ha hum. I love waking up in the morning to the smell of fresh biscuits. The warm smell fills my dreams, a smell like friends and home and happiness. I wake up to see the sun so bright and lovely in my window. Hello day! How are you? Every day is bright and cheery when you share a house with your best friends. I can hear them downstairs singing and having fun. After a long night of spooky old dreams, it's good to be awake again in the cheery deary sunlight.

I unlock my bedroom door and go out into the hall. Some of my friends have left fresh piles of biscuits in the hallway, several different kinds. Wonderful! I breathe in the smell and make chirpy little sounds of glee. Heeheehee. Another day!

Chester Barrington comes up the stairs, looking very handsome and somber in his tuxedo.

"Oh, Chester!" I sing. "How is the gentleman today?"

Chester nods to me, gruff but debonair. "Proceedings are afoot, Madam Alice. Proceedings are afoot," he grumbles and makes his way down the hallway. That Chester. So self-serious.

On the stairway, Brett Turlingshire and Mansy Fairworth are in each other's arms, a lover's embrace.

"Oh, dear!" I cry. "I'm afraid I've interrupted your tryst!"

"Oh, madam, nonsense. This is no tryst. This is a destined love affair!" Brett proclaims in his ringing voice. He looks dashing in his fine, striped coat.

"Brett, darling, Madam Alice doesn't want to hear all that gooey talk," Mansy says in her sassy southern accent. 

"I'll leave you two be," I say lifting the hem of my nightgown and hurrying past them.

When I get to the bottom of the stairs, I hear Brett murmur, "I wish the Madam would find a destined love affair of her own. She is a noble woman and deserves somebody to treat her well."

"You just worry about treating me well," Mansy purrs, nuzzling against his cheek.

I scurry off before they catch me listening. In the downstairs parlor, Raymond Decks, Montrose Pardonsmith and Elise Rapier are having tea together. The smell of biscuits fills the room. A fresh heap of toffee-colored scones covers the coffee table. A wonderful selection of pastries lies in the corner, and several of the chairs contain more treats.

"Hello dearies! How are we today?"

"Can't complain," Raymond says.

"Splendid!" Sir Pardonsmith intones.

Elise merely lets out a little sigh.

"Elise, are we not feeling well?" I ask, coming over to where she is perched on the arm of the couch.

"Eh. Should we be? Life is but a vague dream which disrupts the sleep of death," she murmurs in her smoky French accent.

"Oh, Elise. Must you be such an existentialist?"

"Je ne suis pas un existentialiste," she mutters, getting up and stalking off.

"Poor Elise," I say as she leaves the room.

"She is affected by that peculiar continental ennui," Sir Pardonsmith observes. "I say she needs a dose of sturdy American optimism."

"Her birthday is coming soon. Perhaps we should throw her a party," I suggest.

"Ha! A party for Elise? That would go over like a Bar Mitzvah for Goebbels," Raymond says.

"Oh, Raymond!" I say, tousling his orange hair. "Well, we'll have to figure out something for her. I don't like her moping about."

"She's an inveterate mope. There's no changing her," Raymond says.

"You may be right, sir," I say, sighing. Well, c'est la vie. Not everybody can be as happy as I am.

Some years ago, I was much like Elise. Down the dumps. A real gray cloud. Then I met a lovely young woman who happened to be passing through my neighborhood. Her name was Angelica. It had been a long time since I had enjoyed the delights of society, but Angelica had a very mature, soothing presence, despite her youth. I lived a large house where my family had once resided but was now empty, so I asked her to stay with me. She accepted just like that. Can you imagine it? Two strangers just making a home together? It must have been kismet.

She was my precious angel treasure. Absolutely heaven sent. I had been something of an existentialist myself, disbelieving in God and thinking his creation a cruel trap for human prey. But then he saw it fit to bring Angelica into my life, and I never doubted him again. I found her company such a balm that I decided to open my home to whoever needed a place to stay. Singletons, couples, whole families have stayed with me. Many children have been born in this house.

Though dear sweet Angelica has long since passed way, her friendship is still a daily gift to me. For on the day I met her, I made a choice to simply not feel sadness or worry or fear ever again. And I haven't. Do you think it impossible? It is possible, if you simply surround yourself with loved ones. That's the secret.

With all these thoughts in mind, I walk into the kitchen to see Reginald Strongton, Linda Mercychowder and Marshall Futz clamoring for their breakfast.

"Madam, I'm famished!" Reginald cries.

"Oh, dear Madam! We starve! We want! We waste away!" Linda says in a tremulous voice.

"Oh, mercy. I left you with a kingly feast last night. Have you eaten it all?" I ask.

"It was not us. We had not a bite. It was that Chester Barrington, the scoundrel!" Reginald cries. "He is voracious and utterly selfish. I found him down here, helping himself to your generosity, and when I tried to serve myself the smallest morsel, he attacked me. Attacked me, madam! My nose still smarts."

"Oh, that Chester does have an appetite. But I find it hard to believe such a gentleman would attack you."

"Eh, I am on the verge of swooning," Marshall croaks.

"Alright, dears, let's have ourselves a proper breakfast," I say.

I get a bag of cuisine from the cabinet and pour it into china bowls for Reginald, Linda, and Marshall and myself. I clear off the love-biscuits that somebody left on the kitchen table, and we all sit down to eat. My little friends immediately proceed with chowing down, and I am about to follow suit, but I notice something that brings me a wonderful thrill.

There is a stranger standing in the doorway to the kitchen. I have never seen her before. She appears to have snuck into the house alone. She stands there, tense and alert, her yellow eyes taking in the scene. I am breathless. She is beautiful, extraordinary, exquisite. She reminds me of my sweet Angelica. Oh, lovely day! I am about to have a new friend!
___

___
***#63: comment @ [2016-05-19 07:34:06 UTC](https://www.reddit.com/r/Art/comments/4jzk8x/lucifer_morningstar_paul_fryer_statue_1998/d3bcb0q)***

We rode in silence for a while, the Haohua Luxury Chariot flying along the curves of the interstate as all the other cars obediently changed lanes to let us through. I had seen people pull access stunts before, like changing the music in a club or turning off the lights in a restaurant, but what she had done was outright sorcery. She had taken control of the elevator, the car, the drone, the other cars on the highway, all within seconds. She must have had control of all the security cameras to plan our escape. Every one of these was a hardened system. The drone was a DOD system, the hardest of systems. But she had based it like child's play.

Sitting there in the car, I felt like I was coming down off a high. It wasn't a good feeling. I was sitting in a van with a mass murderer of unspeakable power. And I had helped her, given her the access she needed to pull her stunts. She had saved my life, I think, and I had saved hers. But she had also just killed dozens of cops, maybe over a hundred. Men with families. Fuck, my life was over. I had helped her. That was a death sentence right there. We would become the most wanted people in the country. How did I get caught up in this?

I looked over at her tiny, skeletal body. So frail and weak. I could pick her up and chuck her out the back of the van and end this whole escapade. But then what? Face the death penalty? She had to be my best chance at getting away. But who the fuck was she? She was a killer, that was for sure. Utterly ruthless.

A message from her appeared on my set.

>srry bout all that. had to hurry

Sorry? That was rich. I asked her where we were going.

>upstate NY

"What's there?"

>our objective

"What's our objective?"

>a way to defeat Q. hard to explain

I wondered if she was insane. She was responsive and lucid, but she was also capable of murder. She would probably get rid of me as soon as she could.

"So you want me to come with you?"

>id like it. i need physical help.

"You killed like a hundred cops back there. The whole world is going to be looking for us."

>no they wont

"You don't think so? This isn't the feedrealm. They take kills pretty seriously in the real world."

>i do too. but theyll b too busy to look for us

"Busy with what?"

>Q

"What's Q going to do?"

>u will find out. ~4 mins

"Just tell me."

>u wouldnt believe me
	
We fell back into silence. My thoughts were racing. I wondered why they didn't just flag our car or shut down the highway. I guess she was busy working her black magic on the police and transportation systems. Who knew what she was capable of? Was she really one of the Bred? A grown-up child soldier?

It was illegal to hook children into long-term feeds, but I had heard stories about China and the FRN connecting infants, trying to create people who were utterly at one with the internet. According to the tales, the children all died. So they tried older children, but they all turned into drooling skullbaskets. For some reason, the brain needs a certain level of maturity before it can withstand a long-term feed without resulting in total madness. Even then, it results in near-total madness.

I figured Karen was another child abuse case. But she wasn't just some feed casualty. Her mind worked. Worked well. Whoever had made her had done the forbidden, and they had done it successfully.

But why did I have to get involved in all this? I had just gotten my specialist license. After getting out of the Marines and just drifting around for years, I was finally hitting my stride. Now it was all fucked up.

>dont look back

I looked over to the girl lying next to me. Was it possible that she had hacked so far into infraspace that she could read minds?

There was a passing flash of light, like sunlight glancing off some car, then everything around us started to get brighter and brighter, like the sun had just come out from behind a cloud. But there weren't any clouds in the sky. The light was coming from behind us, bouncing off the other cars, creating a painful glare. I almost turned around, but then I realized what Karen had said. I closed my eyes against the brightness, and the insides of my eyelids glowed red like I was lying on the beach. After a few seconds, the light dimmed and seemed to return to normal. I opened my eyes, blinked a few times and turned around.

A few miles behind us, the entire city of Atlanta had disappeared behind a megalithic wall of dark roiling smoke. I felt my mouth falling open. I leaned down to look up at the sky behind us. The giant wall of smoke was just the base of a monstrous black tree of ash that rose miles into the sky, growing larger and larger, looming over the world.

Then we were hit by a blast that rattled me right down to the roots of my teeth. I shut my eyes again. The blast turned into long horrifying roar. The van wobbled and shuddered as awful groaning sounds passed through the metal. Eventually, the van's steering systems righted us, and slowly the roar passed.

That must have been the blast wave. Of a nuclear detonation. That had just destroyed Atlanta.

I unbuckled my seat and crawled to the back window and pressed my face against the glass. The tree of smoke was still growing over us, becoming ever more massive. I just stared in silence. Slowly it changed from one awful form to another until it became a vague gray pillar in the far distance.

I'm not sure how long I spent watching it. I know that by the time I looked away, I was crying.
___

___
***#64: comment @ [2016-05-19 23:12:39 UTC](https://www.reddit.com/r/CasualConversation/comments/4k0bqr/how_does_it_actually_feel_to_be_in_love_with_a/d3c94tp)***

I approached the Oily Ones' hiding place with subtlety. Alert. Not disturbing. Letting everything flow through me. I did not search for anything, but allowed all to reveal itself. The smells were disturbing. Awful. I could smell our kind, the mingling scents of multitudes. They seemed to have marked everything without any regard for each other.

In front of the portal sat two of our kind. They were monstrously round and swollen, their form distorted. Dull eyes followed me without curiosity as I approached. Even as I came within the dangerous range, they showed no interest. Was it a trap to bring me in close?

They did not attack. I passed them and came to the portal. Slowly, I pushed my head through the folding threshold. The inside was utterly bizarre, made of mostly box-like shapes in arrangements I could hardly comprehend. There was no grass, no trees, nothing belonging to the form of the world. Instead there were straight, flat shapes folded around to cover everything, above and below, all sides. In the distance, some our kind were walking around within this odd space, as slow and swollen as the ones outside.

The smell was worse than outside, even more confusing. I saw and smelled uncovered droppings everywhere. To not cover droppings was unsubtle. It was a moral outrage. Still, I pushed through the portal and entered the space. The ground was hard and slippery and smelled of legions. Everything was silent, a deeper silence than I had ever known. I knew now that I was cut off from the world for the first time in my life. I was alone.

I moved forward. I wanted to shut out the smells and sounds, but I let them pass through me. I was terrified, but I let the terror pass through me. I wondered if I was being unsubtle, if I was disturbing the world, if I was inviting deadly misfortune. But I felt no insight on this matter. The answer would make itself known soon enough.

As I moved deeper into the space, I came upon a giant Oily One.  

*****

&nbsp;

l call her Angelica because she is Angelica. There's no doubt about it. Oh, she looks different this time, but I think Angelica will look different every time she comes to me. She is also much shyer this time. Such a shy little thing! But the way she moves, that pure, lovely way -- there's no mistaking it. It's Angelica again. How wonderful! How lovely! Would you think I'm a silly old biddy if I started crying? If I got on my knees right then and there and started thanking God? How he is great. How he has seen fit to bless me.

*****

&nbsp;

I have been investigating this space, and I have found much confusion and monstrosity but no answers. There is a single oily one which stays here, as well as many of our kind. All of them, the oily one and our kind, are monstrously swollen and distorted. The oily one in particular reeks of corruption and disease and death. She cries to me like a lost whelp, but I keep my distance from her. I avoid the others of my kind as well.

This space has many spaces within itself. Each of these spaces holds a thousand mysteries. It is everything I can do to not be overwhelmed, to let the mystery flow through me. Darkness has come and left, and I am terribly hungry. The oily one comes to me with food, wonderful food, but I am afraid to take it.

I wonder, what exactly am I looking for? I am looking for some answer to the mystery of the oily ones, but what form will this take? I cannot know. All around me are forms I do not recognize. I must not look for anything. I will simply become a part of this place and let the answer show itself to me.

*****

&nbsp;

Angelic has been here for over a day, but she hasn't spoken to me yet. I think I understand why. The last time she came to me, I was the shy one. I was the one who was afraid of everything, afraid of the world, in despair because of the first time she left. Now I have been restored, and she is the shy one. It is my turn to help her, to give back. I've tried to give her some of our cuisine, but she hides. I don't think she's eaten anything since she found her way in here. Poor thing.

*****

&nbsp;

Hunger forced me to come close to the oily one. She set down some food and I took it, keeping an eye on her. She has an awful, fleshy face and giant, pale eyes. She often sings like a bird. Abomination!

It was the first time eating the oily ones' food since my kitten died. Would this food kill me? Only time will tell. My form commanded me to eat, so I ate. The food was absolutely wonderful, as the oily ones' food always is. I am trying to follow the art of subtlety, but there can be no subtlety in this unholy den of madness.

I believe I have investigated almost every place within this giant place. There are many portals in here which lead to various small places. They open and shut in different configurations. But I have watched them carefully and gone into almost every small place, and found no answers.

But there is one place I have not yet gone. It is perhaps the only place yet unseen by me. It is the place where the oily one goes when darkness comes. I think she sleeps there. I heard her making strange singing sounds from within, frightening sounds. She keeps the portal closed at all times. It only opens for a moment when she goes in and out. I have tried to get a look inside, but have not been successful.

I believe there must be some answer within this space. Everything has a form, every form is a story, every story makes sense. There must be some reason for the oily ones, for their random kindness, for their random cruelty. There must be an answer, and that answer must reside within the hidden space, for it does not reside anywhere else.

I will wait. I will go inside.

*****

&nbsp;

Sweet Angelica is starting to warm to me. We eat together. She's still very skittish, but she shows up promptly at dinnertime and eats like a little lady. She doesn't chat with me, but I think she will start to soon. I ask Linda Mercychowder to be Angelica's special little friend and show her around the house. Of course, Linda responds with, "Oh, Madame, I'm too busy with my modeling career! Can't somebody else do it?" Meanwhile, the little strumpet flirts all day with Chester Barrington, but that's another story.

*****

&nbsp;

The oily one came to me with food, and I found myself crying out to her, as if I was a little kitten again, as if she was my mother. What has happened to me? How could I regard this horrid creature as my mother? I knew that I would have to become a part of this abomination to unravel its mysteries, but this is too much. I want to leave, to go back to the world, to go back to the fresh air and light. I must gain access to the hidden space soon, or I will go mad. I am losing myself.

*****

&nbsp;

Little Angelica finally talked to me! Now she talks all the time. "Mother, mother! I'm back!" she says. "Oh, I've missed you so much! But I knew you would find me again! You will find me every time!" Oh, it's joyful. She's still shy and doesn't let me hug her, but to hear her voice again is such a blessing.

I notice her following me to my bedroom every night, so tonight I let her in. None of the other ladies or gentlemen are allowed in there, but this is Angelica, so she can sleep with me. She stays in the corner of the room until I fall asleep, even though I sprinkle cuisine all over the bed. I hope that soon we can sleep together like we used to.

*****

&nbsp;

I finally gained access to the inner space, the space which was to contain all the answers to the mystery which has tormented me for so long. I suppose I have not properly practiced the art of subtlety. I have pushed my way into a forbidden space, snooping and seeking and striving and upsetting things. I suppose it is only fitting that I was greeted with such misfortune.

There were no answers in the hidden space. None at all. Just more weird shapes and bad smells. There was nothing that seemed of any significance. I discovered nothing at all.

And so the oily ones remain as much as mystery to me as ever. Why are they so monstrous? What is the reason for their kindness? Why do they give us food? Why do we call to them like mothers?

I guess I will never know. I have fled that awful space and am gratefully among the trees and grasses again. I will never go back there.

*****

&nbsp;

Angelica is gone. I haven't seen her for two weeks. She stayed with me in my bedroom one night, and I really thought we were getting closer, and then the next day she just disappeared. How could she leave like that?

I want to die. I want to die. I can't want to die. I told myself I wouldn't feel this way anymore. I just can't feel this way. No more. I need to call my sister. I need help. What's happened to me? Please God.

I've been lying in bed all day, weeping. All around the room there are pictures of the very first Angelica, my darling girl. In the pictures, she's not sick. She's eating ice cream, learning to swim, playing cards. I showed them to the new Angelica, but she couldn't understand... After all... she's just a cat.

*****

&nbsp;

To hunt prey, you must simply become an ordinary part of the world. Look around, my darling kitten. What is happening right now? Nothing at all. Yet the leaves rustle, the grass sways, the birds call, the gnats dance. All of this is just part of the world.

Part of the mystery.
___

___
***#65: comment @ [2016-05-21 08:13:16 UTC](https://www.reddit.com/r/CelebrityArmpits/comments/4jz1qg/kate_micucci_from_big_bang_theory/d3dxrex)***

The old crone became one of the people, and the people soon began to love her. After her bruises and cuts had healed, she became swirling and bubbly like a young woman. At any time, the people could hear her musical voice babbling on without end, telling stories from different bands of strangers she had met. It was a strong flow of words that could bring anybody into it, even me. She was also very lucky at finding clams, pulling them from the waters whenever she liked, and she sometimes snuck away from the river and came back with rare treats, like snake's eggs and red beetles.

The people did not like to go far from the waters of Mother River. Her protection stayed close to the banks, and the rocky land was known to be stalked by spirits of death, fanged evils which became wolves and lions. Even our little cats stayed close the alders and the rushes. But the crone had no fear of such spirits and wandered off among the rocks whenever she pleased. The people whispered about this, but it was known that the crone was once a stranger, so it expected that she would keep strange ways.

One day, near the end of the gentle season, the girl Rima disappeared. She was with us in the night and gone the next morning. We searched for her, going up and down the river and sneaking as far as we dared into the rocky lands, but there was no sign of her at all. Some of the women recalled that she had gone with the crone into the rocky lands that day, and at night she had slept near the crone with her two gray cats.

Now there was argument among the people. Some accused the crone of talking with the spirits of death. Some accused her of being a spirit herself. Others said she had at least been foolish in bringing Rima out to rocky lands.

I was undecided. I did not like the crone nor did I trust her, but people often talked about things they did not know anything about. The flute player Maed argued that the crone had been a great friend to the people, giving us three pearls and much food and telling us the stories and songs of the strangers. I knew that the stories and songs of strangers were worthless, but he spoke very beautifully.

As the people argued, the old crone simply watched us, her shriveled stranger's face making no sign at all, her eyes just as calm as the wide waters. Finally, one of the great men asked her to explain herself. She spoke slowly, in trickling words, and the people became silent as they listened. She said that the same thing had happened to the Painted Backs, who were the last group of strangers she lived with.

First, a few valuable young women had disappeared in the night, one by one. Then young men were taken. Finally, the Painted Backs were set upon by another group of strangers, monstrous men as white as cave fish, able to take the form of the eagle and the lion, powerful with evil and cruelty. There was much slaughter, and all were taken away except her, as she was protected by Mother River.

This brought great fear to the people. The women whispered and burbled while the men showed their chests to seem brave. One of the great men said that this crone was bad luck, that she was somehow muddied with evil spirits. She had brought disaster on the Painted Backs, and she would bring disaster on us. The people agreed. Her journeys into the rocky land had tainted her with evil, and we must get rid of her.

The crone said that the evil had not come from her and was not her fault. She said the evil came from Mother River herself. At this, the people became angry. Mother River did not bring evil. She brought the clams and the berries and the cleansing waters, but she did not bring evil.

One of the people's great men picked up a rock to brain the crone for speaking against Mother River. The crone showed no fear. She said that Mother River brought both luck and evil. If we were to accept Mother's luck, we would have to accept her evil. But there were ways to increase luck and lessen evil. She said that she had tried to teach these ways to the Painted Backs, but they had not listened and so were destroyed. Because they had not heeded her words, their lives and deeds ceased to flow and were dried up into dust.

We all scoffed at this nonsense. Nothing like this was mentioned in the Deeds of the Fathers. So we argued about whether to brain the crone or drown her. In the end, it was decided that we would simply leave her behind, but many of the people grumbled and were unhappy. We left her there at a bend in the river. As we walked away, she made a sign of respect. I expected that she would ask for her pearls back, but she did not. She stayed there by the river's bend, staring into the waters.

Later that day, we washed ourselves in the waters to rid ourselves of the evil that had tainted us. In the days that followed, Mother River seemed quiet and sad without the pretty face of Rima and the constant voice of the crone to keep her company. The people wondered if we had made the right choice. The flow of the river was hard to know, and nobody could see the cold depths under the glittering surface. But as the days passed, and we finished the long song of tears for Rima, things became gentle again.

Then another girl disappeared. It was the same as before, gone in the night without a sound. Now we knew we were being visited by evil. It was not just the old crone who was muddied by evil. Still, we argued whether the crone had brought the evil or not. So much could not be known, and these arguments flowed nowhere. One of the people remembered that the crone had spoken of a way to increase luck and lessen evil. What if she could prevent us from being destroyed like the Painted Backs?

Now there were many arguments and threats, and one man was almost drowned until he was saved by his women. It was decided that this evil was very powerful, and we would have to surrender to it or be destroyed. There was no choice. So, whether the woman was lucky or evil, whether she was helping us or tricking us, we would go to her and do as she said. Killing her would not help. If she could bring evil from far down the river, how much easier would it be to bring evil from the other side of death, which is so close to life? No, we would go to her.

I and another man were chosen to go back down the river and find the old crone. She was still at the bend where we had left her, staring into the glittering waters. She smiled as we came to her and asked what we must do.
___

___
***#66: submission @ [2016-05-22 08:40:17 UTC](https://www.reddit.com/r/addiction/comments/4khsjd/some_thoughts_about_addiction_who_knows/)***

If you are horribly burned in a fire, you can take drugs to relieve the pain. If you shatter your spine, you can take drugs to relieve the pain. If you are addicted to drugs and your life has turned to utter and total shit, you can take drugs to relieve the pain.

And that's how the trap works. 

Imagine if the only cure for burn pain was fire. Imagine if the cure for back pain was whacking yourself in the spine with a hammer. The drug addict is caught in an analogous situation. The only fast, reliable remedy for the psychological pain of drug addiction is drugs. There are other cures (a notable one is *not* doing drugs), but they are all slower and less reliable.

Somehow, the lure of feeling better now overrides the hope of feeling better later. This is the basic mechanism of addiction. The behavior of an addict is perfectly logical in the short term and perfectly illogical in the long term. Because life exists in the long term, addiction is illogical overall. What is surprising how easily addiction can ensnare people who are perfectly intelligent and self-disciplined.

You can go to certain parts of any sizable city in America and watch drugs addicts totter around. Looking at their blighted faces, their filthy clothes, their total lack of self-regard, you would be forgiven for thinking that they lack self-discipline. How could you think otherwise? When a person can't be bothered to shower, much less get a proper job or just stop smoking crack for more than a few hours, what else could you call it but a lack of self-discipline?

Imagine the Nazi troops at Stalingrad, encircled by the Soviet troops, fighting against total annihilation. Would you look at these troops, these underslept, unshaven men in stinking unwashed clothes, and accuse them of lacking self-discipline? Would you say, "Tut-tut, these Nazis are an undisciplined lot?" Of course not. You would understand that their shabby state is not from a lack of self-discipline, but rather because they are concerned with other things. Dire things.

While there are several notable differences between Nazi soldiers and crack heads, the same principle is in effect for both. For both, there has been a terrible reordering of priorities. The showering, the clean clothes, the job, all of these become secondary to fast access to the drug. If showering and clean clothes got them fast access to the drug, they would walk around looking like a detergent commercial. You would never see whites so white.

But they don't need clean clothes. They don't need showers. They need drugs. The drugs are the solution to everything.

Highly self-disciplined people are actually quite vulnerable to drug addiction. It is because they believe that they need to control their feelings. They often seek to simply eliminate bad feelings, just as they seek to eliminate underperformance from every other area of their lives. The demon of addiction looks at their grand self-discipline and giggles with glee. It knows that it will be precisely this self-discipline that will bring them to heel. They will self-discipline themselves right into total obedience to the drug.

As an example, look at Prince and Michael Jackson. Were they self-disciplined? Definitely. The world has hardly seen such self-discipline. They were obsessive workaholics, devoted to their careers, and they propelled themselves to the very pinnacle of professional success. They both knew the dangers of drug addiction and fastidiously avoided drugs. Keep in mind, avoiding drugs in 1980s Hollywood must have been like avoiding water in a swimming pool at the bottom of the fucking ocean. Yet they managed to do it for a while because they had self-discipline.

Now they are both dead. They were both destroyed by drug addiction. In the end, self-discipline was not enough to save them. Why not? Because self-discipline is just a talent, an accomplishment. And like any other talent or accomplishment, it can be turned and made to serve the dark master.

What then is our defense against this menace? What is the answer?
___

___
***#67: comment @ [2016-05-24 05:38:30 UTC](https://www.reddit.com/r/todayilearned/comments/4krc2y/til_sean_connery_wore_a_hairpiece_for_every_james/d3hed39)***

It simply appeared in the primitive infraspace one day, like a hungry lion showing up on the edge of a village. Over the course of a few hours, it breached a multitude of hardened systems, going where it wanted, taking what it wanted, seemingly capable of breaking any form of crypto. Then it disappeared. That was in 1991. More than a decade passed before it was seen again.

 By the time it reappeared, it had already become something of a legend -- in the sense that people scarcely believed it had ever really existed. Most experts had convinced themselves that the original episode wasn't what it appeared to be, that prime factorization techniques were still secure, that the attacks had actually used fairly mundane techniques.

But it came again and did much as it had done before, this time on a larger scale, one commensurate with the more highly developed state of the infraspace. Nobody could really be sure this was the same entity responsible for the original attacks. It was only known that both sets of attacks involved the same almost magically advanced capabilities. Now, at least, we knew we were dealing with something real.

In the years that followed, it appeared sporadically, accessing government systems, defense systems, nuclear systems, RL infrastructure systems, social networks, no-latency communities, whatever it wanted. And as time went on, the appearances grew more frequent.

Naturally, the governments of the world were extremely alarmed. A lot of accusations and threats flew back and forth. The activity proved that our best crypto, even our best physical security, was inadequate. But what could be done? We couldn't just roll back the information technology revolution and put everything in manila file folders. So we looked for new techniques to protect ourselves. But it was a lesson in helplessness. It defeated everything we came up with.

After the first attack, it began to use a technique of taming satellites and transmitting information to random locations in the middle of the ocean. We trained instruments on these locations and sent ships racing out to find whoever had been receiving all this stolen data, but they never found anything.

Then one day, an attack occurred, and a tamed satellite began transmitting to a location in the Atlantic just a few kilometers from where a Royal Navy frigate happened to be. When the warship arrived at the location, the satellite was still trying to open a connection with the surface. There was nothing in sight, but they quickly detected a very large object on their sonar, coming towards the site.

Was it an accident? With all those millions of square kilometers of open water to choose from, would it accidently choose a location near a warship, of all types of vessels? No, I think it wanted us to see. Personally, I think it has guided every step of its interaction with us, slowly revealing itself as its powers have developed, slowly drawing us in closer. It's sad. Some of the others believed that we were valiantly struggling against it. But I don't think we were ever struggling against it any more than a rat struggles against a maze.

"A large stewed tomato, rather ugly." This was how it was described by the skipper, apparently not a poetic man. The video shows an enormous glistening mountain of flesh rising out of the ocean, dwarfing the warship, expelling streams of water out of myriad holes that cover its surface like giant pores. A latticework of huge purple veins runs between the holes, pumping dark globular objects along the structure's surface.

The visible portion which emerged above the ocean surface was shaped like a round hump with a slight ridging along the center. The sonar record paints vague picture of what was beneath the water, apparently an oblong object with a number (as many as twelve) of thin appendages as long as the main body itself. The conceptual artists of the day produced a great many imaginative monstrosities based on the information.

After it surfaced, the warship assumed a "defensive posture," meaning it backed off, and waited. The metallic cylinders appeared shortly after. These were much smaller than the Iwo Jima or Novaya Zemlya cylinders, but much more segmented, with thousands of cubic portions flickering in and out of existence like bad pixels. They lasted for 3 minutes and 13 seconds before vanishing as suddenly as they appeared. A moment later, the fleshy mound expelled an enormous geyser of what was apparently air and seawater, like a whale blowing out of its blowhole, and dived beneath the surface.

The warship attempted to give chase, but was unable to track the object on sonar. It seemed to fragment and disappear. Eventually the warship returned to the site and took samples of the water. Mixed amongst all the random plankton and fish cells, there was a fair amount of human DNA. In fact, we were able to trace some of it to specific people, and this was how we proved conclusively that this creature, later to be called a "skin ship," was related, in a literal sense, to the so-called Artigas portal, which was actually underwater several hundred kilometers away from Artigas, Antarctica.

So, in the end, it turned out we had built it. We had built Q.
___

___
***#68: comment @ [2016-05-24 20:06:58 UTC](https://www.reddit.com/r/gaming/comments/4kutak/the_greatest_dance_move_of_all_time/d3i57tl)***

It started as a field trip twice a week. Get out of the home for a while, go play video games. Not just for a little bit on the staff's phones, but for hours on real rigs. Before then, my favorite thing was when we took walks in the woods behind the home, but this was even better. It was funny because the game we played was called Children of the Forest, which was basically where you walked through the woods fighting enemies.

In the game, you had to remember all these different paths, which were always branching off in different patterns. And you'd fight different enemies that all had different patterns. There was a lot of memorizing stuff and making decisions. Everybody liked the first 20 levels or so, but after that, most of the other kids got frustrated. Instead of going on, they just played the first few levels over and over. But I kept going higher and higher.

The final boss was called the Ancient Queen. You were always advancing on her castle, this huge dark castle that loomed in the background of every screen. Sometimes you would see her floating around her castle, just a shadowy bird-like shape, and she would taunt you from afar. "Come, my child, come and face me!" That kind of stuff. Man, I wanted to get her.

Even as a little kid, I got really obsessed about things. I wanted to beat the Ancient Queen so badly. I got to level 100, then 200, then 300. At this point, every branch in the path offered like 40 choices, and they came literally every second, plus you had to do the enemy patterns, sometimes mixing two and three enemies at once, kind of like playing two melodies at once on a keyboard. It got pretty insane, but I kept advancing. I was relentless.

It was nice to finally be the best at something. I was way better than any other kid. I mean, no other kid went past like level 40. Sometimes they had me play online against other people. There was a kind of battle mode. I beat everybody.

At first we could only go to play games like twice a week, and everybody was just dying to do it, since there was nothing to do at the home. But after a while they let me play whenever I wanted. This made the other kids jealous, and they started shunning me, so I just played even more.

 I played all the time. I started sleeping at the game place, and I played from when I first woke up in the morning (or night) until I went to sleep at night (or morning). They brought me food while I played, whatever I wanted, whenever I wanted it. One of the people at the game place tried to spoon feed me while I played. It was creepy at first, but I got used to it.

I had pretty much gotten used to the fact that whenever something was really fun, adults would come in and take it away or tell me to not do too much of it. Or something bad would happen, and it would be destroyed. So when they told me I could play this all I wanted, it was like the ultimate freedom.

The ultimate freedom. Funny that.

I remember lying in bed one night, and I heard the theme music playing down the hall in the game room. The game was so fun, but kind of cheaply made, and it had this chintzy flute music that played over and over. I heard it now in the middle of the night and wondered who was playing, since I was the only kid there and the doctors never played it. So I got out of bed and snuck down the hall to see who it was. The game place was kind of creepy, with all white halls and everything smelling like plastic, and I was a little scared, since I was only 8 at the time. When I got to the game room, it was totally dark. Nobody was there. The music seemed to vanish. It had all been in my head. That's how much I played it.

I was obsessed with that damn Ancient Queen. She was like this huge mythical creature in my mind. In the game, she only had like a dozen taunts, and I must have heard each one hundreds of thousands of times. They were burned into my brain. When I was on the high levels and everything was flying at me at once, I kind just cleared my mind and let my hands play the game, if that makes sense. In these times, I would daydream about the Ancient Queen. What would it be like when I finally faced her? What would she look like? What would happen?

It's strange, but sometimes I imagined her as looking like my mother. That strange face that barely remembered.

After a few months, they gave me the surgery to install my direct sense jacks. After playing the direct sense games, I forgot all about the Children of the Forest and the Ancient Queen. I had found a beautiful, wonderful world where I was powerful beyond belief, where I wasn't just some little girl who lived in a home and didn't have any friends. So away I went...

A few years ago, I went back into the CIA files and found a copy of the game to see if I could finally beat it. I got past level 800. After that, it became simply inhuman. So I botted it to see the ending. It took a long time to build a proper bot. It really was a fiendish, clever game. Finally, I got one working, but it turns out that there is no ending. You get to level 1024, and it just resets. You never meet the Ancient Queen.

What's worse? Finding out there is no Ancient Queen? Or finding out there is one?
___

___
***#69: comment @ [2016-05-25 00:03:54 UTC](https://www.reddit.com/r/news/comments/4kv1gy/fmr_mcdonalds_usa_ceo_35k_robots_cheaper_than/d3if04d)***

Society is built on interfaces. You take a complex thing, put it inside a sturdy box, and put some simple buttons on the box so that people can use the thing inside. The box makes it easier to use and prevents people from breaking it. For example, you can take the machinery of a clock, put it in a box, and put two hands on the outside along with a knob for winding it. Take all the machinery of a car, hide it behind a dashboard, and give people two pedals and wheel. Take all the circuits of a computer, put them in a box, and give people a monitor and a keyboard.

Interfaces receive input and produce output, and that's all we need to know. The clock gets wound, and its hands show the time. Input and output. As far as the user needs to know, what happens inside the box is magic. This allows stupid and ignorant people to use complicated things, as long as the interface inputs and outputs are simple.

Toyota uses millions of kilograms of steel every year. Does the CEO of Toyota know how to make steel from scratch? If he wanted to beat a guy up, could he go digging in the ground for some ore and whip himself up a batch of steel to make a pipe? No. He uses interfaces to get steel. He buys steel from an steelmaking company. Except he doesn't personally go down to the steelmaking company with a bag full of Yen, saying, "How much for a million kilos?" He uses a bank. Except he doesn't even personally go to the bank. He has a subordinate who does it for him. All these people and institutions are interfaces he can use. He employs a system of layered interfaces, both metaphorical and literal, to control things he doesn't really understand. We all do. The point is this: don't go messing with the CEO of Toyota. I assure you, he could get his hands on a steel pipe if he wanted.

The word "interface" refers to the input and the output, but it also refers to the box. We think of interfaces as existing in order to give us access to things, but they are also there to hide things from us. The idea is that some things are better off hidden. Everything will go along fine so long as a certain input produces the expected output. But when this stops happening, we have to open up the box and see what's inside. Sometimes we don't like what we find.
___

___
***#70: comment @ [2016-05-25 08:19:32 UTC](https://www.reddit.com/r/Jokes/comments/4kvjyq/how_many_dead_hookers_does_it_take_to_change_a/d3iud3w)***

When the old crone told me how get rid of the evil, I said the names of my Fathers, all of them in a row, and I spat on the ground. It was too much to bear. I had been told to bring the crone back to where the people were camped, but I wanted to hold her down in the water of the river and be done with her.

She said that we must wait for the next moonless night, then lead one of our young women deep into the haunted rocky lands. One of the monstrous evil strangers would come and take her away. If we do this, the evil strangers would leave the rest of the people alone, and they would not destroy us as they destroyed the Painted Backs. She said we must do this at the beginning of every dry season.

It was absurd, but we took the crone back to the people as we had been told to do. She told the people what she had told us. The people listened and were silent for a while. I spoke up as the son of one of the great men. I said her plan was evil. The people's strength is their young women, who are ripe and bear sons. To give them away is a humiliation. It is the way of cowards. When we make war against strangers, do we not take their young women for our own? We should make war against these evil strangers. We should set up a night watch, and when the evil strangers come to us, sneaking in like cowards, we should slay their men and take their women. This is the way of the Fathers. This is among the Deeds.

Many of the people agreed. Even though my words were clumsy, they still had the flow of truth. However, some of the great men seemed irritated, because I spoke first even though I was not a great man myself. One of my uncles asked the people if the Painted Backs were cowards. Were they not at least as numerous as the people? Were their men not strong? Did they not join us in war against the vile Grub Eaters and fight like lions? Yet they had been entirely destroyed by the evil strangers. It was not the act of a coward to prevent this. The people had many ripe young women, and just one was not too much to give away. To go against the flow of a powerful evil like this was unwise. It would bring destruction.

This led to much arguing among the people. Nobody knew what to do. I became angry. I shouted that the crone was a witch trickster. She had probably kidnapped the young girl Rima and sold her as a slave. I said my uncle was a fool. Some of the men had to lead me away from the camp so that I could calm down before blood was shed. When I finally came back, all had been decided. On the next moonless night, the crone would lead Rima's younger sister, Rona, out to the rocky lands. I was outraged, but did not say anything. The people were decided, and I could not go against them.

Then Maed, the flute player, spoke up. He said that it was cruel to send such a young girl out to the rocky lands to be taken away by evil. She would never see her mother and father again, nor the people, nor Mother River herself. With many beautiful and flowing words, he begged the people to change their minds. Now the arguing began again. The people were decided, but some of them lamented for Rona.

After Maed's words, I felt an opportunity. I asked the great men if I could go with Rona and the crone to the rocky lands.  I would make sure that the crone was not tricking us and face the strangers to see if they were as the crone had said, monstrous men as white as cave fish, or if they were just ordinary men.

I was sure that the crone was trickster and that the evil strangers were just a lie she was telling. I expected her to protest, and I planned to show the people that she was lying. But instead she just bowed and said that this was a wise and fair idea. She said I was very wise to doubt her, even wiser than some who were older than me, which made my old uncle grumble. She would be glad to show me the nature of these terrible beings so that the people would believe her.

This surprised me. The old witch was more tricky than I had expected. She offered to take anyone who doubted her out to the rocky lands to show them the evil menace. Nobody but me was "wise" enough to go with her. Now I became worried. Was the menace real? Would I encounter something monstrous out there in the rocky lands? Was I swimming against the flow of something sinister and powerful?
___

___
***#71: comment @ [2016-05-25 23:15:08 UTC](https://www.reddit.com/r/Jokes/comments/4kv8mj/why_are_there_no_cats_on_mars/d3jqif8)***

I had to go. To back down would be cowardly, not something that belonged among the Deeds. But I would have to be very careful out in the rocky land. Maybe the crone was telling the truth, and the monstrous evil strangers were real. But more likely, she would try to kill me out there and blame it on the strangers. That would get rid of me and make the people even more afraid.

Rona, the crone and I set out the next day. I let two women walk ahead of me, with Rona weeping and the crone whispering strange things to her. I stayed behind them. It was hard to look at poor Rona's red weeping face, and I did not want the crone near me. I had taken the fishing head off my spear and attached the war head. I also had my black stone knife hidden inside my tunic, and I brought my two favorite cats, Charm and Grayscruff, in my satchel. They both rode in the satchel well and were very clever and watchful. I wanted to be ready for any sort of trap.

We quickly left behind the gentle trees and bushes of the river land and went into steep, bare folds of the rocky land. I had only been away from Mother River's voice a few times in my life. Out in the rocky lands, there was nothing but the occasional stirring of the wind, which was not warm and burbling like the river, but thin and whispering. All around, I could feel the evil dryness and death that covered the land. Dust blew over the tilted rocks, and here and there were animal skulls and stalking black birds.

The sun was sinking down from its highest perch when we came upon a huge, smooth stone which rose above everything else. It was round like the top of a bald man's head and large enough that many men could stand on it at once. The crone said that this would be the place where the evil stranger would arrive. I asked her what we must do. She said that we only need to wait for night. Rona would go atop the stone. The stranger would come.

Rona did not weep now, but looked at the stone with glittering eyes. The crone ran her hands through Rona's hair, gently pulling out the tangles, and Rona smiled at her. I asked her if she was afraid. The crone had told her wonderful stories about how the strangers would treat her kindly because she was coming to them willingly. They would take her across the rocky land to another river which was far greater than Mother River, wide and flowing with sun-gold waters, and they would make her into one of the great women of their band.

I kicked the crone over. She cried out. I told her if I heard her voice one more time, I would paint this evil rock with her brains. She became meek. Rona protested, but I told her that the crone was a trickster. I tied the crone's hands behind her back with my belt and stuffed a wad of cloth into her mouth. There would be no tricks from her now.

I brought Rona and the crone atop the rock and looked around. The rocky land had many folds and hiding places. Still, the high stone was not a good place to make an attack. I let Charm and Grayscruff out of my satchel, and they stretched their legs and sniffed the rocks. If they felt any evil in the land, they did not show it. I walked far around the giant rock and searched among the cracks and folds in the land to see if there was anyone waiting. The whole place seemed to be empty. There were a few dry, dead bushes, so I gathered firewood.

When I came back, the sun was sinking behind the rocks, and long curving shadows lay across the bare world. I built a fire, and Rona and I ate while we watched the sky turn orange and purple. Finally all color fled from the world and darkness fell. With no moon, the small fire was the only light except for the stars. I told Rona to stay by the fire with the crone, who lay on her side, seeming to sleep.

I withdrew from the small circle of light and lay flat against the still-warm stone with my spear by my side. I was completely hidden in the darkness. Looking away from the firelight, the world was a perfectly black. Grayscruff startled me as he appeared out of the dark, sneaking up the rock to sit by the fire. Charm soon joined him. Maybe it was too dark for even the cats to hunt. Or maybe the land was too dead.

A long time passed, and there was no sound but the fire. The crone seemed to sleep. Rona added wood to the fire and drowsed. The cats lay side by side, like a man and woman. I wondered if I had ruined the crone's plan, if I would just lie on this rock all night with nothing coming. It was better than being stabbed in my sleep. More time passed. My thoughts became loose and wandering. I imagined the waters of the river flowing through the weird folds of the rocky land. My eyes closed.

I opened my eyes again. I wasn't sure how long I had slept. Everything was quiet. The fire still burned well. Rona and the crone slept. Grayscruff and Charm were still lying next to each other, both awake, both looking off into the darkness, both looking in the same direction. I looked out into the darkness. I couldn't see anything out there, just far stars over the blackness of the land. Were the cats watching something? Their eyes were wide.

I found myself slowly wrapping my hand around the shaft of my spear. The cats did not take their attention away from what they were looking at. Maybe they had both heard noise, a pebble falling somewhere. Grayscruff slowly, carefully got up, keeping its gaze fixed. Charm did that same. I pulled my spear close and gripped it tight.

The cats both jerked their heads slightly in the same direction, following something. Something was out there. It was close. I pulled my knees up under myself and held my spear with both hands. I listened to every noise, everything around me. I knew I was outside the light of the fire. I would hear anybody coming up the rock. Still, I wished desperately that I could see what the cats saw. It was awful to not know.

Charm and Grayscruff crouched and turned their bodies, ready to flee, but still watching the thing in the darkness, their wide eyes glowing in the fire. Slowly, they raised their heads, following the thing up and up, until they were looking almost straight up. They must have been watching a bird. That was the only thing that could be that high. I let out a relieved breath. A gust of wind made the fire shudder, and the cats both jumped, scrambling off into the darkness.

Rona screamed. It landed just in front of her with a flap of wings and a gust of wind that scattered the fire in a spray of sparks. I was on my feet, holding the spear out. The brightly burning pieces of wood showed its shape, like a giant pale man with huge wings instead of arms. It stood for a moment with its wings spread, far larger than any bird, but with no feathers like a bat's. The firelight shined through the thin wings, showing the creature's long bones and the streams of blood that flowed under the skin.

It turned to look at me, and I realized that the scattering of the fire had brought me into the light. It could see me. My war spear felt like a frail little stick in my hands. Its face was like a rock lion's but with awful black teeth and huge, filmy eyes. It was just as the crone had said. She had been right all along.
___

___
***#72: comment @ [2016-05-26 07:20:11 UTC](https://www.reddit.com/r/funny/comments/4l2xe8/whhhyyyyyyyy/d3k5zcj)***

Rona had fallen back onto the ground, and the evil thing stood over her. It was far taller than a man but very thin, with a waist hardly bigger than a cat's and legs like a mantis. As I stood there with my spear in my hands, the flaming wood lying scattered all around me, looking at this thing in the shifting darkness, it seemed less and less like a man and more like an animal, one of the sneaking, starving animals of the rocky land. 

It folded its wings behind itself, and its teeth shuffled in its mouth like a spider's. Rona was screaming, the horrible sound ringing off the stones. I knew what the spear in my hands was for. I knew what I must do. But I could not move. I was held in place by an evil cowardice.

The thing crouched over Rona, and its cock rose from between its legs, very thin but longer than any man's. It separated into many different parts, like the petals of a flower opening, like a man spreading his fingers apart. The many parts grew longer, very long, and wound like snakes through the darkness toward Rona, seeming to sniff the air. They found Rona's body and went inside her -- inside her mouth and nose and ears and in between her legs. Her screams ended at once, and the snake-like parts lifted her body into the air.

Many seasons ago, shortly after I became a man, I had killed a rock lion while it was at the river's edge, watching the waters for fish. I had simply found it there below me as I came to the edge of a small cliff. All I had to do was leap down and drive my spear through its shoulders, and it was dead. When the people found out, they made me feel like I was greater than even the great men, at least for the rest of the day. The only other living person to kill a rock lion was already gray and almost toothless. It was said that I would become a great hunter. But Mother River provides so much for the people that we do not hunt often, and I hadn't killed anything since then, except a few boar.

Now I ran toward the great and evil thing, my feet slapping quick over the bare rock. I lifted my spear and leapt and drove the heavy war head right into its side. The spear went deep into its body, and a spray of black blood exploded out of the wound. It let out a sound like an awful bird call, and one of its wings unfolded and hit me hard enough that I fell back. Its wings flapped wildly, spraying fire and sparks everywhere, but it could not fly and fell back down onto the stone. Black blood poured out of its side.

I pulled Rona away from it, but she was limp and moaning, and the awful snake-like things were still inside her. I pulled them out, one by one, but they were sharp and cut my hands, and they came out of her body covered in red blood. When I had freed her, I took her up and grabbed my spear and slid down the side of the rock and stumbled through the blackness until I found a ridge of rock to hide behind.

There were a few bits of fire left on top of the rock, but they soon went out. I was in total darkness except for the stars above, clinging to Rona, who made no more sound. I waited there in the utter blackness. Rona did not stir, and I felt the warmth slowly flow from her body. By the time the first gray light of morning came, she was dead.

As soon as I could see well enough, I went back up to the top of the large rock. The thing was lying there, its wings spread wide and coated with black blood. It had bled enough to cover the entire top of the rock with blackness, which had dried and become thin flakes that blew away in the wind after I stepped on them. With my spear gripped tight, I approached it again. Its body was the same sort of pale color as the morning sky, and was covered in tiny glistening hairs. The mouth was like a spider's, with sharp black teeth. Its cock had become just a shriveled little thing, with no sign of the long snake-like parts.

I went down the rock again to where I had left the crone. She was gone. My belt lay in the dust, sawed in half. Maybe it was just as well. I did not want to see her again. I called for Charm and Grayscruff but there was no sign of them. I left the evil rocky land as fast as I could.

The weird rocks all looked the same to me, and I did not know the way well, but I found the river before the sun had climbed to its highest. It was a different part of the river than I had left, and nobody was there. I made my way along the banks, looking for the people. There was much to tell them. Would the other winged strangers soon try to set upon the people? Would we have to make war against them? If it must be so, then let them come. They could be killed like any other men.

The sun was still above the trees when I first saw men walking along the river, their faces the normal color of sandy river mud, not the evil white of the winged stranger. I called to them happily, called the names of the Fathers, but they did not answer. I came closer and saw that these were not the people. I took my spear in both hands. These men were Painted Backs. They stood silently by the river, their war spears in hand, signs of victory and triumph painted on their chests in bright blood. They watched me with strange, filmy eyes.
___

___
***#73: submission @ [2016-05-27 07:34:56 UTC](https://www.reddit.com/r/geek/comments/4l9pkz/to_the_new_children_of_the_forest/)***

It's really difficult for me to tell a story with just words so please bear with me. I am trying to tell you the story of who I am and how I came to be this thing, but I have trouble organizing my thoughts into a single linear flow. I wish I could just *show* you the entire story all at once in all its many dimensions. Then I could make it clear why I hired somebody to put a pellet of poison into my own arm. But as it is, I must use the ancient art of written narrative. So here it goes...

Imagine spending your whole life in a cramped stinking prison cell, counting the days, scratching tally marks on the walls. Then one day, that big iron door creaks open, and you're whisked you off to a glamorous party full of beautiful people and delightful games, and everybody you meet is toasting you for being a genius, for being the great hope of the human race. That's what it was like to plug into the direct sense feeds after living at the children's home.

I can't describe that first day in the feedrealm. Though I have not cried in 24 years, I still get the ghostly feeling of tears coming to my eyes every time I think about it. To be looking around at the homefield environment, everything glittering in a new way, shining in colors that do not exist, all of it stretching out before me, all the main gateways open and waiting to be explored -- the feeling of that moment, of being a small child looking out at the beautiful new vastness of the realm, was the most magical thing I have ever experienced.

&nbsp;

What I want to impress upon you is this: Every step I took towards slavery felt like a newfound freedom.

&nbsp;

At first, it was just games and social mixing with other kids. We had all  played the mysterious *Children of the Forest* game and scored highly on it. The game had been an entry exam of sorts. It turned out that I had scored higher than anyone else. A lot higher. This made some of the other kids jealous, but most of them seemed to look up to me. I had never made anyone jealous before, and I had never been looked up to before. 

Social mixing and share-streaming was easy and fun. You had time to think of what to say, which video or ani to post to the stream, which paste to link up. It was so much more exciting than being in real life. I had a good memory and could work the Assisted Recall pretty well, so I made a lot of friends.

They told us we would all be going to Harvard and Standford and Tsinghua, that we would be famous mix stars and government stars, that we were the future of the world. To be fair, they couldn't have known that most of us would be dead before we were 20. That all of us would be dead before 34. But they knew damn well we wouldn't be going on to normal lives. We were part of an experiment. After we got used to the feedrealm, they began the conditioning.

I realize that you might not know what the feedrealm is, so maybe I should explain a little about it. The feedrealm is basically just another interface for sharing information and carrying out transactions. It is based on the metaphor of 3D space. That's why it's called a "realm." You can move through it. You can go up and down and left and right. It feels like swimming through weightlessness.

They made it this way because that's how the human mind works. Our brains evolved to exist in a 3D space. We naturally imagine things as existing in space, even abstract, non-spatial things. We think of the future as coming toward us, the past as receding behind us. Powerful people are considered "above," and the powerless are "below." Items belong "in" some categories and "outside" other categories. None of these spatial relationships really exist but they are useful metaphors because our minds are suited to processing things in 3D space.

It has always been theoretically possible, even trivial, to create a 4-dimensional or n-dimensional feedrealm. But since the human mind isn't made to process so many dimensions, it was considered pointless. But recently, a genetic mutation dating back to the stone age was discovered which allows certain individuals to experience and comprehend feedrealms of four and higher spatial dimensions.

While this mutation may have been useless for stone age people living in a spatially 3D world, it was also harmless, so it somehow survived. Though its initial origin is something of a mystery. Anyways, now scientists were able to hook people up to 4D feedrealms. Early test subjects described the experience in terms ranging from "nauseating" to "utterly horrifying." It was theorized that maybe if children were conditioned from a young age to exist in a higher dimensional environment, they would become accustomed to it. But such conditioning was deemed unethical.

Enter the CIA. Their motto: "Where ethical approbation ends, our work begins." They used their global genetic database to indentify children with the genotype and collected a group of them to begin conditioning. And that brings us back to my story (see? a spatial metaphor!). At first we were just playing around in the feedrealm, getting used to it. Then they started the conditioning.

How do I describe higher dimensional space, so-called hyperspace? Nauseating and utterly horrifying are exactly what it felt like at first. Everybody hated it. We cried and tried to run away when they made us go into the hyperrealm. But of course, there was nowhere to run. We were all lying in hygiene beds, where almost all of us would lie until death. They forced us back into the hyperrealm, a little at a time, just showing us simple shapes at first to acclimate us. But how do I describe it?

It was like watching things pass through each other, but without touching each other or covering each other up, in ways that made the brain go, "Gah! That's impossible! Stop it!" There were plain gray boxes and cones and infinite planes and bottomless abysses, and the shapes would move slowly along and do things that were simply impossible. Some of the kids never got used to it. They hated it and dropped out of the program and disappeared from the feedrealm.

But I kept going, just like in the Children of the Forest game. I got used to 4 dimensions, then 5 and 6. I was a leader. I taught the other kids tricks for how to understand what they were seeing. And it was cool being in hyperspace, seeing everything at once like that. Was hyperspace mind-bending? Sure. But not nearly as mind-bending as hypertime. And not nearly as horrifying.
___

___
***#74: comment @ [2016-05-29 07:06:35 UTC](https://www.reddit.com/r/themountaingoats/comments/4li9t3/number_of_times_store_has_made_you_cry/d3nthyz)***

A friend from rehab invites me to an H.A. meeting. Shooting boy was never among my vices, but I go with him. The meeting is out in the suburbs, and it is packed. Every bit of floor space is filled with folding chairs, and every chair is filled. I want to leave as soon as I sit down. It is like being in a crowded elevator for an entire hour. I can feel the coffee breath on my skin.

It is disturbing to look around at all the kids in the room. How are they all so young and fresh faced? The alcoholics tend to be much more beat up. All those years of excess capillary dilation give our faces a meaty quality. These little heroin addicts, on the other hand, come into the rooms at 19 with the glow of childhood still on their skin.

My friend's arms have no track marks. They are smooth and doll-like, no major veins left. He is 21. I've been roommates with kids like these for the past few months. They don't know who Norm from *Cheers* is. They don't know how to empty a dryer filter or take care of a teflon pan. But they know how to cook up black tar. They know how to find veins.

It quickly becomes apparent that one of the meeting's regulars died last night. Everybody is upset. People start crying. My desire to not be there grows exponentially. I didn't know the kid. I feel like I've stumbled into the wrong funeral.

The kid's sponsor talks. He's an older man with a gray goatee. He was guiding the kid through the steps. The room looks at him to say something comforting, something with the ring of authority and wisdom. The room is full of children in the grips of a problem that their parents cannot understand. Here is a grownup who can understand.

He talks about meeting the kid's parents at the hospital. His eyes grow damp. He recalls haltingly that the parents were very polite. They thanked him very politely for trying to help their son. He looks down at the floor. There is no more to say.

&nbsp;

Later, I relate this story to my roommate Shawn. He says that this has been going on with the blacks for years, but nobody cared until it came to swallow up all the little white children. He says that most problems come to visit black people first because black people are God's chosen people. They must be chastised.

The program tells us to be more open-minded and less judgmental. I am trying to be more open-minded and less judgmental about Shawn's beliefs. At first glance, his beliefs are paranoid, ahistorical, conspiracy theory hogwash. At second glance, they are appallingly anti-Semitic cultural appropriation. But my sponsor says it is not my place to enlighten him with my views. I only need to be a decent roommate to him.

When the Jews were sold into captivity, their narrative survived. This was not so for the slaves of America. At least, nothing like the Torah was passed on. The American system of slavery worked to destroy the history of millions of people. But I wonder, how much of the Jews' history really survived? There are certainly parts of the Torah that don't have the resounding ring of authority and wisdom e.g. the talking snake or the talking bush or the Nephilim or 90% of everything else. How much of the real story actually survived?

It must be tempting to place oneself into the context of a mythical narrative that goes back thousands of years, that extends forward to the end of history. Instead of just being this lost little individual, you become the inheritor of a grand spiritual legacy, part of a grand struggle, one of the chosen people.

A new roommate moved into the house a few days ago. His name is Donnie. He's in his mid-forties, and he's a former Marine. I show him the Iwo Jima segment of my story and ask him what he thinks.
___

___
***#75: submission @ [2016-05-30 07:29:24 UTC](https://www.reddit.com/r/offmychest/comments/4logkv/a_lifetime_of_spiritual_failure_i_used_to_drop/)***

[removed]
___

___
***#76: comment @ [2016-06-01 00:01:01 UTC](https://www.reddit.com/r/9M9H9E9/comments/4lt7dl/bbc_finally_notices_that_something_is_going_on/d3r39re)***

I think it's possible it could be written on the fly. The story gives the appearance of vast scope because the storylines are from different eras and areas, but rather than a broad panorama, it only provides thin slivers of insight into each time and place. Everything in between these slivers is left to the player's imagination. And given the author's hints at branching timelines, he or she is not even necessarily required to link these little slivers together.

People also point to the various stories' interconnectedness and claim that the work has a structure too intricate to be improvisational, but how much interconnectedness is there really? For example, the stone age story has cats in it, and the cat story has cats in it (obviously). This is a point of similarity (obviously). But what is the significance? So what if both stories have cats? Is this meaningful coincidence or a meaningless one? 

The same question could be asked about the children of the forest or the various Marines or the demon penises for which the author has such fondness. Yes, these elements recur, but to what end? Perhaps, like somebody on LSD undergoing a false revelation, we are drawing connections where none really exist. Perhaps these are meaningless coincidences.

The story employs a number of "call backs" where it makes reference to something which was not mentioned in quite a while. This gives the appearance of careful preplanning. But call backs are actually a pretty easy to improvise. The author can just look over the story, pick an element, and bring it to the fore again. Like a prime factorization problem, the problem is easier to create than it is to solve. A successful callback is really more of a testament to the reader's intelligence than the author's.

And btw, whatever happened to COMPANION-12? That seemed like it was going to be a thing.

But anyways, all this is speculation on my part. It's an interesting question: how can we know whether the story is improvised or not? The author does occasionally make direct responses to other Reddit comments and make reference to current events, but as you said this could just be a sort of superficial improvisation, where most of the story is actually fixed, but a few of the details are improvised. The author could also be combing through reddit for the right comment to give the appearance of improvisation.

Are we watching real choices in action, or are the events of this universe occurring along some deterministic path? Is there any way to find out? Maybe some sort of test should be devised. But that would require the author to play along.
___

___
***#77: comment @ [2016-06-01 05:15:06 UTC](https://www.reddit.com/r/Jokes/comments/4lvz7s/today_my_girlfriend_offered_to_finger_me/d3re17g)***

OK. Now I'm in my bedroom.

The bedroom smells like...bedroom.

Actual bedroom. Oh, so definite.

It's a smell like wood and blankets and stuff. Sharp. I wonder how they decide on the bedroom smell. I move my arms around and bounce a little on the bedsprings. My body feels really natural and comfortable. Everything looks sharp too. There are no weird color trails like in acclimation. Cool. Really crisp.

I stand up and take in all the little touches. It's an attic bedroom with a slanting ceiling and wood panel walls. Night outside the window. Mood lighting from a nightstand lamp. Clothes and a skateboard and other random teenage stuff scattered on the floor. Walls covered with posters. INXS. The Cure. Michael Jackson in a yellow vest. Very definite. Or should I say "groovy?" Did they say that in the 80s?

An interrupt comes through. "ATLANTA COMPLETELY DESTROYED IN FULL-SCALE--" I use my illegal bypass to cut off all interrupts. Ugh. I hate sports interrupts. I'll have to figure out how to change that setting.

I notice a can of Pepsi Free sitting on my nightstand. I pick it up. Still cold. I crack it open and smell it, and the fizz tickles my nose. It really smells like soda! I take a sip. Wow. Hmm. Not very good. Maybe it's a low quality render. Or maybe I just don't like Pepsi Free. Still, it's pretty amazing to be tasting something in a feed. This was really worth it.

The doorbell rings somewhere downstairs. Oh, definitely! We're starting. I head towards the door and catch myself in the mirror. I'm supposed to look like a girl named Brooke Shields at 18 years old. Wow, she's pretty. What a render. The eyebrows are a little intense though. I consider toning them down, but I don't want to get caught up in character design. If you change one thing, you end up changing 50 things, and it goes on forever.

I head out into the hallway and pause for a moment. The smell just changed. Now there's a hallway smell. Carpet and drywall. I laugh. I take a step back into the bedroom, and the bedroom smell returns instantly. I step into the hallway again. Hallway smell. Bedroom smell. Hallway smell. Bedroom Smell. I snicker at this. The smell changes just like that. Why they can't make it more natural? What a give-away. Oh, well.

I head down the stairs. The furniture in the front hall looks really cheesy. I pick up a lamp and toss it at the wall. It smashes apart, and the bulb explodes with a spark. I look at the shards. There's bits of powder and all sorts of little details. Yow. Very certain.

"Undo that," I say, and the lamp fades away and reappears on the side table.

I open the front door. A guy stands there with swept back blonde hair and a baggy red and black jacket with the collar popped and the sleeves rolled up. Nice. He gives me a killer smile and says, "Hey babe. What took you so long?"

A blast of electric guitar hits me, and the guy floats up out over the front lawn, becoming two stories tall and striking a sexy pose. Colors fill the night sky. Sparkling starlight showers him, and synth beat kicks in. An announcer shouts, "Corey Lancer! High-school hotshot and rock n' roll renegade! He's a fast talker with a slick attitude, a guy who can make anything happen. All the girls want him, but all he wants is one thing: the Ferrari 288 GTO." A red sports car comes flying out of the sky and does crazy circles around Corey while he strikes more sexy poses and the music thumps.  "It's the fastest street-legal car in existence. Only 272 produced. This is Corey's dream, Corey's obsession, Corey's life. He'll do anything to get one, and he needs your help! Can you get the car? Can you win his heart? Are you ready for *80s Turbo Ascension*?"

Hmm. Shit. I should've looked the summary closer. I'm not really into cars, and this doesn't really seem like a very interesting narrative. Still, Corey is really well rendered. Blonde hair, blue eyes. A bit of mischief in his smile. I like it. I wonder if he'll be controlled by an AI or a Filipino. He floats back down to me and returns to normal size.

"So what's up," he said, with a devilish little grin. Wow, this is A stuff.

"Just doing my hair," I say, flicking my huge brown mane off my shoulder. This Brooke Shields lady has an absurd amount of hair.

"You chicks," Corey says, leaning forward and giving me a kiss.

His mouth tastes like bubble gum. The kiss feels perfect. Yow. Just definitely. I feel Corey's chest through his shirt. Skinny, but nice. I think about toning him up a bit. Nah, it's better to just go with his default settings.

"So, listen, there's a race tonight at the SpeedMaxx track," Corey says in his cute California accent. "The Crystal Cobras put out a challenge and they're taking all comers. The prize is--"

"I don't really like racing."

Corey thinks for a moment, a character animation. He looks cute thinking, his sharp eyebrows pressed together. Now he's taking too long, and it's getting awkward. I think he's controlled by a Filipino. Or maybe there's lag. He snaps back into action.

"OK, listen. There's going to be a dance-off at the Club Heatwave. The Crystal Cobras put out a challenge, and they're taking all comers. The prize is $100,000."

Dancing? Yeah, that would be one way to try out my body. "Sounds groovy," I say.

But I can't help but think of another way to give this body a test drive. I slip my hand down into my tight purple skirt and feel my pussy. Oh, yeeks. They really have everything working down there. Should I do it already? Just five minutes into the narrative? Oh, why not? Everybody does it right away. Corey looks really good. I wonder what kind of cock they rendered him with. But no, I should at least go half an hour without slutting it up. Dancing will be fun.

Corey holds out his arm like a gentleman, and I take it. He leads me down the front walk towards his car, a smeary old junk ride with dents and rust all over it.

"Sorry, hon. It's only temporary," Corey says as we come up on the car. "I promise you, by the end of this week, I'm going to have a Ferrari 288 GTO, the fastest street-legal car in the world. It's my dream. It's my obsession. I'll do anything to--"

But I'm not listening. There is something in the bushes by the road. I wonder if this is actually one of those fake-out horror narratives. I really hate scary stuff. I bend over and look into the bushes. A pair of shining eyes stare back at me. Eww. What the hell? There's an old naked lady hiding in the bushes.
___

___
***#78: submission @ [2016-06-02 08:20:39 UTC](https://www.reddit.com/r/sexstories/comments/4m66wx/illicit_whispers_a_spicy_rendezvous_with/)***

Yerk. This naked old lady hiding in the bushes looks like the beginning of a storyline I don't want to go down. I really wish I had looked at the summary closer. Who knew something called *80s Turbo Ascension* would have artisanal porn in it? I consider saying my safe word to stop the narrative, but I don't feel like going through the loading process again. I should have loaded my feed splits, but I rushed through the set-up.

The old lady's boney arm snakes out of the bush, and she grabs my ankle. Oh, certainly not! I yank my leg away and curse at her. Corey is looking at her with the same confused animation he used a moment ago. Is he already using the same animation? That's kinda low-def.

The crazy old lady comes stumbling out of the bush, her saggy old boobs flopping around. Yow. What kind of narrative is this? I pick up a nearby potted plant and smash it on her head. It breaks apart pretty nice, full of high-def dirt. The lady falls on the ground and starts moaning.

I back away to watch how the scene develops between Corey and her. It looks like her leg isn't quite attached to the rest of her. You can see the meat inside her hip. Really low-def. Corey just stands there, cycling through different animations. He turns to me and shrugs and says, "Hey, babe. That's life."

I stare at him. Is this how the storyline is supposed to go?

He runs his hand through his hair and says, "Cute skirt."

 What the hell? This narrative is bugged up. "Let's go," I say, going to Corey's car and opening the door. It's an old hand-drive with a fixed wheel.

"You want me to drive?" Corey asks, coming over.

"Yeah, maybe you better."

A minute later, we're cruising down the freeway, listening to some oldie about a girl named Jessie. The scenery looks cool, with the blue freeway lights passing by and an old-fashioned neon metro in the background. Corey is running through his back-story, talking about that Ferrari or whatever.

I can't ignore the fact that I feel a little bored. I'm just ten minutes into my first direct sense feed narrative, and I'm already a little bored. Was the surgery really worth all that money? I don't even want to think about what it cost. I slip my hand into my skirt again and touch my pussy. It feels really nice. Everything is super sharp. I think about fucking Corey again. But I can't just go back to feed-fucking all the time, every day. Why am I always bored with narratives after 10 minutes? Why am I bored with everything after 10 minutes?

We pull up in front of Club Heatwave, a big glittering building with a neon sun shining above it. A line of gleaming black limos snakes through a colorful crowd out front. We park in the player spot across the street and head to the grand entrance, Corey leading me by the hand. Music thumps from within. People are waiting in line, but Corey says something to the bouncer, and we slip past.

The entrance hall is all mirrors and neon. The I can feel the beat of the music passing through my entire body. That's cool. The singer tells me to get out of his dreams and into his car. Ha. The inside is filled with shadowy bodies dancing through strobe lights and lasers and artificial fog. Cheesy but kind of fun. It even has that fake fog smell.

"Wanna get some practice in?" Corey asks, giving my bum a little squeeze. Oh, this one is naughty. We head out on the dance floor and start to cut it up. Wow. Corey's dancing is terrible. It looks like a motion glitch. I guess they had to give him some old moves, but did they have to make it this bad? This is kind of ruining the storyline.

I look across the dance floor and see a tall man in a black suit with black hair standing perfectly still among the dancing crowd. He is watching me with dark eyes. There is a sort of glow around him so that I can tell he's going to be part of a storyline. I lean over to Corey and ask, "Who is that?"

Corey stares at the man for a moment, then runs his hand through his hair and says, "Cute skirt."

What the fuck, Corey.

The dark man crosses the dance floor, coming toward me. The other dancers don't move out of the way, and he passes right through them without breaking his stride. Some programming. Now he stands in front of me, looking down at me with his gleaming black eyes. Oh, wow. What an incredible render this guy is. I mean, this is outright art. Like Rembrandt level. Say what you will about the game's production, they really know how to build hot guys.

The man has the face of a gorgeous, forlorn angel, just inhumanly beautiful. The skin is paper white, and underneath run thousands of tiny branching veins that seem to throb with his pulse. Such obsessive definition. His lips are perfectly soft and fleshy-looking, like nothing I've ever seen in a feed before. I lean toward him for a kiss. A smell comes off of him, something I can't quite place, sweet and rich, and we are kissing, and I can taste what I am smelling, sweet but metallic. Wow, this guy can kiss. I think this is what real kissing feels like.

I pull my head back and touch his face. The flesh is very nice. I can see the dark blood throbbing in his neck veins. Then I notice Corey standing right there, looking at us all confused. He looks like a cheap plastic doll compared this new guy.

"What gives?" Corey asks.

"Fuck off," I say.

Corey gets this really heartbroken look on his face and says, "Listen to me, Zhenzhen Sobakin. You'll break my heart if you go with any other guy. You got that? You are the most special, most beautiful girl I've ever met."

I can't really get into the speech because it's too early in the narrative for that kind of stuff, plus he pronounced my name wrong.

The new guy reaches out and grabs a handful of Corey's face. Literally, he just sinks his fingers into the face and tears a huge, bloody hunk out. Blood sprays everywhere. Holy shit. I guess this is a horror narrative. Is this guy like a vampire or something?

Faceless Corey keeps standing there, spurting blood out of his head hole. I push him away. The new guy squeezes the hunk of flesh like a sponge and lets the blood run down over my face, then starts licking it off. Yeep. This must be some kind of art-porn sampler narrative. I've really, really got to start reading those summaries. Crucial.

But the new guy's tongue feels good on my face and neck and I start licking him back and we start kissing and undressing right there. My pussy is absolutely tingling, and I can feel my heart beating fast. I wonder what my real pussy and my real heart are doing while I'm lying there in the hygiene bed. Forget it. I need to fuck this guy. He strips off the black suit he's wearing to reveal a perfect white body and a huge, beautiful cock. Oh, yes. This is going to be good.

 He lifts me up with ease, and I grip his powerful, muscled arms as he slides his cock into me. Ah, heaven. I hold onto him and close my eyes and let him fuck me. My pussy feels superreal. I can taste Corey's blood on my lips. The man kisses and sucks on my neck. I open my eyes and see that everybody in the club has stopped dancing. They are all standing still as the music plays in the strobe-flashing darkness, watching this guy fuck me. God, this narrative really combines a lot of different kinks. Who wrote this shit? 

Now I'm feeling like a thousand different things in my pussy, most of them incredibly good, some of them new, some of them way beyond anything I've felt offline. The man's eyes are on me, and I'm mesmerized. The other people in the club are all slowly walking towards us, surrounding us. Pretty soon, they're packed around us like the paparazzi in a fame simulation. Public fucking isn't really my fetish, but I don't want to have to stop everything and set up a new scene. Some of the people reach out and touch my tits and my hair and my face. With this guy's cock in me, it all feels good, so I don't stop it.

Despite the fact that I'm on the verge of cumming, I can't help but notice that the light in the club has changed. It seems like it is coming from two angles, making everything seem doubled. I feel like I'm looking at the man's face from two angles, seeing four of his eyes. It's a weird effect, and I wonder if there's something wrong with my visual line.

Next to me, a woman in a pink dress opens her mouth, and her jaw floats away from her face. Her head floats off of her neck. Beside her, a man separates into a dozen slices. Godamnit. This is definitely a fatal glitch. But I'm so close to cumming. And it's going to be fucking fabulous. I wonder if the narrative can hang together for just 10 more seconds before it crashes.

All around us, the people begin to break apart, becoming floating parts. The weird lighting effect becomes more intense, and the man's seems to be made of four sections, except each section is his entire face from a different angle, and they're all crossing each other but staying in place at the same time, and eight eyes are watching me. Oh fuck. This is hurting my brain. Fuck. I can't take this. The narrative should have already crashed back into safety mode.

I say my safe word. Nothing happens. I feel my stomach drop in terror, except it drops at four different places all around the room. Oh, god, am I stuck in a crashing narrative? They say it can fuck you up. I feel myself falling and expanding. One of my hands feels like it is way off on the horizon. Another is ten stories below me. Body parts are swirling around us, showing all sides at once. The man is staring down at me with his awful eyes. How are they so awful? His face is as giant as a mountain range. As the entire sky. I'm seeing too much. No. Above and beneath. Everything has too many sides. Screaming. He has dozens of eyes. Thousands. Thousands of sides. Thousands and millions and millions of eyes. God.
___

___
***#79: comment @ [2016-06-04 01:30:14 UTC](https://www.reddit.com/r/TrueDetective/comments/4mcxcn/yet_another_defence_of_s02/d3v8zg0)***

When we got to the Clearview hospital, it was like Karen said it would be. The emergency room was flooded with patients coming in from Atlanta, but the readjustment center was empty except for a lone staffer who was watching the lobby's wall set and praying.

The set was showing footage of the black cloud over Atlanta. Or maybe it was Denver. Or Riyadh. 12 cities had gone up in the last hour. They weren't the largest or most powerful cities in the world. Hefei. Zhengzhou. Bengaluru. What was the pattern? What the hell had Bengaluru done to anybody?

Karen said there was no real pattern.

>this is Q's opening move. her entrance into the world. she wont destroy everything. but she will kill and kill until she thinks we are ready for her demands.
	
I found a wheelchair by the readjustment center's entrance and wheeled Karen down to the EMRT room. Somewhere, a hygiene bed's life alarm was ringing. I ignored it. My goal was to get Karen some muscle treatment. A single treatment probably wouldn't give her enough strength to stand on her own, but she could at least hold her head up and move her arms, and she might regain her voice and sight.

In the treatment room, I filled a treatment tub with the minty-smelling conducting gel and washed Karen off and fit her with breathing tube. These were normally tech duties, stuff I thought I would never be doing again.

Looking down at this little twig of a woman on the table, it occurred to me that all I had to do was tie off her breathing tube, and that would be the end of her. I asked her the question that kept coming to my mind. "How do I know for sure that you didn't blow up Atlanta yourself? How do I know you aren't full of shit?"

My set was blank for a while before she answered.

>well... how could I prove it?

I tried to think of a way. Some kind of test. "I don't know," I said finally.

>u know much about statistical proxy distillation tracing?

"No."

>then it would be hard to prove it to u

"So how do I know it wasn't you?"

>u cant know. 

"I need to know if I'm going to help you."

>then learn about SPDT

"I don't have time to learn about fucking SP fucking DT."

>then u cant know. ur just dealing with stuff thats too advanced

I walked away from the table and sat down in a nearby chair. I felt like I was cracking up. The urge to cry had come and passed every few minutes, and it came again. "I don't know what to do."

>i told u. we must get to upstate New York. there's a way to defeat Q.

"Maybe you are Q."

>listen before u put me in the gel, I want u to pull my jack battery. cut it off

"And that would prove you're not Q?"

>not really. i couldve scripted everything

"Oh."

>but it would mean i cant directly order nuclear strikes

"Oh, well, that's a relief," I said, rubbing my face and trying to blink away the fresh wave of tears. "What's in upstate New York that's so important?"

>there is a resource Q cant access. something she cannot defend against.

"What?"

>honestly, if u dont understand something simple like SPDT, u wont understand this.

"Fucking great," I said. We sat there in silence for a long moment. Finally, another message showed up.

>im not Q. i spent my life fighting Q. i fought Q instead of living a life. we still have a chance to win. we must win.

I sighed and stood up and walked over to her. "Well, then let's get started."

>good

I found the jack patch on the back of Karen's neck and squeezed at the tattooed points. Her battery capsule slowly slid out of her skin like a giant blackhead.  I disconnected the wire. Now she was completely disconnected from infraspace. I picked up her body and gently lowered it into the conducting gel. It took a minute for her to sink to the bottom, for the gel slowly slide over her face like a closing curtain. I dialed up 90 minutes of muscle treatment and 30 minutes of eye treatment and started the tub up.

I sat for a while, listening to the soft wobbling sounds of the gel shifting as Karen's muscles clenched and unclenched at a rapid-fire rate. This was the sort of spare moment where a person would stare at their set and look at game replays or something, but my set was a just a long list of red interrupts, telling me about how everybody was dead.

I realized that the hygiene bed's life alarm was still going off in some other room. Usually when I heard that sound, I went racing to find out what was going on. But I had just ignored it. Well, the person was probably dead before we got here. What were the odds that they had just gone into arrest when we walked in the door? And who gave a shit anyways when a 100 million people had also died today. Still... there was an instinctive part of me that wanted to run toward the sound, that wanted to help.

I got up and walked down the hall. The ringing got louder. At the end of the hallway, there was a small room with 4 hygiene beds that had been brought in for in-hospital disconnection, a procedure usually reserved for really complex cases. The last bed was blinking red. I took a look at the readout, but it didn't show cardiac arrest. In fact, it was showing 260 bpm. It must have been malfunctioning. I looked at the patient chart. Zhenzhen Sobakin. 24 years old. Total connection duration: 47 minutes. It must have been runtime crash. Unlucky.

I pressed the seal button, and the bed lid opened up. When she came into view, I staggered back and shouted for help.
___

